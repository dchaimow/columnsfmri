function results = simulatefMRIOfColumnPatterns(parameters)
% simulatefMRIOfColumnPatterns simulates fMRI of column patterns. 
%   RESULTS = simulatefMRIOfColumnPatterns(PARAMETERS) runs simulations of
%   cortical column patterns and their imaging. It quantifies measures 
%   related to possible analysis objectives and approaches, and estimates
%   optimal voxel widths. Results are displayed as text and returned in 
%   structure RESULTS.
% 
%   PARAMETERS is a structure of parameters that can be set using
%   setParameters(s1,...).
%
%   see also setParameters

% potential limitations of this version:
% - only 2D single slice case
%   alt: isotropic voxels, multiple slices within constant 3D volume
% - no arbitrary spectra
%   alt: specify filter spectrum and/or amplitude
% - detection probability calculated from mvCNR fitting
%   alt: calculate analytically simulate detection probability
% - decoding probability and decoding accuracy from mvCNR fitting
%   alt: simulate decoding
%        NOTE: fitting and simulation depends on some implicit assumptions 
%        (e.g. trial length)
% - output is printout of optimum voxels and associated quantities, in 
%   addition all quantities as a function of voxel width are returned in
%   structure results
%   alt: display of entire curves, display examplary simulated patterns

% set parameters
nTrials        = parameters.nTrials;
Nsim           = parameters.N;
L              = parameters.L;
rho            = parameters.rho;
delta          = parameters.delta;
fwhm           = parameters.fwhm;
b              = parameters.beta;
downFactors    = parameters.downFactors;
sliceThickness = parameters.sliceThickness;
TR             = parameters.TR;
nT             = parameters.nT;
noiseModel     = parameters.noiseModel;
AFlat          = parameters.AFlat;

% setup simulation grid
sim = cdt_setupsim(Nsim,L);

% compute range of voxel widths
wRange = sim.L./(2 .* ceil(sim.N .* downFactors .* 0.5));

% voxel volume as a function of voxel width
voxelVOfW = sliceThickness.*wRange.^2;

% number of voxels as a function of voxel width (assuming single slice)
nVoxelsOfW = AFlat./(wRange.^2);

% noise level as a function of voxel volume
differentialFlag = true;
noiseOfW    = ...
    cit_noiseModel(voxelVOfW,noiseModel,TR,1,nT,differentialFlag);

cr = zeros(nTrials,length(wRange));
cor = zeros(nTrials,length(wRange));

for zTrial = 1:nTrials
    rng(parameters.randomNumberSeed+zTrial);

    % initialize noise patter for simulation of columns
    noise = cdt_noise2(sim);
    % simulate neuronal columnar pattern
    neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise); 
    % simulate BOLD response pattern
    bold = cdt_bold2(sim,fwhm,b,neuronal);
    
    % for each tested voxel width
    for zW = 1:length(wRange)
        w = wRange(zW);
        
        % simulate MRI voxel sampling
        downFactor = sim.dx/w;
        [voxel,~] = cdt_mri2(sim,downFactor,bold);
        
        % calculate contrast range
        cr(zTrial,zW) = std(voxel(:));
        
        % add noise
        voxelPlusNoise = voxel + noiseOfW(zW)*randn(size(voxel));
   
        % calculate correlation to original (neuronal) pattern        
        cor(zTrial,zW) =  patternCorrelation(sim,neuronal,voxelPlusNoise);
    end        
end

% average over trials
cr = mean(cr);
cor = mean(cor);

% calculate CNR and mv-CNR
CNR = cr./noiseOfW;
a = 0.26;
mvCNR = CNR.*nVoxelsOfW.^a;

% calculate univariate detection probability
pUniOfW = detectionProbability(CNR,1);

% calculate multivariate detection probability
fPMultiDetect = cdfModel(1.9038,3.5990,0.05,@wblcdf);
pMultiOfW = fPMultiDetect(mvCNR);

% calculate decoding probability
fPDecode2 = cdfModel(2.0675,3.4101,0.05,@wblcdf);
fPDecode4 = cdfModel(2.8451,3.4770,0.05,@wblcdf);
fPDecode8 = cdfModel(3.8086,3.2733,0.05,@wblcdf);

pDecodeOfW2 = fPDecode2(mvCNR);
pDecodeOfW4 = fPDecode4(mvCNR);
pDecodeOfW8 = fPDecode8(mvCNR);

% calculate decoding accuracy
fMeanClassPerf2 = cdfModel(4.7018,1.9954,1/2,@wblcdf);
fMeanClassPerf4 = cdfModel(8.0900,2.1585,1/4,@wblcdf);
fMeanClassPerf8 = cdfModel(15.8022,1.9954,1/8,@wblcdf);

meanClassPerfOfW2 = fMeanClassPerf2(mvCNR);
meanClassPerfOfW4 = fMeanClassPerf4(mvCNR);
meanClassPerfOfW8 = fMeanClassPerf8(mvCNR);

% find optima
[maxPUni,idxMaxPUni] = max(pUniOfW);
optWPUni = wRange(idxMaxPUni);

[maxMVCNR,idxMaxMVCNR] = max(mvCNR);
optWMVCNR = wRange(idxMaxMVCNR);

maxPMulti = max(pMultiOfW);
assert(maxPMulti==pMultiOfW(idxMaxMVCNR));

maxPDecode2 = max(pDecodeOfW2);
maxPDecode4 = max(pDecodeOfW4);
maxPDecode8 = max(pDecodeOfW8);
assert(maxPDecode2==pDecodeOfW2(idxMaxMVCNR));
assert(maxPDecode4==pDecodeOfW4(idxMaxMVCNR));
assert(maxPDecode8==pDecodeOfW8(idxMaxMVCNR));

maxMeanClassPerf2 = max(meanClassPerfOfW2);
maxMeanClassPerf4 = max(meanClassPerfOfW4);
maxMeanClassPerf8 = max(meanClassPerfOfW8);
assert(maxMeanClassPerf2==meanClassPerfOfW2(idxMaxMVCNR));
assert(maxMeanClassPerf4==meanClassPerfOfW4(idxMaxMVCNR));
assert(maxMeanClassPerf8==meanClassPerfOfW8(idxMaxMVCNR));

[maxCor,idxMaxCor] = max(cor);
optWCor = wRange(idxMaxCor);

% assign results
results.w                        = wRange;
results.pDetectUnivariate        = pUniOfW;
results.pDetectUnivariate_max    = maxPUni;
results.pDetectUnivariate_optW   = optWPUni;

results.mvCNR                    = mvCNR;
results.mvCNR_max                = maxMVCNR;
results.mvCNR_opt                = optWMVCNR;

results.pDetectMultivariate      = pMultiOfW;
results.pDetectMultivariate_max  = maxPMulti;
results.pDetectMultivariate_optW = optWMVCNR;

results.pDecode2                  = pDecodeOfW2;
results.pDecode2_max              = maxPDecode2;
results.pDecode2_optW             = optWMVCNR;

results.accuracyDecode2           = meanClassPerfOfW2;
results.accuracyDecode2_max       = maxMeanClassPerf2;
results.accuracyDecode2_optW      = optWMVCNR;

results.pDecode4                  = pDecodeOfW4;
results.pDecode4_max              = maxPDecode4;
results.pDecode4_optW             = optWMVCNR;

results.accuracyDecode4           = meanClassPerfOfW4;
results.accuracyDecode4_max       = maxMeanClassPerf4;
results.accuracyDecode4_optW      = optWMVCNR;

results.pDecode8                  = pDecodeOfW8;
results.pDecode8_max              = maxPDecode8;
results.pDecode8_optW             = optWMVCNR;

results.accuracyDecode8           = meanClassPerfOfW8;
results.accuracyDecode8_max       = maxMeanClassPerf8;
results.accuracyDecode8_optW      = optWMVCNR;

results.patternCorrelation       = cor;
results.patternCorrelation_max   = maxCor;
results.patternCorrelation_optW  = optWCor;

% print out results
fprintf('optimized quantity                 | optimal value | optimal voxel width\n');
fprintf('-----------------------------------+---------------+--------------------\n');
fprintf('univariate detection probability   | %.2f          | %.2f mm            \n',maxPUni,optWPUni);
fprintf('multivariate detection probability | %.2f          | %.2f mm            \n',maxPMulti,optWMVCNR);
fprintf('decoding probability - 2 classes   | %.2f          | %.2f mm            \n',maxPDecode2,optWMVCNR);
fprintf('decoding accuracy    - 2 classes   | %.2f          | %.2f mm            \n',maxMeanClassPerf2,optWMVCNR);
fprintf('decoding probability - 4 classes   | %.2f          | %.2f mm            \n',maxPDecode4,optWMVCNR);
fprintf('decoding accuracy    - 4 classes   | %.2f          | %.2f mm            \n',maxMeanClassPerf4,optWMVCNR);
fprintf('decoding probability - 8 classes   | %.2f          | %.2f mm            \n',maxPDecode8,optWMVCNR);
fprintf('decoding accuracy    - 8 classes   | %.2f          | %.2f mm            \n',maxMeanClassPerf8,optWMVCNR);
fprintf('pattern correlation                | %.2f          | %.2f mm            \n',maxCor,optWCor);
end

function f = cdfModel(a,b,y0,cdf)
f = @(x) y0+(cdf(x,a,b)-cdf(0,a,b))*(1-y0);
end