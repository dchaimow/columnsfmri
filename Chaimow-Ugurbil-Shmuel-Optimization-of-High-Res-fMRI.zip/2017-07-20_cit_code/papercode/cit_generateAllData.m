rootDir = fullfile(fileparts(mfilename('fullpath')));

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));

%% parameters are set in:
% cit_masterParameterSetting.m
% (is being called from figure functions)

%% for generateFigure_cnrAsIntegration:
% ~10s
calcData_cnrAsIntegration

%% for generateFigure_voxelSizeDependence:
% ~1min20s
calcData_voxelSizeDependence

%% decoding simulation
% run (remaining) simulations on cluster
a = dir(fullfile(rootDir,'data','decodingSimulationTrials',...
    'dataAllDecodingDetectionCNRnVoxels',...
    'dataAllDecodingDetectionCNRnVoxels_*.mat'));
todoNumbers = setdiff(1:1000,arrayfun(@(x) str2num(x.name(36:end-4)),a));
for z=1:length(todoNumbers)
    submitDecodingSimToGuillimin(todoNumbers(z));
end

a = dir(fullfile(rootDir,'data','decodingSimulationTrials',...
    'dataAllDecodingDetectionCNRnVoxels_4curves',...
    'dataAllDecodingDetectionCNRnVoxels_4curves_*.mat'));
todoNumbers = setdiff(1:1000,arrayfun(@(x) str2num(x.name(44:end-4)),a));
for z=1:length(todoNumbers)
    submitDecodingSimPermutationToGuillimin(todoNumbers(z));
end

a = dir(fullfile(rootDir,'data','decodingSimulationTrials',...
    'dataAllDecodingDetectionCNRnVoxels_permutation',...
    'dataAllDecodingDetectionCNRnVoxels_permutation_*.mat'));
todoNumbers = setdiff(1:1000,arrayfun(@(x) str2num(x.name(48:end-4)),a));
for z=1:length(todoNumbers)
    submitDecodingSimPermutationToGuillimin(todoNumbers(z));
end

% download
system([...
    'rsync -avu dchaimow@guillimin.hpc.mcgill.ca',...
    ':/home/dchaimow/projectspace/allDecodingDetectionCNRnVoxels/*.mat ',...
    fullfile(rootDir,'data',...
    '/decodingSimulationTrials/dataAllDecodingDetectionCNRnVoxels/')]);

system([...
    'rsync -avu dchaimow@guillimin.hpc.mcgill.ca',...
    ':/home/dchaimow/projectspace/allDecodingDetectionCNRnVoxels_4curves/*.mat ',...
    fullfile(rootDir,'data',...
    '/decodingSimulationTrials/dataAllDecodingDetectionCNRnVoxels_4curves/')]);

system([...
    'rsync -avu dchaimow@guillimin.hpc.mcgill.ca',...
    ':/home/dchaimow/projectspace/allDecodingDetectionCNRnVoxels_permutation/*.mat ',...
    fullfile(rootDir,'data',...
    '/decodingSimulationTrials/dataAllDecodingDetectionCNRnVoxels_permutation/')]);

% combine trials
% ~10s and ~20s
combineAllDecodingDetectionCNRnVoxelsResults;
combineAllDecodingDetectionCNRnVoxelsResults_4curves;
combineAllDecodingDetectionCNRnVoxelsResults_permutation;

%% optimal voxel sizes
% every individual trial ~1h15min on 1 CPU
zTrials = 32;
completedTrials = [];
%locally (Guillimin version similar to decoding sim above)
parfor z=setdiff(1:zTrials,completedTrials)
    fig4SingleTrialData(z);
    fig4SingleTrialDataScannerSpecific(z);
end
%on cluster:
parfor z=setdiff(1:zTrials,completedTrials)
    submitFig4DataToGuillimin(z);
    submitFig4DataScannerSpecificToGuillimin(z);
end
% combine trials 
% ~2x35s
fig4CombineSingleTrialData;
fig4CombineSingleTrialDataScannerSpecific;

%% compare scanner effects
% ~4min25s
calcData_compareEffects;

%% imgpsf effect
% ~3min
calcData_imgpsfEffect

%% imgpsf effect quadratic
% ~3min
quadraticFlag = true;
calcData_imgpsfEffect(quadraticFlag);
