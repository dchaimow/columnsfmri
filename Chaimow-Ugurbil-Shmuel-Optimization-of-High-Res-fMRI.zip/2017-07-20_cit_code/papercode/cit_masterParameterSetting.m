function parameters = cit_masterParameterSetting
parameters.N = 512;
parameters.L = 24; % mm, for simulation/calculation of contrast range
parameters.randomNumberSeed = 23;

parameters.Aflat = 87; % mm^2 area for calculating nVoxels (from odc rois)
parameters.Vhemi = 3250; % mm^3 volume for nVoxels (Schwartzkopf 2010);
% Obermayer finds in monkeys tha Orient cycle is .8-.9 times ODC cycle
% depending on direction (not totally isotropic), using 2 mm ODC cycle in
% humans this results in rho = .56-.63
% Essas paper: 1.43 - 1.83 cycle (2 subjects)
% we use 1/1.6 = 0.625
parameters.rho = 1/1.6;

% delta fwhm relative to rho 
parameters.delta = 0.5; % moderate degree of irregularity

% PSF FWHM in mm
parameters.fwhm7TSE = 0.82; % Chaimow et al. 2015 in preparation
parameters.fwhm7TGE = 1.02; % Chaimow et al. 2015 in preparation
% 3T GE PSF = 2.8 mm calculated from Engel 3.5 mm (1.5T), accounting for
% RF effect, which we estimated to be 2.1156 mm (Chaimow et al. 2015 in
% preparation)
parameters.fwhm3TGE = 2.8; % Chaimow et al. 2015 in preparation
parameters.fwhmExample = 1.5; % Exemplary PSF width for model overview

% PSF amplitude heuristically set taking a number of results into account
parameters.beta7TSE = 0.025;
parameters.beta7TGE = 0.035;
parameters.beta3TGE = 0.03;
parameters.betaExample = 0.03;

parameters.TR = 2; % s
parameters.nT = 1000; % number of volumes (sum of both conditions)
parameters.sliceThickness = 2.5; % mm
parameters.voxelWidth = 0.5; % mm
parameters.voxelWidthExample = 1; % mm

% rho and delta range for pattern parametrization figure
parameters.parametrizationFigure.rhoRange = [0.25 0.5 1];
parameters.parametrizationFigure.deltaRange = [0 0.25 0.5 0.75 1];

% fwhm, rho and delta range for pattern dependence figure
parameters.patternDependenceFigure.fwhmSteps = [0.5 1 2];
parameters.patternDependenceFigure.deltaRange = linspace(0,1,21);
parameters.patternDependenceFigure.rhoRange = 1./linspace(5,0.2,25);

% range of downsampleFactos/voxelSize
parameters.downFactors = (2/parameters.N) * ...
    [3:23 24 25 26 27 28 30 32 34 37 40 44 48 53 60 69 80 96 120 160 240];

% unknown pattern reconstruction voxel widths
parameters.unkownPatternFigure.w1 = 0.5;
parameters.unkownPatternFigure.w2 = 1;

%imaging fasibility thresholds
%parameters.cnrThreshold = 1; % preliminary seeting, change later!!!
%parameters.cnrThreshold = 7.88; % = 80% detection probability, p<0.05
%parameters.ocnrThreshold = 3.33; % = 80% detection probability, p<0.05
parameters.pThreshold = 0.8; % = 80% detection probability, p<0.05
parameters.corThreshold = sqrt(0.5);
parameters.corThresholdLow = 0.5;