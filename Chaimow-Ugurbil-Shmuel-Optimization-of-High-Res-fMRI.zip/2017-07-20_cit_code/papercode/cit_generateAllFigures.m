rootDir = fullfile(fileparts(mfilename('fullpath')));

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
addpath(fullfile(rootDir,'generateFigures'));

% figure 1 overview components
generateFigureComponents_modelOverview;
% -> assemble or update figure in omnigraffle

% figure 2 pattern parametrization
generateFigure_patternParametrizationBoth(2);

% figure 3 contrast range as integration
generateFigure_cnrAsIntegration(3);

% figure 4 CNR
generateFigure_voxelSizeDependence(4);

% figure 5 detection and decoding
generateFigure_Decoding_Detection_MVCNR_Individual;

% figure 6 voxel size dependenve for MVPA
generateFigure_voxelDependenceForMVPA(6);

% figure 7 pattern correlation
generateFigure_patternCorrelation_Individual
% -> assemble or update figure in omnigraffle

% figure 8 optimal voxel size - pattern dependence
generateFigure_optimalVoxelSize_detectionProbabilityVersion(8);

% figure 9 optimal quantities size - pattern dependence
generateFigure_optimalQuantities_detectionProbabilityVersion(9);

% figure 10  optimal Voxel size/quatities extract - pattern dependence
generateFigure_optimal_extract_pDetect(10);

% figure 11 effect of field strength
generateFigure_compareEffects(11);

% figure 12  optimal VOxel size/qunatitites - scanner specific
generateFigure_optimalScannerSpecific_extract_pDetect(12);

% figure 13
generateFigure_imgpsfEffect(13);

% figure 14 isotropic voxels and 3D
generateFigure_voxelDependenceIso(14);

% figure 15  imaging of unknown patterns
generateFigure_unknownPatternRecon(15);

% figure 16 (supplementary)
generateFigure_permutation(16);

% figure 17 (supplementary)
quadraticFlag = true;
generateFigure_imgpsfEffect(17,quadraticFlag);
