function y = dcifft2(fy,dk)
N = size(fy,1);
y = N^2 * dk^2 * fftshift(ifft2(ifftshift(fy)));