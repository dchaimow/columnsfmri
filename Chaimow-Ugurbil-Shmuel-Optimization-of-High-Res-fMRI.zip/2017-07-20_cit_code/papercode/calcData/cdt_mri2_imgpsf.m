function [my,vSize] = cdt_mri2_imgpsf(sim,downFactor,y,fwhmIMGPSF)
% downFactor between 0 and 1
L = sim.L;
% here N is defined, so that 2N covers the FOV in one dim
N = ceil(sim.N * downFactor * 0.5);
vSize = L/(2*N);

centerk = find(sim.k == 0);

fwfactor = 2*sqrt(2*log(2));
sigmaIMGPSF = fwhmIMGPSF/fwfactor;

if fwhmIMGPSF<0
    yk = dcfft2(y,sim.dx) .* ...
        exp(2*pi^2*sigmaIMGPSF^2.*sim.k1.^2);
else
    yk = dcfft2(y,sim.dx) .* ...
        exp(-2*pi^2*sigmaIMGPSF^2.*sim.k1.^2);
end
downSampledY = yk(centerk-N:centerk+N-1,centerk-N:centerk+N-1);
my = real(fftshift(ifft2(ifftshift(downSampledY))))/vSize^2;



