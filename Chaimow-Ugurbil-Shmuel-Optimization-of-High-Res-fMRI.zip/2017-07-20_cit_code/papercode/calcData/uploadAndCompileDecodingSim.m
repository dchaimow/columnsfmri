function uploadAndCompileDecodingSim(targetFolder)
codeFolder = 'allDecodingDetectionCNRnVoxels';

if ~exist('targetFolder','var')
    targetFolder = codeFolder;
end

jobFolder1 = targetFolder;
jobFolder2 = [targetFolder '_4curves'];
jobFolder3 = [targetFolder '_permutation'];

nowStr = datestr(now,30);

% compose code folder
mfileDir = fileparts(mfilename('fullpath'));
rootDir = fullfile(mfileDir,'..');

fileList = {...
    'simulateAllDecodingDetectionCNRnVoxels.m',...
    'simulateAllDecodingDetectionCNRnVoxels_4curves.m',...
    'simulateAllDecodingDetectionCNRnVoxels_permutation.m',...
    'translateDifferentialMultiMeasurementCNRtoSingleResponseCNR.m'};

codeFolderPath = fullfile(mfileDir,codeFolder);
mkdir(codeFolderPath);
copyfile(fullfile(rootDir,'cit_masterParameterSetting.m'),...
    fullfile(codeFolderPath,'cit_masterParameterSetting.m'));
for z=1:length(fileList)
    copyfile(fullfile(mfileDir,fileList{z}),...
        fullfile(codeFolderPath,fileList{z}));
end
compileStr = [...
    'mcc -mv -R -singleCompThread -R -nodisplay -N -p stats simulateAllDecodingDetectionCNRnVoxels.m\n' ...
    'mcc -mv -R -singleCompThread -R -nodisplay -N -p stats simulateAllDecodingDetectionCNRnVoxels_4curves.m\n' ...
    'mcc -mv -R -singleCompThread -R -nodisplay -N -p stats simulateAllDecodingDetectionCNRnVoxels_permutation.m\n' ...
    ];
fid = fopen(fullfile(codeFolderPath,'make.sh'),'w');
fprintf(fid, compileStr);
fclose(fid);

% find out if code folder exists
[status,~]  = ...
    system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
    '"[ -d ' fullfile('~','matlab',targetFolder)  ' ]"']);

% if so, rename the folder
if status == 0
    [status,result]  = ...
        system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
        '"mv ' fullfile('~','matlab',targetFolder) ...
        ' ' fullfile('~','matlab',[targetFolder '_' nowStr]) '"']);
    if status
        disp(result);
        error('error during code folder renaming');
    end
end

% transfer code folder
[status, result] = system(['scp -r ' codeFolderPath ...
    ' dchaimow@guillimin-p2.hpc.mcgill.ca:' ...
    fullfile('~','matlab',targetFolder)]);
if status
    disp(result);
    error('error during code folder transfer');
end

% find out if job folders exists
[status,~]  = ...
    system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
    '"[ -d ' fullfile('~','projectspace',jobFolder1)  ' ]"']);

% if not, create folder 
if status ~= 0
    [status,~]  = ...
        system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
        '"mkdir ' fullfile('~','projectspace',jobFolder1)  '"']);
end

[status,~]  = ...
    system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
    '"[ -d ' fullfile('~','projectspace',jobFolder2)  ' ]"']);

% if not, create folder 
if status ~= 0
    [status,~]  = ...
        system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
        '"mkdir ' fullfile('~','projectspace',jobFolder2)  '"']);
end

[status,~]  = ...
    system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
    '"[ -d ' fullfile('~','projectspace',jobFolder3)  ' ]"']);

% if not, create folder 
if status ~= 0
    [status,~]  = ...
        system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
        '"mkdir ' fullfile('~','projectspace',jobFolder3)  '"']);
end

% compile code
[status,result] = system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
    '"chmod +x ' fullfile('~','matlab',targetFolder,'make.sh') '"']);
if status
    disp(result);
    error('error during compilation');
end

[status,] = system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca ' ...
    '"' ...
    'source ~/.bash_profile ; ' ...
    'cd ' fullfile('~','matlab',targetFolder) ' ; '...
    './make.sh' ...
    '"'],'-echo');
if status
    disp(result);
    error('error during compilation');
end

rmdir(codeFolderPath,'s');
end