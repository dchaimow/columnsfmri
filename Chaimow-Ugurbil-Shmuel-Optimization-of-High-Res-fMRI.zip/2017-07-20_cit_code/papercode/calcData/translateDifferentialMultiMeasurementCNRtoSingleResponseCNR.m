function singleResponseCNR = ...
    translateDifferentialMultiMeasurementCNRtoSingleResponseCNR(diffMultiCNR,nResponses)
% nResponse = number of responses 
% (nResponses/2 condition A and nResponses/2 condition B)

% differential multimeasurementCNR is the ratio of the standard deviation
% of a differential map which has been calculated as the difference of 
% single condition maps A and B, each estimated by averaging nResponse/2
% responses

% we define units such that the standard deviation of the differential map
% is equal to 1
% accordingly the differential noise is 1/diffMultiCNR


% because response B = -responseA, it follows that the standard deviation of
% single condition maps is 0.5

% the noise in single condition maps increases by a factir of sqrt(2)

% the single response standard deviations are equal to the standard
% deviations of their averages
% the noise increases by a factor of sqrt(nResponses/2)

% in total, single response CNR is
singleResponseCNR = diffMultiCNR/sqrt(nResponses);
