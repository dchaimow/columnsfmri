function calcData_compareEffects
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

nTrials = 32;

dataMVCNR = load(fullfile(dataDir,...
    'data_allDecodingDetectionCNRnVoxels'));

% set parameters
parameters = cit_masterParameterSetting;
rng(parameters.randomNumberSeed);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

downFactors = parameters.downFactors;
wRange = sim.L./(downFactors*sim.N);

rho = parameters.rho;
delta = parameters.delta;
nT = parameters.nT;
TR = parameters.TR;
sliceThickness = parameters.sliceThickness;
area2DFlat = parameters.Aflat;


differentialFlag = true;
voxelV = sliceThickness.*wRange.^2;
nVoxels = area2DFlat./(wRange.^2);

noiseOfWSingleVoxel7T    = ...
    cit_noiseModel(voxelV,'7T',TR,1,nT,differentialFlag);
noiseOfWAveragedVoxels7T = ...
    cit_noiseModel(voxelV,'7T',TR,nVoxels,nT,differentialFlag);
noiseOfWSingleVoxel3T    = ...
    cit_noiseModel(voxelV,'3T',TR,1,nT,differentialFlag);
noiseOfWAveragedVoxels3T = ...
    cit_noiseModel(voxelV,'3T',TR,nVoxels,nT,differentialFlag);
noiseOfWSingleVoxelTherm = ...
    cit_noiseModel(voxelV,'Thermal',TR,1,nT,differentialFlag);
noiseOfWAveragedVoxelsTherm = ...
    cit_noiseModel(voxelV,'Thermal',TR,nVoxels,nT,differentialFlag);
noiseOfWSingleVoxelPhys = ...
    cit_noiseModel(voxelV,'Physiological',TR,1,nT,differentialFlag);
noiseOfWAveragedVoxelsPhys = ...
    cit_noiseModel(voxelV,'Physiological',TR,nVoxels,nT,differentialFlag);

cr3T = zeros(1,length(wRange));
cr7TGE = zeros(1,length(wRange));
cr7TSE = zeros(1,length(wRange));
crMag3T = zeros(1,length(wRange));
crMag7TGE = zeros(1,length(wRange));
crMag7TSE = zeros(1,length(wRange));
crPSF3T = zeros(1,length(wRange));
crPSF7TGE = zeros(1,length(wRange));
crPSF7TSE = zeros(1,length(wRange));
crNoise3T = zeros(1,length(wRange));
crNoise7T = zeros(1,length(wRange));
crNoisePhys = zeros(1,length(wRange));
crNoiseTherm = zeros(1,length(wRange));

cor3T = zeros(1,length(wRange));
cor7TGE = zeros(1,length(wRange));
cor7TSE = zeros(1,length(wRange));
corMag3T = zeros(1,length(wRange));
corMag7TGE = zeros(1,length(wRange));
corMag7TSE = zeros(1,length(wRange));
corPSF3T = zeros(1,length(wRange));
corPSF7TGE = zeros(1,length(wRange));
corPSF7TSE = zeros(1,length(wRange));
corNoise3T = zeros(1,length(wRange));
corNoise7T = zeros(1,length(wRange));
corNoisePhys = zeros(1,length(wRange));
corNoiseTherm = zeros(1,length(wRange));

b3T = parameters.beta3TGE;
b7TGE = parameters.beta7TGE;
b7TSE = parameters.beta7TSE;

fwhm3T = parameters.fwhm3TGE;
fwhm7TGE = parameters.fwhm7TGE;
fwhm7TSE = parameters.fwhm7TSE;

% standard parameters (use 7T GE)
b0 = b7TGE;
fwhm0 = fwhm7TGE;
noiseOfWSingleVoxel0 = noiseOfWSingleVoxel7T;
noiseOfWAveragedVoxels0 = noiseOfWAveragedVoxels7T;

tic;
nIterations = nTrials;
zIterations = 0;
for zTrials = 1:nTrials    
    disp(zTrials);
    noise = cdt_noise2(sim);
    neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
    
    bold3T = cdt_bold2(sim,fwhm3T,b3T,neuronal);
    bold7TGE = cdt_bold2(sim,fwhm7TGE,b7TGE,neuronal);
    bold7TSE = cdt_bold2(sim,fwhm7TSE,b7TSE,neuronal);
    
    boldMag3T   = cdt_bold2(sim,fwhm0,b3T,neuronal);
    boldMag7TGE = cdt_bold2(sim,fwhm0,b7TGE,neuronal);
    boldMag7TSE = cdt_bold2(sim,fwhm0,b7TSE,neuronal);
    
    boldPSF3T = cdt_bold2(sim,fwhm3T,b0,neuronal);
    boldPSF7TGE = cdt_bold2(sim,fwhm7TGE,b0,neuronal);
    boldPSF7TSE = cdt_bold2(sim,fwhm7TSE,b0,neuronal);
    
    bold0 = cdt_bold2(sim,fwhm0,b0,neuronal); % standard parameters
    
    parfor zW = 1:length(wRange)
        rng(parameters.randomNumberSeed+zW);
        w = wRange(zW);
        downFactor = sim.dx/w;
        
        [cr3T(zW),cor3T(zW)] = calcAll...
            (cr3T(zW),cor3T(zW),zW,b3T,...
            noiseOfWSingleVoxel3T,bold3T,neuronal,sim,downFactor);
        [cr7TGE(zW),cor7TGE(zW)] = calcAll...
            (cr7TGE(zW),cor7TGE(zW),zW,b7TGE,...
            noiseOfWSingleVoxel7T,bold7TGE,neuronal,sim,downFactor);
        [cr7TSE(zW),cor7TSE(zW)] = calcAll...
            (cr7TSE(zW),cor7TSE(zW),zW,b7TSE,...
            noiseOfWSingleVoxel7T,bold7TSE,neuronal,sim,downFactor);
        
        [crMag3T(zW),corMag3T(zW)] = calcAll...
            (crMag3T(zW),corMag3T(zW),zW,b3T,...
            noiseOfWSingleVoxel0,boldMag3T,neuronal,sim,downFactor);
        [crMag7TGE(zW),corMag7TGE(zW)] = calcAll...
            (crMag7TGE(zW),corMag7TGE(zW),zW,b7TGE,...
            noiseOfWSingleVoxel0,boldMag7TGE,neuronal,sim,downFactor);
        [crMag7TSE(zW),corMag7TSE(zW)] = calcAll...
            (crMag7TSE(zW),corMag7TSE(zW),zW,b7TSE,...
            noiseOfWSingleVoxel0,boldMag7TSE,neuronal,sim,downFactor);
        
        [crPSF3T(zW),corPSF3T(zW)] = calcAll...
            (crPSF3T(zW),corPSF3T(zW),zW,b0,...
            noiseOfWSingleVoxel0,boldPSF3T,neuronal,sim,downFactor);
        [crPSF7TGE(zW),corPSF7TGE(zW)] = calcAll...
            (crPSF7TGE(zW),corPSF7TGE(zW),zW,b0,...
            noiseOfWSingleVoxel0,boldPSF7TGE,neuronal,sim,downFactor);
        [crPSF7TSE(zW),corPSF7TSE(zW)] = calcAll...
            (crPSF7TSE(zW),corPSF7TSE(zW),zW,b0,...
            noiseOfWSingleVoxel0,boldPSF7TSE,neuronal,sim,downFactor);
        
        [crNoise3T(zW), corNoise3T(zW)] = calcAll...
            (crNoise3T(zW),corNoise3T(zW),zW,b0,...
            noiseOfWSingleVoxel3T,bold0,neuronal,sim,downFactor);
        [crNoise7T(zW), corNoise7T(zW)] = calcAll...
            (crNoise7T(zW),corNoise7T(zW),zW,b0,...
            noiseOfWSingleVoxel7T,bold0,neuronal,sim,downFactor);
        [crNoisePhys(zW), corNoisePhys(zW)] = calcAll...
            (crNoisePhys(zW),corNoisePhys(zW),zW,b0,...
            noiseOfWSingleVoxelPhys,bold0,neuronal,sim,downFactor);
        [crNoiseTherm(zW), corNoiseTherm(zW)] = calcAll...
            (crNoiseTherm(zW),corNoiseTherm(zW),zW,b0,...
            noiseOfWSingleVoxelTherm,bold0,neuronal,sim,downFactor);
    end
    
    zIterations = zIterations + 1;
    disp(['Please wait ... ' ...
        datestr(datenum([0 0 0 0 0 ...
        toc*(nIterations/zIterations-1)]), 'HH:MM:SS') ' left']);
end


cr3T = cr3T/nTrials;
cr7TGE = cr7TGE/nTrials;
cr7TSE = cr7TSE/nTrials;
crMag3T = crMag3T/nTrials;
crMag7TGE = crMag7TGE/nTrials;
crMag7TSE = crMag7TSE/nTrials;
crPSF3T = crPSF3T/nTrials;
crPSF7TGE = crPSF7TGE/nTrials;
crPSF7TSE = crPSF7TSE/nTrials;
crNoise3T = crNoise3T/nTrials;
crNoise7T = crNoise7T/nTrials;
crNoisePhys = crNoisePhys/nTrials;
crNoiseTherm = crNoiseTherm/nTrials;

cor3T = cor3T/nTrials;
cor7TGE = cor7TGE/nTrials;
cor7TSE = cor7TSE/nTrials;
corMag3T = corMag3T/nTrials;
corMag7TGE = corMag7TGE/nTrials;
corMag7TSE = corMag7TSE/nTrials;
corPSF3T = corPSF3T/nTrials;
corPSF7TGE = corPSF7TGE/nTrials;
corPSF7TSE = corPSF7TSE/nTrials;
corNoise3T = corNoise3T/nTrials;
corNoise7T = corNoise7T/nTrials;
corNoisePhys = corNoisePhys/nTrials;
corNoiseTherm = corNoiseTherm/nTrials;

cnr3T = cr3T./noiseOfWSingleVoxel3T;
cnr7TGE = cr7TGE./noiseOfWSingleVoxel7T;
cnr7TSE = cr7TSE./noiseOfWSingleVoxel7T;
cnrMag3T = crMag3T./noiseOfWSingleVoxel0;
cnrMag7TGE = crMag7TGE./noiseOfWSingleVoxel0;
cnrMag7TSE = crMag7TSE./noiseOfWSingleVoxel0;
cnrPSF3T = crPSF3T./noiseOfWSingleVoxel0;
cnrPSF7TGE = crPSF7TGE./noiseOfWSingleVoxel0;
cnrPSF7TSE = crPSF7TSE./noiseOfWSingleVoxel0;
cnrNoise3T = crNoise3T./noiseOfWSingleVoxel3T;
cnrNoise7T = crNoise7T./noiseOfWSingleVoxel7T;
cnrNoisePhys = crNoisePhys./noiseOfWSingleVoxelPhys;
cnrNoiseTherm = crNoiseTherm./noiseOfWSingleVoxelTherm;

mvcnr3T = cnr3T.*nVoxels.^dataMVCNR.a;
mvcnr7TGE = cnr7TGE.*nVoxels.^dataMVCNR.a;
mvcnr7TSE = cnr7TSE.*nVoxels.^dataMVCNR.a;
mvcnrMag3T = cnrMag3T.*nVoxels.^dataMVCNR.a;
mvcnrMag7TGE = cnrMag7TGE.*nVoxels.^dataMVCNR.a;
mvcnrMag7TSE = cnrMag7TSE.*nVoxels.^dataMVCNR.a;
mvcnrPSF3T = cnrPSF3T.*nVoxels.^dataMVCNR.a;
mvcnrPSF7TGE = cnrPSF7TGE.*nVoxels.^dataMVCNR.a;
mvcnrPSF7TSE = cnrPSF7TSE.*nVoxels.^dataMVCNR.a;
mvcnrNoise3T = cnrNoise3T.*nVoxels.^dataMVCNR.a;
mvcnrNoise7T = cnrNoise7T.*nVoxels.^dataMVCNR.a;
mvcnrNoisePhys = cnrNoisePhys.*nVoxels.^dataMVCNR.a;
mvcnrNoiseTherm = cnrNoiseTherm.*nVoxels.^dataMVCNR.a;


rDecode3T = dataMVCNR.f_meanClassPerf{1}(mvcnr3T)';
rDecode7TGE = dataMVCNR.f_meanClassPerf{1}(mvcnr7TGE)';
rDecode7TSE = dataMVCNR.f_meanClassPerf{1}(mvcnr7TSE)';
rDecodeMag3T = dataMVCNR.f_meanClassPerf{1}(mvcnrMag3T)';
rDecodeMag7TGE = dataMVCNR.f_meanClassPerf{1}(mvcnrMag7TGE)';
rDecodeMag7TSE = dataMVCNR.f_meanClassPerf{1}(mvcnrMag7TSE)';
rDecodePSF3T = dataMVCNR.f_meanClassPerf{1}(mvcnrPSF3T)';
rDecodePSF7TGE = dataMVCNR.f_meanClassPerf{1}(mvcnrPSF7TGE)';
rDecodePSF7TSE = dataMVCNR.f_meanClassPerf{1}(mvcnrPSF7TSE)';
rDecodeNoise3T = dataMVCNR.f_meanClassPerf{1}(mvcnrNoise3T)';
rDecodeNoise7T = dataMVCNR.f_meanClassPerf{1}(mvcnrNoise7T)';
rDecodeNoisePhys = dataMVCNR.f_meanClassPerf{1}(mvcnrNoisePhys)';
rDecodeNoiseTherm = dataMVCNR.f_meanClassPerf{1}(mvcnrNoiseTherm)';

pDetectAvg3T = detectionProbability(cnr3T,1);
pDetectAvg7TGE = detectionProbability(cnr7TGE,1);
pDetectAvg7TSE = detectionProbability(cnr7TSE,1);
pDetectAvgMag3T = detectionProbability(cnrMag3T,1);
pDetectAvgMag7TGE = detectionProbability(cnrMag7TGE,1);
pDetectAvgMag7TSE = detectionProbability(cnrMag7TSE,1);
pDetectAvgPSF3T = detectionProbability(cnrPSF3T,1);
pDetectAvgPSF7TGE = detectionProbability(cnrPSF7TGE,1);
pDetectAvgPSF7TSE = detectionProbability(cnrPSF7TSE,1);
pDetectAvgNoise3T = detectionProbability(cnrNoise3T,1);
pDetectAvgNoise7T = detectionProbability(cnrNoise7T,1);
pDetectAvgNoisePhys = detectionProbability(cnrNoisePhys,1);
pDetectAvgNoiseTherm = detectionProbability(cnrNoiseTherm,1);

pMulti3T = detectionProbability(cnr3T,nVoxels);
pMulti7TGE = detectionProbability(cnr7TGE,nVoxels);
pMulti7TSE = detectionProbability(cnr7TSE,nVoxels);
pMultiMag3T = detectionProbability(cnrMag3T,nVoxels);
pMultiMag7TGE = detectionProbability(cnrMag7TGE,nVoxels);
pMultiMag7TSE = detectionProbability(cnrMag7TSE,nVoxels);
pMultiPSF3T = detectionProbability(cnrPSF3T,nVoxels);
pMultiPSF7TGE = detectionProbability(cnrPSF7TGE,nVoxels);
pMultiPSF7TSE = detectionProbability(cnrPSF7TSE,nVoxels);
pMultiNoise3T = detectionProbability(cnrNoise3T,nVoxels);
pMultiNoise7T = detectionProbability(cnrNoise7T,nVoxels);
pMultiNoisePhys = detectionProbability(cnrNoisePhys,nVoxels);
pMultiNoiseTherm = detectionProbability(cnrNoiseTherm,nVoxels);

ocnr3T = cr3T./noiseOfWAveragedVoxels3T;
ocnr7TGE = cr7TGE./noiseOfWAveragedVoxels7T;
ocnr7TSE = cr7TSE./noiseOfWAveragedVoxels7T;
ocnrMag3T = crMag3T./noiseOfWAveragedVoxels0;
ocnrMag7TGE = crMag7TGE./noiseOfWAveragedVoxels0;
ocnrMag7TSE = crMag7TSE./noiseOfWAveragedVoxels0;
ocnrPSF3T = crPSF3T./noiseOfWAveragedVoxels0;
ocnrPSF7TGE = crPSF7TGE./noiseOfWAveragedVoxels0;
ocnrPSF7TSE = crPSF7TSE./noiseOfWAveragedVoxels0;
ocnrNoise3T = crNoise3T./noiseOfWAveragedVoxels3T;
ocnrNoise7T = crNoise7T./noiseOfWAveragedVoxels7T;
ocnrNoisePhys = crNoisePhys./noiseOfWAveragedVoxelsPhys;
ocnrNoiseTherm = crNoiseTherm./noiseOfWAveragedVoxelsTherm;

[maxCNR3T,      idxMaxCNR3T]        = max(cnr3T);
[maxCNR7TGE,    idxMaxCNR7TGE]      = max(cnr7TGE);
[maxCNR7TSE,    idxMaxCNR7TSE]      = max(cnr7TSE);
[maxCNRMag3T,   idxMaxCNRMag3T]     = max(cnrMag3T);
[maxCNRMag7TGE, idxMaxCNRMag7TGE]   = max(cnrMag7TGE);
[maxCNRMag7TSE, idxMaxCNRMag7TSE]   = max(cnrMag7TSE);
[maxCNRPSF3T,   idxMaxCNRPSF3T]     = max(cnrPSF3T);
[maxCNRPSF7TGE, idxMaxCNRPSF7TGE]   = max(cnrPSF7TGE);
[maxCNRPSF7TSE, idxMaxCNRPSF7TSE]   = max(cnrPSF7TSE);
[maxCNRNoise3T, idxMaxCNRNoise3T]   = max(cnrNoise3T);
[maxCNRNoise7T, idxMaxCNRNoise7T]   = max(cnrNoise7T);
[maxCNRNoisePhys, idxMaxCNRNoisePhys]   = max(cnrNoisePhys);
[maxCNRNoiseTherm, idxMaxCNRNoiseTherm]   = max(cnrNoiseTherm);

[maxMVCNR3T,      idxMaxMVCNR3T]        = max(mvcnr3T);
[maxMVCNR7TGE,    idxMaxMVCNR7TGE]      = max(mvcnr7TGE);
[maxMVCNR7TSE,    idxMaxMVCNR7TSE]      = max(mvcnr7TSE);
[maxMVCNRMag3T,   idxMaxMVCNRMag3T]     = max(mvcnrMag3T);
[maxMVCNRMag7TGE, idxMaxMVCNRMag7TGE]   = max(mvcnrMag7TGE);
[maxMVCNRMag7TSE, idxMaxMVCNRMag7TSE]   = max(mvcnrMag7TSE);
[maxMVCNRPSF3T,   idxMaxMVCNRPSF3T]     = max(mvcnrPSF3T);
[maxMVCNRPSF7TGE, idxMaxMVCNRPSF7TGE]   = max(mvcnrPSF7TGE);
[maxMVCNRPSF7TSE, idxMaxMVCNRPSF7TSE]   = max(mvcnrPSF7TSE);
[maxMVCNRNoise3T, idxMaxMVCNRNoise3T]   = max(mvcnrNoise3T);
[maxMVCNRNoise7T, idxMaxMVCNRNoise7T]   = max(mvcnrNoise7T);
[maxMVCNRNoisePhys, idxMaxMVCNRNoisePhys]   = max(mvcnrNoisePhys);
[maxMVCNRNoiseTherm, idxMaxMVCNRNoiseTherm]   = max(mvcnrNoiseTherm);

[maxRDecode3T,      idxMaxRDecode3T]        = max(rDecode3T);
[maxRDecode7TGE,    idxMaxRDecode7TGE]      = max(rDecode7TGE);
[maxRDecode7TSE,    idxMaxRDecode7TSE]      = max(rDecode7TSE);
[maxRDecodeMag3T,   idxMaxRDecodeMag3T]     = max(rDecodeMag3T);
[maxRDecodeMag7TGE, idxMaxRDecodeMag7TGE]   = max(rDecodeMag7TGE);
[maxRDecodeMag7TSE, idxMaxRDecodeMag7TSE]   = max(rDecodeMag7TSE);
[maxRDecodePSF3T,   idxMaxRDecodePSF3T]     = max(rDecodePSF3T);
[maxRDecodePSF7TGE, idxMaxRDecodePSF7TGE]   = max(rDecodePSF7TGE);
[maxRDecodePSF7TSE, idxMaxRDecodePSF7TSE]   = max(rDecodePSF7TSE);
[maxRDecodeNoise3T, idxMaxRDecodeNoise3T]   = max(rDecodeNoise3T);
[maxRDecodeNoise7T, idxMaxRDecodeNoise7T]   = max(rDecodeNoise7T);
[maxRDecodeNoisePhys, idxMaxRDecodeNoisePhys]   = max(rDecodeNoisePhys);
[maxRDecodeNoiseTherm, idxMaxRDecodeNoiseTherm]   = max(rDecodeNoiseTherm);

[maxOCNR3T,      idxMaxOCNR3T]        = max(ocnr3T);
[maxOCNR7TGE,    idxMaxOCNR7TGE]      = max(ocnr7TGE);
[maxOCNR7TSE,    idxMaxOCNR7TSE]      = max(ocnr7TSE);
[maxOCNRMag3T,   idxMaxOCNRMag3T]     = max(ocnrMag3T);
[maxOCNRMag7TGE, idxMaxOCNRMag7TGE]   = max(ocnrMag7TGE);
[maxOCNRMag7TSE, idxMaxOCNRMag7TSE]   = max(ocnrMag7TSE);
[maxOCNRPSF3T,   idxMaxOCNRPSF3T]     = max(ocnrPSF3T);
[maxOCNRPSF7TGE, idxMaxOCNRPSF7TGE]   = max(ocnrPSF7TGE);
[maxOCNRPSF7TSE, idxMaxOCNRPSF7TSE]   = max(ocnrPSF7TSE);
[maxOCNRNoise3T, idxMaxOCNRNoise3T]   = max(ocnrNoise3T);
[maxOCNRNoise7T, idxMaxOCNRNoise7T]   = max(ocnrNoise7T);
[maxOCNRNoisePhys, idxMaxOCNRNoisePhys]   = max(ocnrNoisePhys);
[maxOCNRNoiseTherm, idxMaxOCNRNoiseTherm]   = max(ocnrNoiseTherm);

[maxCor3T,      idxMaxCor3T]        = max(cor3T);
[maxCor7TGE,    idxMaxCor7TGE]      = max(cor7TGE);
[maxCor7TSE,    idxMaxCor7TSE]      = max(cor7TSE);
[maxCorMag3T,   idxMaxCorMag3T]     = max(corMag3T);
[maxCorMag7TGE, idxMaxCorMag7TGE]   = max(corMag7TGE);
[maxCorMag7TSE, idxMaxCorMag7TSE]   = max(corMag7TSE);
[maxCorPSF3T,   idxMaxCorPSF3T]     = max(corPSF3T);
[maxCorPSF7TGE, idxMaxCorPSF7TGE]   = max(corPSF7TGE);
[maxCorPSF7TSE, idxMaxCorPSF7TSE]   = max(corPSF7TSE);
[maxCorNoise3T, idxMaxCorNoise3T]   = max(corNoise3T);
[maxCorNoise7T, idxMaxCorNoise7T]   = max(corNoise7T);
[maxCorNoisePhys, idxMaxCorNoisePhys]   = max(corNoisePhys);
[maxCorNoiseTherm, idxMaxCorNoiseTherm]   = max(corNoiseTherm);

clear bold*;
clear neuronal;
clear noise;
clear sim;

save(fullfile(dataDir,'data_compareEffects'));
end

function [cr,cor] = calcAll(cr,cor,zW,b,noiseOfW,bold,neuronal,sim,downFactor)
[voxel,~] = cdt_mri2(sim,downFactor,bold);
cr = cr + std(voxel(:));
voxelNoise = noiseOfW(zW)*randn(size(voxel));
upVoxel = real(upSample(voxel+voxelNoise,sim));
c = corrcoef(b*neuronal,upVoxel);
cor = cor+c(1,2);
end

function upPattern = upSample(pattern,sim)
Fy = fft2(pattern);
[m,n] = size(Fy); % size of the original matrix
nzsr = sim.N - m; % number of zero rows to add
nzsc = sim.N - n; % number of zero columns to add
% quadrants of the FFT, starting in the upper left
q1 = Fy(1:m/2,1:n/2);
q2 = Fy(1:m/2,n/2+1:n);
q3 = Fy(m/2+1:m,n/2+1:n);
q4 = Fy(m/2+1:m,1:n/2);
zpdr = zeros(nzsr,n/2);  % zeropad rows to insert
zpdc = zeros(nzsr+m,nzsc); % zeropad columns to insert
zpdFy = [ [q1;zpdr;q4] , zpdc , [q2;zpdr;q3] ]; % insert the zeros
upPattern = real(ifft2(zpdFy)) * sim.N^2/(m*n) ;
end