function simulateAllDecodingDetectionCNRnVoxels_permutation(seedNo,dataDir)
tic;
if ischar(seedNo)
    seedNo = str2double(seedNo);
end

mfileDir = fileparts(mfilename('fullpath'));
rootDir = fullfile(mfileDir,'..');

addpath(rootDir);
addpath(mfileDir);

if ~exist('dataDir','var') || isempty(dataDir)
    dataDir = fullfile(rootDir,'data');
end

nVoxelRange = 100;
cnrRange = linspace(0,1,20);
% runs for about 230s per cnr value on one 1 CPU (~76min for 20 cnr values)

nCNR = length(cnrRange);
nNVoxels = length(nVoxelRange);


% measurement and response blocks
parameters = cit_masterParameterSetting;

nMeasurements = parameters.nT;

nMeasurementsPerResponse = 5;
nResponses = nMeasurements/nMeasurementsPerResponse;
assert(mod(nResponses,1)==0);

%classRange = [2,4,8];
classRange = [2];

decodingIsSignificant = zeros(nNVoxels,nCNR,length(classRange));
classPerf = zeros(nNVoxels,nCNR,length(classRange));
classPerfNull = zeros(nNVoxels,nCNR,length(classRange));
rng(seedNo);
for zCNR=1:nCNR
    CNR = cnrRange(zCNR);
    % assume single response to be 1
    singleResponseCNR = ...
        translateDifferentialMultiMeasurementCNRtoSingleResponseCNR(CNR,nResponses);
    singleResponseNoiseLevel = 1/singleResponseCNR;
    if CNR==0
        singleResponseNoiseLevel = 1;
    end
    for zNVoxels=1:nNVoxels
        nVoxels = nVoxelRange(zNVoxels);
        gamma = randn(1,nVoxels) + 1j * randn(1,nVoxels);
        %diffResponse = abs(gamma) .* cos(2*(angle(gamma)/2));
        %diff cR = 1
        for zNClasses=1:length(classRange)
            nClasses = classRange(zNClasses);
            nResponsesPerClass = nResponses/nClasses;
            assert(mod(nResponsesPerClass,1)==0);
            
            data = zeros(nResponses,nVoxels);
            labels = zeros(nResponses,1);
            
            % generate data
            theta = (0:nClasses-1)*(pi/nClasses);
            for zClasses=1:nClasses
                voxelResponse = (abs(gamma).* ...
                    cos(2*(angle(gamma)/2-theta(zClasses))));
                if CNR==0
                    voxelResponse = zeros(size(voxelResponse));
                end
                data((zClasses-1)*nResponsesPerClass+...
                    (1:nResponsesPerClass),:) = ...
                    bsxfun(@plus,voxelResponse(:)',...
                    randn(nResponsesPerClass,nVoxels) * ...
                    singleResponseNoiseLevel);
                
                labels((zClasses-1)*nResponsesPerClass+...
                    (1:nResponsesPerClass)) = zClasses;
            end
            % generate null-hypothesis data
            dataNull = randn(nResponses,nVoxels) * ...
                singleResponseNoiseLevel;
            
            % simulate MVPA
            f = fitcdiscr(data,labels,...
                'DiscrimType','diagLinear',...
                'CrossVal','on','SaveMemory','on');
            classPerf(zNVoxels,zCNR,zNClasses) =  ...
                1 - kfoldLoss(f,'lossfun','classiferror');
            fNull = fitcdiscr(dataNull,labels,...
                'DiscrimType','diagLinear',...
                'CrossVal','on','SaveMemory','on');
            classPerfNull(zNVoxels,zCNR,zNClasses) =  ...
                1 - kfoldLoss(fNull,'lossfun','classiferror');
            % permutation analysis
            nPerm = 1000;
            classPerfPerm = zeros(1,nPerm);
            for zPerm = 1:nPerm
                labelsPerm = labels(randperm(nResponses));
                
                fPerm = fitcdiscr(data,labelsPerm,...
                    'DiscrimType','diagLinear',...
                    'CrossVal','on','SaveMemory','on');
                classPerfPerm(zPerm) =  ...
                    1 - kfoldLoss(fPerm,'lossfun','classiferror');
            end
            decodingIsSignificant(zNVoxels,zCNR,zNClasses) = ...
                classPerf(zNVoxels,zCNR,zNClasses)>=...
                prctile(classPerfPerm,95);
        end
    end
end
toc;
save(fullfile(dataDir,...
    ['dataAllDecodingDetectionCNRnVoxels_permutation_' num2str(seedNo)]),...
    'decodingIsSignificant','classPerf','classPerfNull',...
    'classRange','cnrRange','nVoxelRange',...
    'seedNo');
end