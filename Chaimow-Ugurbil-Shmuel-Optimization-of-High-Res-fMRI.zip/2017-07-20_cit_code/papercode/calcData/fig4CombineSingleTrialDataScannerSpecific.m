function fig4CombineSingleTrialDataScannerSpecific
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

singleTrialsDir = fullfile(dataDir,'optimalVoxelSimulationTrials',...
    'fig4DataScannerSpecific');

%% load some data and set up
parameters = cit_masterParameterSetting;
area2DFlat = parameters.Aflat;

dataMVCNR = load(fullfile(dataDir,...
    'data_allDecodingDetectionCNRnVoxels'));

a = dir(fullfile(singleTrialsDir,'fig4dataScannerSpecific_*.mat'));
load(fullfile(singleTrialsDir,a(1).name));
nTrials = length(a);

%% initialize arrays
optVoxelCNR = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps));
optCNR      = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps));
optVoxelCor = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps));
optCor      = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps));

CNR = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
cor = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
CNRlow = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
corLow = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
pDetectMulti = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
pDetectMultiLow = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
pDetectSingle = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
pDetectSingleLow = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));

%% load individual trials data and average CNR and correlation
for z=1:nTrials
   data = load(fullfile(singleTrialsDir,a(z).name));   
   CNR  = CNR + data.CNR;
   CNRlow  = CNRlow + data.CNRlow;   
   cor = cor + data.cor;
   corLow = corLow + data.corLow;
end
CNR = CNR/nTrials;
CNRlow = CNRlow/nTrials;
cor = cor/nTrials;
corLow = corLow/nTrials;

nVoxels = repmat(...
    reshape(...
    area2DFlat./(wRange.^2),...
    [1 1 1 length(wRange)]),...
    [length(rhoRange) length(deltaRange) length(fwhmSteps) 1]);

%% calculate MVCNR
MVCNR = CNR.*nVoxels.^dataMVCNR.a;

%% calculate MVCNR
MVCNR = CNR.*nVoxels.^dataMVCNR.a;
MVCNRlow = CNRlow.*nVoxels.^dataMVCNR.a;

%% use fitted functions to compute MVPA quantities from MVCNR
pDetectSingle = detectionProbability(CNR,1);
pDetectSingleLow = detectionProbability(CNRlow,1);
pDetectMulti = detectionProbability(CNR,nVoxels);
pDetectMultiLow = detectionProbability(CNRlow,nVoxels);
pDetectMultiMVCNR = reshape(dataMVCNR.f_pDetect(MVCNR),size(MVCNR));
pDetectMultiMVCNRlow = reshape(dataMVCNR.f_pDetect(MVCNRlow),size(MVCNRlow));

for z=1:dataMVCNR.nClassRange
    rDecodeMVCNR{z} = ...
        reshape(dataMVCNR.f_meanClassPerf{z}(MVCNR),size(MVCNR));
    rDecodeMVCNRlow{z} = ...
        reshape(dataMVCNR.f_meanClassPerf{z}(MVCNRlow),size(MVCNRlow));
    pDecodeMVCNR{z} = ...
        reshape(dataMVCNR.f_pDecode{z}(MVCNR),size(MVCNR));
    pDecodeMVCNRlow{z} = ...
        reshape(dataMVCNR.f_pDecode{z}(MVCNRlow),size(MVCNRlow));
end

%% find optima
[optVoxelCNR,optCNR,optUniqueCNR] = findMax(CNR,wRange);
[optVoxelCNRlow,optCNRlow,optUniqueCNRlow] = findMax(CNRlow,wRange);

[optVoxelMVCNR,optMVCNR,optUniqueMVCNR] = findMax(MVCNR,wRange);
[optVoxelMVCNRlow,optMVCNRlow,optUniqueMVCNRlow] = findMax(MVCNRlow,wRange);

[optVoxelCor,optCor,optUniqueCor] = findMax(cor,wRange);
[optVoxelCorLow,optCorLow,optUniqueCorLow] = findMax(corLow,wRange);

[optVoxelPDetectSingle,optPDetectSingle,optUniquePDetectSingle] = ...
    findMax(pDetectSingle,wRange);
[optVoxelPDetectSingleLow,optPDetectSingleLow,optUniquePDetectSingleLow] = ...
    findMax(pDetectSingleLow,wRange);

[optVoxelPDetectMultiMVCNR,optPDetectMultiMVCNR,...
    optUniquePDetectMultiMVCNR] = findMax(pDetectMultiMVCNR,wRange);
[optVoxelPDetectMultiMVCNRlow,optPDetectMultiMVCNRlow,...
    optUniquePDetectMultiMVCNRlow] = findMax(pDetectMultiMVCNRlow,wRange);

[optVoxelPDetectMulti,optPDetectMulti,optUniquePDetectMulti] = ...
    findMax(pDetectMulti,wRange);
[optVoxelPDetectMultiLow,optPDetectMultiLow,optUniquePDetectMultiLow] = ...
    findMax(pDetectMultiLow,wRange);

for z=1:dataMVCNR.nClassRange
    [optVoxelRDecodeMVCNR{z},optRDecodeMVCNR{z},...
        optUniqueRDecodeMVCNR{z}] = findMax(rDecodeMVCNR{z},wRange);
    [optVoxelRDecodeMVCNRlow{z},optRDecodeMVCNRlow{z},...
        optUniqueRDecodeMVCNRlow{z}] = findMax(rDecodeMVCNRlow{z},wRange);

    [optVoxelPDecodeMVCNR{z},optPDecodeMVCNR{z},...
        optVoxelPDecodeMVCNR{z}] = findMax(pDecodeMVCNR{z},wRange);
    [optVoxelPDecodeMVCNRlow{z},optPDecodeMVCNRlow{z},...
        optVoxelPDecodeMVCNRlow{z}] = findMax(pDecodeMVCNRlow{z},wRange);
end

save(fullfile(dataDir,'data_optimalVoxelQuantitiesScannerSpecific'),...
    'deltaRange','rhoRange','fwhmSteps','wRange',...
    'optVoxelCNR','optCNR','optUniqueCNR',...
    'optVoxelMVCNR','optMVCNR','optUniqueMVCNR',...
    'optVoxelCor','optCor','optUniqueCor',...
    'optVoxelPDetectSingle','optPDetectSingle','optUniquePDetectSingle',...
    'optVoxelPDetectMulti','optPDetectMulti','optUniquePDetectMulti',...
    'optVoxelPDetectMultiMVCNR','optPDetectMultiMVCNR',...
                                           'optUniquePDetectMultiMVCNR',...
    'optVoxelRDecodeMVCNR','optRDecodeMVCNR','optUniqueRDecodeMVCNR',...
    'optVoxelPDecodeMVCNR','optPDecodeMVCNR','optVoxelPDecodeMVCNR',...
    'optVoxelCNRlow','optCNRlow','optUniqueCNRlow',...
    'optVoxelMVCNRlow','optMVCNRlow','optUniqueMVCNRlow',...
    'optVoxelCorLow','optCorLow','optUniqueCorLow',...
    'optVoxelPDetectSingleLow','optPDetectSingleLow','optUniquePDetectSingleLow',...
    'optVoxelPDetectMultiLow','optPDetectMultiLow','optUniquePDetectMultiLow',...
    'optVoxelPDetectMultiMVCNRlow','optPDetectMultiMVCNRlow',...
                                           'optUniquePDetectMultiMVCNRlow',...
    'optVoxelRDecodeMVCNRlow','optRDecodeMVCNRlow','optUniqueRDecodeMVCNRlow',...
    'optVoxelPDecodeMVCNRlow','optPDecodeMVCNRlow','optVoxelPDecodeMVCNRlow');
end

function [optVoxel, optVal, optUnique] = findMax(A,wRange)
sz = size(A);
AFlat = reshape(A,[],sz(end));
optVoxel = zeros(size(AFlat,1),1);
optVal = zeros(size(AFlat,1),1);
optUnique = zeros(size(AFlat,1),1);
for z=1:size(AFlat,1)
    optVal(z) = max(AFlat(z,:));
    optVoxel(z) = ...
    mean([wRange(find(AFlat(z,:)==optVal(z),1,'first')),...
        wRange(find(AFlat(z,:)==optVal(z),1,'last'))]);
    optUnique(z) = (length(find(AFlat(z,:)==optVal(z)))==1);
end
optVoxel = reshape(optVoxel,sz(1:end-1));
optVal = reshape(optVal,sz(1:end-1));
optUnique = reshape(optUnique,sz(1:end-1));
end