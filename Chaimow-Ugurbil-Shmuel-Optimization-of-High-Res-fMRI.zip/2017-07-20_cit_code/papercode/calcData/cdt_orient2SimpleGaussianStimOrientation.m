function [neuronal,orientPref,orientSpec] = ...
    cdt_orient2SimpleGaussianStimOrientation(...
    sim,rho,delta,stimOrient,noise)
% SIMULATES SINGLE CONDITION NEURONAL RESPONSE
if ~any(imag(noise(:)))
    error('noise needs to be complex');
end

%% Niebur and W?rg?tter (1993) model
fwfactor = 2*sqrt(2*log(2));
sim.r = sqrt(sim.k1.^2+sim.k2.^2);
if delta == 0
    FORIENTNotNormalized = abs(sim.r - rho)<sim.dk/2;
else
    % sum of Gaussians (positive and negative):
    FORIENTNotNormalized = normpdf(sim.r,rho,(rho * delta)/fwfactor) + ...
        normpdf(sim.r,-rho,(rho * delta)/fwfactor);
end
% normalization, such that single condition model produces average response
% of 1
C = (sqrt(cdt_meanpower(FORIENTNotNormalized)))*sqrt(pi/8);
FORIENT = FORIENTNotNormalized/C;
noiseF = dcfft2(noise,sim.dx);

gamma = dcifft2(FORIENT.*noiseF,sim.dk);
orientPref = angle(gamma)/2;
orientSpec = abs(gamma);

neuronal = orientSpec .* ((cos(2*(orientPref-stimOrient))+1)/2);
