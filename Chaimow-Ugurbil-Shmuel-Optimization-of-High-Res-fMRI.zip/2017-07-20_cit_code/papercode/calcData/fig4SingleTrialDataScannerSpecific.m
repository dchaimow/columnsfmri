function fig4SingleTrialDataScannerSpecific(zTrial,dataDir)
tic;

if ischar(zTrial)
    zTrial = str2double(zTrial);
end

mfileDir = fileparts(mfilename('fullpath'));
rootDir = fullfile(mfileDir,'..');

addpath(rootDir);
addpath(mfileDir);

if ~exist('dataDir','var') || isempty(dataDir)
    dataDir = fullfile(rootDir,'data');
end

% set parameters
parameters = cit_masterParameterSetting;
rng(parameters.randomNumberSeed+zTrial);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

downFactors = parameters.downFactors;
wRange = sim.L./(downFactors*sim.N);

nT = parameters.nT;
TR = parameters.TR;
sliceThickness = parameters.sliceThickness;

deltaRange = parameters.patternDependenceFigure.deltaRange;
rhoRange = parameters.patternDependenceFigure.rhoRange;

voxelV = sliceThickness.*wRange.^2;

differentialFlag = true;

noiseOfWSingleVoxel3T    = cit_noiseModel(voxelV,'3T',TR,1,nT,...
    differentialFlag);
noiseOfWSingleVoxel7T    = cit_noiseModel(voxelV,'7T',TR,1,nT,...
    differentialFlag);

betaRange = [parameters.beta3TGE parameters.beta7TGE parameters.beta7TSE];
fwhmSteps = [parameters.fwhm3TGE parameters.fwhm7TGE parameters.fwhm7TSE];
noiseOfWSingleVoxelRange = [...
    noiseOfWSingleVoxel3T; ...
    noiseOfWSingleVoxel7T; ...
    noiseOfWSingleVoxel7T];

CNR = zeros(...
    length(rhoRange),length(deltaRange),length(fwhmSteps),length(wRange));
CNRlow = zeros(...
    length(rhoRange),length(deltaRange),length(fwhmSteps),length(wRange));
cor = zeros(...
    length(rhoRange),length(deltaRange),length(fwhmSteps),length(wRange));
corLow = zeros(...
    length(rhoRange),length(deltaRange),length(fwhmSteps),length(wRange));

noise = cdt_noise2(sim);
for zRho = 1:length(rhoRange)
    rho = rhoRange(zRho);
    for zDelta = 1:length(deltaRange)
        delta = deltaRange(zDelta);
        neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
        for zScanner = 1:length(fwhmSteps)
            fwhm = fwhmSteps(zScanner);
            b = betaRange(zScanner);
            bold = cdt_bold2(sim,fwhm,b,neuronal);
            noiseOfWSingleVoxel = noiseOfWSingleVoxelRange(zScanner,:);            
            for zW = 1:length(wRange)
                w = wRange(zW);
                downFactor = sim.dx/w;
                [voxel,~] = cdt_mri2(sim,downFactor,bold);
                cR = std(voxel(:));
                
                CNR(zRho,zDelta,zScanner,zW) = ...
                    CNR(zRho,zDelta,zScanner,zW) + ...
                    cR/noiseOfWSingleVoxel(zW);
                CNRlow(zRho,zDelta,zScanner,zW) = ...
                    CNR(zRho,zDelta,zScanner,zW)/2;
                
                voxelNoise = voxel + ...
                    noiseOfWSingleVoxel(zW)*randn(size(voxel));
                voxelNoiseLow = voxel/2 + ...
                    noiseOfWSingleVoxel(zW)*randn(size(voxel));
                
                upVoxel = real(cit_upsample(voxelNoise,sim));
                upVoxelLow = real(cit_upsample(voxelNoiseLow,sim));
                
                c = corrcoef(neuronal(:),upVoxel(:));
                cLow = corrcoef(neuronal(:),upVoxelLow(:));
                
                cor(zRho,zDelta,zScanner,zW) = ...
                    cor(zRho,zDelta,zScanner,zW) + c(1,2);
                corLow(zRho,zDelta,zScanner,zW) = ...
                    corLow(zRho,zDelta,zScanner,zW) + cLow(1,2);
            end            
        end
    end
end

save(fullfile(dataDir,['fig4DataScannerSpecific_' num2str(zTrial)]),...
    'deltaRange','rhoRange','fwhmSteps',...
    'CNR','cor','CNRlow','corLow','wRange');
toc;
end