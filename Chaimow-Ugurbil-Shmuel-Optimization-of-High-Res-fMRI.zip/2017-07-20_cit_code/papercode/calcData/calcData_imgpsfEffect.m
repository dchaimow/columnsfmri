function calcData_imgpsfEffect(quadraticFlag)
if ~exist('quadraticFlag','var')
    quadraticFlag = false;
end
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

parameters = cit_masterParameterSetting;

nTrials = 32;

defaultTrd = 0.0278;
defaultTrdDouble = 2 * defaultTrd;

% set parameters
rng(parameters.randomNumberSeed);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

downFactors = parameters.downFactors;
wRange = sim.L./(downFactors*sim.N);

rho = parameters.rho;
delta = parameters.delta;


nT = parameters.nT;
TR = parameters.TR;
sliceThickness = parameters.sliceThickness;

noiseModel = '7T';

differentialFlag = true;
voxelV = sliceThickness.*wRange.^2;
noiseOfWSingleVoxel    = cit_noiseModel(...
    voxelV,noiseModel,TR,1,nT,differentialFlag);

nW =length(wRange);

GESErange = {'GE','SE'};
nGESE = length(GESErange);
crWithIMGPSFEffect = zeros(nTrials,nW,length(nGESE));

crWithoutIMGPSFEffect = zeros(nTrials,nW,length(nGESE));
crWithIMGPSFEffectDoubleTrd = zeros(nTrials,nW,length(nGESE));
crWithIMGPSFEffectPF = zeros(nTrials,nW,length(nGESE));
crWithIMGPSFEffectDoubleTrdPF = zeros(nTrials,nW,length(nGESE));

corWithoutIMGPSFEffect = zeros(nTrials,nW,length(nGESE));
corWithIMGPSFEffectDoubleTrd = zeros(nTrials,nW,length(nGESE));
corWithIMGPSFEffectPF = zeros(nTrials,nW,length(nGESE));
corWithIMGPSFEffectDoubleTrdPF = zeros(nTrials,nW,length(nGESE));


tic;
for zTrials = 1:nTrials
    noise = cdt_noise2(sim);
    neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
    
    for zGESE = 1:nGESE
        gese = GESErange{zGESE};
        if strcmpi(gese,'GE')
            fwhm = parameters.fwhm7TGE;
            b = parameters.beta7TGE;
            fwhmBOLDonly = 1.04; % from odcpsf
            
            
            
        elseif strcmpi(gese,'SE')
            fwhm = parameters.fwhm7TSE;
            b = parameters.beta7TSE;
            fwhmBOLDonly = 0.72; % from odcpsf
        end
        
        crTrialWithoutIMGPSFEffect = zeros(1,nW);
        crTrialWithIMGPSFEffect = zeros(1,nW);
        crTrialWithIMGPSFEffectDoubleTrd = zeros(1,nW);
        crTrialWithIMGPSFEffectPF = zeros(1,nW);
        crTrialWithIMGPSFEffectDoubleTrdPF = zeros(1,nW);
        
        corTrialWithoutIMGPSFEffect = zeros(1,nW);
        corTrialWithIMGPSFEffect = zeros(1,nW);
        corTrialWithIMGPSFEffectDoubleTrd = zeros(1,nW);
        corTrialWithIMGPSFEffectPF = zeros(1,nW);
        corTrialWithIMGPSFEffectDoubleTrdPF = zeros(1,nW);
        
        for zW = 1:length(wRange)
            w = wRange(zW);
            downFactor = sim.dx/w;
            
            % without imgpsf effect:
            bold = cdt_bold2(sim,fwhm,b,neuronal);
            [voxel,~] = cdt_mri2(sim,downFactor,bold);
            
            measurementNoise = randn(size(voxel)) * noiseOfWSingleVoxel(zW);
            
            crTrialWithoutIMGPSFEffect(zW) = std(voxel(:));
            corTrialWithoutIMGPSFEffect(zW) = ...
                calcCorrelation(sim,voxel,neuronal,b,measurementNoise);
            
            % with imgpsf effect:
            bold = cdt_bold2(sim,fwhmBOLDonly,b,neuronal);
            fwhmIMGPSF = ...
                imgPSFOfVoxel(w,gese,defaultTrd,false,quadraticFlag);
            fwhmIMGPSFDoubleTrd = ...
                imgPSFOfVoxel(w,gese,defaultTrdDouble,false,quadraticFlag);
            pfFlag = true;
            fwhmIMGPSFPF = ...
                imgPSFOfVoxel(w,gese,defaultTrd,pfFlag,quadraticFlag);
            fwhmIMGPSFDoubleTrdPF = ...
                imgPSFOfVoxel(w,gese,defaultTrdDouble,pfFlag,quadraticFlag);
            
            [voxel,~] = ...
                cdt_mri2_imgpsf(sim,downFactor,bold,fwhmIMGPSF);
            crTrialWithIMGPSFEffect(zW) = std(voxel(:));
            corTrialWithIMGPSFEffect(zW) = ...
                calcCorrelation(sim,voxel,neuronal,b,measurementNoise);
            
            [voxel,~] = ...
                cdt_mri2_imgpsf(sim,downFactor,bold,fwhmIMGPSFDoubleTrd);
            crTrialWithIMGPSFEffectDoubleTrd(zW) = std(voxel(:));
            corTrialWithIMGPSFEffectDoubleTrd(zW) = ...
                calcCorrelation(sim,voxel,neuronal,b,measurementNoise);
            
            [voxel,~] = ...
                cdt_mri2_imgpsf(sim,downFactor,bold,fwhmIMGPSFPF);
            crTrialWithIMGPSFEffectPF(zW) = std(voxel(:));
            corTrialWithIMGPSFEffectPF(zW) = ...
                calcCorrelation(sim,voxel,neuronal,b,measurementNoise);
            
            [voxel,~] = ...
                cdt_mri2_imgpsf(sim,downFactor,bold,fwhmIMGPSFDoubleTrdPF);
            crTrialWithIMGPSFEffectDoubleTrdPF(zW) = std(voxel(:));
            corTrialWithIMGPSFEffectDoubleTrdPF(zW) = ...
                calcCorrelation(sim,voxel,neuronal,b,measurementNoise);
        end
        crWithoutIMGPSFEffect(zTrials,:,zGESE) = crTrialWithoutIMGPSFEffect;
        crWithIMGPSFEffect(zTrials,:,zGESE) = ...
            crTrialWithIMGPSFEffect;
        crWithIMGPSFEffectDoubleTrd(zTrials,:,zGESE) = ...
            crTrialWithIMGPSFEffectDoubleTrd;
        crWithIMGPSFEffectPF(zTrials,:,zGESE) = ...
            crTrialWithIMGPSFEffectPF;
        crWithIMGPSFEffectDoubleTrdPF(zTrials,:,zGESE) = ...
            crTrialWithIMGPSFEffectDoubleTrdPF;
        corWithoutIMGPSFEffect(zTrials,:,zGESE) = corTrialWithoutIMGPSFEffect;
        corWithIMGPSFEffect(zTrials,:,zGESE) = ...
            corTrialWithIMGPSFEffect;
        corWithIMGPSFEffectDoubleTrd(zTrials,:,zGESE) = ...
            corTrialWithIMGPSFEffectDoubleTrd;
        corWithIMGPSFEffectPF(zTrials,:,zGESE) = ...
            corTrialWithIMGPSFEffectPF;
        corWithIMGPSFEffectDoubleTrdPF(zTrials,:,zGESE) = ...
            corTrialWithIMGPSFEffectDoubleTrdPF;
    end
    
end
toc;

cnrWithoutIMGPSFEffect = ...
    bsxfun(@rdivide,mean(crWithoutIMGPSFEffect,1),noiseOfWSingleVoxel);
cnrWithIMGPSFEffect = ...
    bsxfun(@rdivide,mean(crWithIMGPSFEffect,1),noiseOfWSingleVoxel);
cnrWithIMGPSFEffectDoubleTrd = ...
    bsxfun(@rdivide,mean(crWithIMGPSFEffectDoubleTrd,1),noiseOfWSingleVoxel);
cnrWithIMGPSFEffectPF = ...
    bsxfun(@rdivide,mean(crWithIMGPSFEffectPF,1),noiseOfWSingleVoxel);
cnrWithIMGPSFEffectDoubleTrdPF = ...
    bsxfun(@rdivide,mean(crWithIMGPSFEffectDoubleTrdPF,1),noiseOfWSingleVoxel);

corWithoutIMGPSFEffect = ...
  mean(corWithoutIMGPSFEffect,1);
corWithIMGPSFEffect = ...
  mean(corWithIMGPSFEffect,1);
corWithIMGPSFEffectDoubleTrd = ...
  mean(corWithIMGPSFEffectDoubleTrd,1);
corWithIMGPSFEffectPF = ...
  mean(corWithIMGPSFEffectPF,1);
corWithIMGPSFEffectDoubleTrdPF = ...
  mean(corWithIMGPSFEffectDoubleTrdPF,1);

fName = 'data_imgpsfEffect';
if quadraticFlag
    fName = [fName '_quadratic'];
end
    
save(fullfile(dataDir,fName),'cnrWithIMGPSFEffect',...
    'cnrWithoutIMGPSFEffect','cnrWithIMGPSFEffectDoubleTrd',...
    'cnrWithIMGPSFEffectPF','cnrWithIMGPSFEffectDoubleTrdPF',...
    'corWithIMGPSFEffect',...
    'corWithoutIMGPSFEffect','corWithIMGPSFEffectDoubleTrd',...
    'corWithIMGPSFEffectPF','corWithIMGPSFEffectDoubleTrdPF',...
    'wRange','GESErange');
end

function c = calcCorrelation(sim,voxel,neuronal,b,noise)
assert(isequal(size(noise),size(voxel)));
voxelNoise = voxel + noise;
upVoxel = real(upSample(voxelNoise,sim));
c = corrcoef(b*neuronal,upVoxel);
c = c(1,2);
end

function upPattern = upSample(pattern,sim)
Fy = fft2(pattern);
[m,n] = size(Fy); % size of the original matrix
nzsr = sim.N - m; % number of zero rows to add
nzsc = sim.N - n; % number of zero columns to add
% quadrants of the FFT, starting in the upper left
q1 = Fy(1:m/2,1:n/2);
q2 = Fy(1:m/2,n/2+1:n);
q3 = Fy(m/2+1:m,n/2+1:n);
q4 = Fy(m/2+1:m,1:n/2);
zpdr = zeros(nzsr,n/2);  % zeropad rows to insert
zpdc = zeros(nzsr+m,nzsc); % zeropad columns to insert
zpdFy = [ [q1;zpdr;q4] , zpdc , [q2;zpdr;q3] ]; % insert the zeros
upPattern = real(ifft2(zpdFy)) * sim.N^2/(m*n) ;
end