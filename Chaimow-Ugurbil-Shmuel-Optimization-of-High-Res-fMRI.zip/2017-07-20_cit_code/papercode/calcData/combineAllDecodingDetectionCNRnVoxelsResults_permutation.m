function combineAllDecodingDetectionCNRnVoxelsResults_permutation
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

a = dir(fullfile(dataDir,'decodingSimulationTrials',...
    'dataAllDecodingDetectionCNRnVoxels_permutation',...
    'dataAllDecodingDetectionCNRnVoxels_permutation_*.mat'));

classPerf = [];
classPerfNull = [];
decodingIsSignificant = [];
for z=1:length(a)
    data = load(fullfile(dataDir,'decodingSimulationTrials',...
        'dataAllDecodingDetectionCNRnVoxels_permutation',...
        a(z).name));
    classPerf = cat(4,classPerf,data.classPerf);
    classPerfNull = cat(4,classPerfNull,data.classPerfNull);
    decodingIsSignificant = ...
        cat(4,decodingIsSignificant,data.decodingIsSignificant);
end
classRange = data.classRange;
nClassRange = length(classRange);

meanClassPerf = mean(classPerf,4);
pDecode = mean(bsxfun(@ge,classPerf,prctile(classPerfNull,95,4)),4);
pDecodePermutation = mean(decodingIsSignificant,4);

nVoxelRange = data.nVoxelRange;
cnrRange = data.cnrRange;

nNVoxels = length(nVoxelRange);
nCNR = length(cnrRange);

pDetect = zeros(nNVoxels,nCNR);
for z=1:nNVoxels
    pDetect(z,:) = ...
        detectionProbability(cnrRange,nVoxelRange(z));
end

save(fullfile(dataDir,'data_allDecodingDetectionCNRnVoxels_permutation'));
end