function fy = dcfft2(y,dx)
N = size(y,1);
L = N * dx;
fy = (L^2/N^2)*fftshift(fft2(ifftshift(y)));