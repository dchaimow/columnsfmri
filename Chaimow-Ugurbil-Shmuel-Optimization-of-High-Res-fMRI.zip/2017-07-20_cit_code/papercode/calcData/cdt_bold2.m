function [by,psf,MTF]=cdt_bold2(sim,fwhm,beta,y)
if fwhm == 0
    by = beta * y;
    psf = [];
    MTF= ones(size(y));
else
    fwfactor = 2*sqrt(2*log(2));
    psf = beta * normpdf(sim.x1,0,fwhm/fwfactor).*...
        normpdf(sim.x2,0,fwhm/fwfactor);
    % normalize kernel (for numeric reasons)
    %psf = beta * psf./(sum(psf(:))*sim.dx^2);
    %MTF = real(dcfft2(psf,sim.dx));
    MTF = beta* exp(-(sim.k1.^2+sim.k2.^2)*2*(fwhm/fwfactor)^2*pi^2);
    by = dcifft2(MTF.*dcfft2(y,sim.dx),sim.dk);
end