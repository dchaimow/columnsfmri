function combineAllDecodingDetectionCNRnVoxelsResults_4curves
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

a = dir(fullfile(dataDir,'decodingSimulationTrials',...
    'dataAllDecodingDetectionCNRnVoxels_4curves',...
    'dataAllDecodingDetectionCNRnVoxels_4curves_*.mat'));

classPerf = [];
classPerfNull = [];
tDetect = [];
tDetectNull = [];
for z=1:length(a)
    data = load(fullfile(dataDir,'decodingSimulationTrials',...
        'dataAllDecodingDetectionCNRnVoxels_4curves',...
        a(z).name));
    classPerf = cat(4,classPerf,data.classPerf);
    classPerfNull = cat(4,classPerfNull,data.classPerfNull);
    tDetect = cat(3,tDetect,data.tDetect);
    tDetectNull = cat(3,tDetectNull,data.tDetectNull);
end
classRange = data.classRange;
nClassRange = length(classRange);

meanClassPerf = mean(classPerf,4);
pDecode = mean(bsxfun(@ge,classPerf,prctile(classPerfNull,95,4)),4);
pDetectSim = mean(bsxfun(@ge,tDetect,prctile(tDetectNull,95,3)),3);

nVoxelRange = data.nVoxelRange;
cnrRange = data.cnrRange;

nNVoxels = length(nVoxelRange);
nCNR = length(cnrRange);

pDetect = zeros(nNVoxels,nCNR);
for z=1:nNVoxels
    pDetect(z,:) = ...
        detectionProbability(cnrRange,nVoxelRange(z));
end

save(fullfile(dataDir,'data_allDecodingDetectionCNRnVoxels4curves'));
end