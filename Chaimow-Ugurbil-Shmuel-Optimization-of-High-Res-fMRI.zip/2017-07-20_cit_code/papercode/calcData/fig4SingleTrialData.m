function fig4SingleTrialData(zTrial,dataDir)
tic;
if ischar(zTrial)
    zTrial = str2double(zTrial);
end

mfileDir = fileparts(mfilename('fullpath'));
rootDir = fullfile(mfileDir,'..');

addpath(rootDir);
addpath(mfileDir);

if ~exist('dataDir','var') || isempty(dataDir)
    dataDir = fullfile(rootDir,'data');
end

% set parameters
parameters = cit_masterParameterSetting;
rng(parameters.randomNumberSeed+zTrial);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

downFactors = parameters.downFactors;
wRange = sim.L./(downFactors*sim.N);

b = parameters.beta7TGE;
nT = parameters.nT;
TR = parameters.TR;
sliceThickness = parameters.sliceThickness;
noiseModel = '7T';

fwhmSteps = parameters.patternDependenceFigure.fwhmSteps;
deltaRange = parameters.patternDependenceFigure.deltaRange;
rhoRange = parameters.patternDependenceFigure.rhoRange;

voxelV = sliceThickness.*wRange.^2;

differentialFlag = true;
noiseOfWSingleVoxel    = ...
    cit_noiseModel(voxelV,noiseModel,TR,1,nT,differentialFlag);

CNR = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
CNRlow = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
cor = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));
corLow = zeros(length(rhoRange),length(deltaRange),length(fwhmSteps),...
    length(wRange));

noise = cdt_noise2(sim);
for zRho = 1:length(rhoRange)
    rho = rhoRange(zRho);
    for zDelta = 1:length(deltaRange)
        delta = deltaRange(zDelta);
        neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
        for zFwhm = 1:length(fwhmSteps)
            fwhm = fwhmSteps(zFwhm);
            bold = cdt_bold2(sim,fwhm,b,neuronal);
            for zW = 1:length(wRange)
                w = wRange(zW);
                downFactor = sim.dx/w;
                [voxel,~] = cdt_mri2(sim,downFactor,bold);
                cR = std(voxel(:));
                
                CNR(zRho,zDelta,zFwhm,zW) = ...
                    CNR(zRho,zDelta,zFwhm,zW) + ...
                    cR/noiseOfWSingleVoxel(zW);              
                CNRlow(zRho,zDelta,zFwhm,zW) = ...
                    CNR(zRho,zDelta,zFwhm,zW)/2;
                
                voxelNoise = voxel + ...
                    noiseOfWSingleVoxel(zW)*randn(size(voxel));
                voxelNoiseLow = voxel/2 + ...
                    noiseOfWSingleVoxel(zW)*randn(size(voxel));
                
                upVoxel = real(cit_upsample(voxelNoise,sim));
                upVoxelLow = real(cit_upsample(voxelNoiseLow,sim));
 
                c = corrcoef(neuronal(:),upVoxel(:));
                cLow = corrcoef(neuronal(:),upVoxelLow(:));
                               
                cor(zRho,zDelta,zFwhm,zW) = ...
                    cor(zRho,zDelta,zFwhm,zW) + c(1,2);
                corLow(zRho,zDelta,zFwhm,zW) = ...
                    corLow(zRho,zDelta,zFwhm,zW) + cLow(1,2);
            end
        end
    end
end
  
save(fullfile(dataDir,['fig4Data_' num2str(zTrial)]),...
    'deltaRange','rhoRange','fwhmSteps',...
    'CNR','cor','CNRlow','corLow','wRange');
toc;
end