function calcData_cnrAsIntegration
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

nTrials = 32;

% set parameters
parameters = cit_masterParameterSetting;
rng(parameters.randomNumberSeed);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

downFactors = parameters.downFactors;
wRange = sim.L./(downFactors*sim.N);

rho = parameters.rho;
delta = parameters.delta;
fwhm = parameters.fwhm7TGE;
b = parameters.beta7TGE;

cr = zeros(1,length(wRange));
nK = ceil(2.4 * rho/sim.dk);
neuronalSpectrum = zeros(nK,1);
boldSpectrum = zeros(nK,1);

for zTrials = 1:nTrials
    fprintf('%d ',zTrials);
    noise = cdt_noise2(sim);
    neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
    [bold,~,MTF] = cdt_bold2(sim,fwhm,b,neuronal);

    [neuronalSpectrumTrial,~] = ...
        cdt_calcSpectrum(sim,neuronal,nK);
    [boldSpectrumTrial,spectrumK] = cdt_calcSpectrum(sim,bold,nK);
    neuronalSpectrum = neuronalSpectrum + neuronalSpectrumTrial;
    boldSpectrum = boldSpectrum + boldSpectrumTrial;
    for zW = 1:length(wRange)
        w = wRange(zW);
        downFactor = sim.dx/w;
        [voxel,~] = cdt_mri2(sim,downFactor,bold);
    cr(zW) = cr(zW) + std(voxel(:));
    end
end
fprintf('\n');
cr = cr/nTrials;
neuronalSpectrum = neuronalSpectrum/nTrials;
boldSpectrum = boldSpectrum/nTrials;
mtfSpectrum = cdt_calcSpectrumFromKSpace(sim,MTF,nK);

kRange = 1./wRange;
kVoxel1 = kRange(wRange==4)/2;       %4   mm
kVoxel2 = kRange(wRange==2)/2;       %2   mm
kVoxel3 = kRange(wRange==1)/2;       %1   mm
kVoxel4 = kRange(wRange==0.5)/2;     %0.5 mm 

voxelFilter1 = (abs(sim.k1)<=kVoxel1) & (abs(sim.k2)<=kVoxel1);
voxelFilter2 = (abs(sim.k1)<=kVoxel2) & (abs(sim.k2)<=kVoxel2);
voxelFilter3 = (abs(sim.k1)<=kVoxel3) & (abs(sim.k2)<=kVoxel3);
voxelFilter4 = (abs(sim.k1)<=kVoxel4) & (abs(sim.k2)<=kVoxel4);
voxelSpectrum1 = cdt_calcSpectrumFromKSpace(sim,voxelFilter1,nK,1);
voxelSpectrum2 = cdt_calcSpectrumFromKSpace(sim,voxelFilter2,nK,1);
voxelSpectrum3 = cdt_calcSpectrumFromKSpace(sim,voxelFilter3,nK,1);
voxelSpectrum4 = cdt_calcSpectrumFromKSpace(sim,voxelFilter4,nK,1);
maxVoxelSpectrum = max(voxelSpectrum1);

save(fullfile(dataDir,'data_cnrAsIntegration'),...
    'spectrumK', ...
    'neuronalSpectrum', ...
    'mtfSpectrum', ...
    'boldSpectrum','voxelSpectrum1', ...
    'voxelSpectrum2', ...
    'voxelSpectrum3', ...
    'voxelSpectrum4', ...
    'maxVoxelSpectrum', ...
    'kVoxel1', ...
    'kVoxel2', ...
    'kVoxel3', ...
    'kVoxel4', ...
    'kRange', ...
    'rho', ...
    'b', ...
    'cr');
end