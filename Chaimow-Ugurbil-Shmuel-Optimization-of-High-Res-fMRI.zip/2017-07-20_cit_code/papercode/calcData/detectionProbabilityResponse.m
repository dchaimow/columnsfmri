function p = detectionProbabilityResponse(rnr)
% rnr = response/noise ratio in single voxel
lambda = rnr.^2;
N = 1;
alpha = 0.05;
    
x_crit = chi2inv(1-alpha,N); 
p = ncx2cdf(x_crit,N,lambda,'upper');

end

