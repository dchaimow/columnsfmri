function p=cdt_meanpower(s)
p = mean(abs(s(:)).^2);
end