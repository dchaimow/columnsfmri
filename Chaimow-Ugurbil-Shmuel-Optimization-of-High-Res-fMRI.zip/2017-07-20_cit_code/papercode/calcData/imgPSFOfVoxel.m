function imgPSFFWHM = imgPSFOfVoxel(w,gese,defaultTrd,pfFlag,quadraticFlag)
% returns img psf width as estimated using a Gaussian blurring model
% for ge or se
% assuming a default total read out duration of 0.5 mm voxels
% and calculating total read out duration of other voxel size by
% considering increases or increases in the number of phase encode lines
% uses the true total read out duration for partial fourier

defaultVoxelSize = 0.5;

if ~exist('defaultTrd','var')
    defaultTrd = 0.0278;
end

if ~exist('pfFlag','var')
    pfFlag = false;
end

imgPSFFWHM = zeros(size(w));
for z=1:numel(w)
    if exist('quadraticFlag','var') && quadraticFlag
        trdForVoxelSize = (defaultVoxelSize/w(z))^2 * defaultTrd;
    else
        trdForVoxelSize = (defaultVoxelSize/w(z)) * defaultTrd;
    end
    imgPSFFWHMVoxelsForVoxelSize = ...
        imgPSFOfTrdFWHMVoxels(trdForVoxelSize,gese,pfFlag);
    imgPSFFWHM(z) = imgPSFFWHMVoxelsForVoxelSize * w(z);
end
42;
end

function [fwhm,a] = imgPSFOfTrdFWHMVoxels(trd,gese,pfFlag)
load('~/imgpsf/Matlab/data/allData.mat','trdRange','fwhmgf',...
    'GESErange','pfRange','defaultTrdValue','MTFgf');

%MTFgf(:,zGESE,zPF,zTrd)

imgpsfOfTrdFWHMVoxelsGEdata = ...
    squeeze(fwhmgf(find(strcmp(GESErange,'GE')),...
    find(strcmp(pfRange,'none')),:));
aOfTrdFWHMVoxelsGEdata = ...
    squeeze(MTFgf(1,find(strcmp(GESErange,'GE')),...
    find(strcmp(pfRange,'none')),:));

imgpsfOfTrdFWHMVoxelsSEdata = ...
    squeeze(fwhmgf(find(strcmp(GESErange,'SE')),...
    find(strcmp(pfRange,'none')),:));
aOfTrdFWHMVoxelsSEdata = ...
    squeeze(MTFgf(1,find(strcmp(GESErange,'SE')),...
    find(strcmp(pfRange,'none')),:));

imgpsfOfTrdFWHMVoxelsGEdataPF = ...
    squeeze(fwhmgf(find(strcmp(GESErange,'GE')),...
    find(strcmp(pfRange,'earlyZero')),:));
aOfTrdFWHMVoxelsGEdataPF = ...
    squeeze(MTFgf(1,find(strcmp(GESErange,'GE')),...
    find(strcmp(pfRange,'earlyZero')),:));

imgpsfOfTrdFWHMVoxelsSEdataPF = ...
    squeeze(fwhmgf(find(strcmp(GESErange,'SE')),...
    find(strcmp(pfRange,'earlyZero')),:));
aOfTrdFWHMVoxelsSEdataPF = ...
    squeeze(MTFgf(1,find(strcmp(GESErange,'SE')),...
    find(strcmp(pfRange,'earlyZero')),:));


%imgpsfOfTrdFWHMVoxelsGEdata = [0.0071,-0.0551,-0.1101,-0.1649,-0.2194,...
%    -0.2736,-0.3273,-0.3805,-0.4331,-0.4851,-0.5364,-0.5870,-0.5931,...
%    -0.6370,-0.6863,-0.7348,-0.7827,-0.8299,-0.8765,-0.9225,-0.9678,...
%    -1.0127];

%imgpsfOfTrdFWHMVoxelsSEdata = [0.0071,0.2655,0.3755,0.4599,0.5312,...
%    0.5940,0.6510,0.7034,0.7524,0.7985,0.8423,0.8841,0.8890,0.9243,...
%    0.9629,1.0004,1.0367,1.0721,1.1067,1.1405,1.1737,1.2063];

%trdRange = [0,0.0025,0.0050,0.0075,0.0100,0.0125,0.0150,0.0175,0.0200,...
%    0.0225,0.0250,0.0275,0.0278,0.0300,0.0325,0.0350,0.0375,0.0400,...
%    0.0425,0.0450,0.0475,0.0500];

if strcmpi(gese,'GE')
    if exist('pfFlag','var') && pfFlag
        imgpsfOfTrdFWHMVoxelsData = imgpsfOfTrdFWHMVoxelsGEdataPF;
        trd = trd * (4/3);
    else
        imgpsfOfTrdFWHMVoxelsData = imgpsfOfTrdFWHMVoxelsGEdata;
    end
elseif strcmpi(gese,'SE')
    if exist('pfFlag','var') && pfFlag
        imgpsfOfTrdFWHMVoxelsData = imgpsfOfTrdFWHMVoxelsSEdataPF;
         trd = trd * (4/3);
    else     
        imgpsfOfTrdFWHMVoxelsData = imgpsfOfTrdFWHMVoxelsSEdata;
    end
else
    error('use GE or SE');
end
fwhm = interp1(trdRange,imgpsfOfTrdFWHMVoxelsData,trd);
end