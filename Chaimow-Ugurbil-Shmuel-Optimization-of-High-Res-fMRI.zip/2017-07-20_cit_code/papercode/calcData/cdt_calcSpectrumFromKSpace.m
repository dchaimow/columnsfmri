function [s,k] = cdt_calcSpectrumFromKSpace(sim,FY,nK,noSquare)
% power spectrum
nPhi = length(sim.x);
if exist('noSquare','var') & noSquare
    plFY = abs(resampleCart2Polar(FY,nK,nPhi));
else
    plFY = abs(resampleCart2Polar(FY,nK,nPhi)).^2;
end
    k = 0:sim.dk:((nK-1)*sim.dk);
s = mean(plFY,2)/(sim.dk).^2; %averaged over all directions
%s = mean(plFY,2).*(2*pi*k');  %integrated over all directions
end 
    
    
    
    
 
    
    
function plIm = resampleCart2Polar(im,nR,nPhi)
x0 = ceil((size(im,1)+1)/2);
y0 = ceil((size(im,2)+1)/2);
r0 = 1;
r = @(x,y) sqrt((x-x0).^2+(y-y0).^2) + r0;
phi = @(x,y) (atan2(y-y0,x-x0)+pi)*((nPhi-1)/(2*pi))+1;

x = @(r,phi) x0+(r-r0).*cos((phi-1)*((2*pi)/(nPhi-1))-pi);
y = @(r,phi) y0+(r-r0).*sin((phi-1)*((2*pi)/(nPhi-1))-pi);

bwfunc = @(U,T) [x(U(:,1),U(:,2)) y(U(:,1),U(:,2))];
fwfunc = @(X,T) [r(X(:,1),X(:,2)) phi(X(:,1),X(:,2))];

tform = maketform('custom',2,2,fwfunc,bwfunc,[]);
R = makeresampler('nearest', 'fill');
plIm = tformarray(im, tform, R,[1 2],[1 2],[nR nPhi],[], 0);
end