function simulateAllDecodingDetectionCNRnVoxels_4curves(seedNo,dataDir)
tic;
if ischar(seedNo)
    seedNo = str2double(seedNo);
end

mfileDir = fileparts(mfilename('fullpath'));
rootDir = fullfile(mfileDir,'..');

addpath(rootDir);
addpath(mfileDir);

if ~exist('dataDir','var') || isempty(dataDir)
    dataDir = fullfile(rootDir,'data');
end

cnrRange = [0:0.02:0.3 0.34:0.04:0.5 0.6:0.1:1.5 1.75:0.25:5 5.5:0.5:8 ...
    9:1:14 16:2:18 20:5:40];
nVoxelRange = [1 10 100 1000];

nCNR = length(cnrRange);
nNVoxels = length(nVoxelRange);


% measurement and response blocks
parameters = cit_masterParameterSetting;

nMeasurements = parameters.nT;

nMeasurementsPerResponse = 5;
nResponses = nMeasurements/nMeasurementsPerResponse;
assert(mod(nResponses,1)==0);

classRange = [2,4,8];

classPerf = zeros(nNVoxels,nCNR,length(classRange));
classPerfNull = zeros(nNVoxels,nCNR,length(classRange));
tDetect = zeros(nNVoxels,nCNR);
tDetectNull = zeros(nNVoxels,nCNR);
rng(seedNo);
for zCNR=1:nCNR
    CNR = cnrRange(zCNR);
    % assume single response to be 1
    singleResponseCNR = ...
        translateDifferentialMultiMeasurementCNRtoSingleResponseCNR(CNR,nResponses);
    singleResponseNoiseLevel = 1/singleResponseCNR;
    if CNR==0
        singleResponseNoiseLevel = 1;
    end
    for zNVoxels=1:nNVoxels
        nVoxels = nVoxelRange(zNVoxels);
        gamma = randn(1,nVoxels) + 1j * randn(1,nVoxels);
        %diffResponse = abs(gamma) .* cos(2*(angle(gamma)/2));
        %diff cR = 1
        for zNClasses=1:length(classRange)
            nClasses = classRange(zNClasses);
            nResponsesPerClass = nResponses/nClasses;
            assert(mod(nResponsesPerClass,1)==0);
            
            data = zeros(nResponses,nVoxels);
            labels = zeros(nResponses,1);
            
            % generate data
            theta = (0:nClasses-1)*(pi/nClasses);
            for zClasses=1:nClasses
                voxelResponse = (abs(gamma).* ...
                    cos(2*(angle(gamma)/2-theta(zClasses))));
                if CNR==0
                    voxelResponse = zeros(size(voxelResponse));
                end
                data((zClasses-1)*nResponsesPerClass+...
                    (1:nResponsesPerClass),:) = ...
                    bsxfun(@plus,voxelResponse(:)',...
                    randn(nResponsesPerClass,nVoxels) * ...
                    singleResponseNoiseLevel);
                
                labels((zClasses-1)*nResponsesPerClass+...
                    (1:nResponsesPerClass)) = zClasses;
            end
            % generate null-hypothesis data
            dataNull = randn(nResponses,nVoxels) * ...
                singleResponseNoiseLevel;
            
            % simulate MVPA
            f = fitcdiscr(data,labels,...
                'DiscrimType','diagLinear',...
                'CrossVal','on','SaveMemory','on');
            classPerf(zNVoxels,zCNR,zNClasses) =  ...
                1 - kfoldLoss(f,'lossfun','classiferror');
            fNull = fitcdiscr(dataNull,labels,...
                'DiscrimType','diagLinear',...
                'CrossVal','on','SaveMemory','on');
            classPerfNull(zNVoxels,zCNR,zNClasses) =  ...
                1 - kfoldLoss(fNull,'lossfun','classiferror');
            if nClasses==2
                tDetect(zNVoxels,zCNR) = sum((...
                    mean(data(labels==1,:),1)-...
                    mean(data(labels==2,:),1)).^2);
                tDetectNull(zNVoxels,zCNR) = sum((...
                    mean(dataNull(labels==1,:),1)-...
                    mean(dataNull(labels==2,:),1)).^2);
            end
        end
    end
end
save(fullfile(dataDir,...
    ['dataAllDecodingDetectionCNRnVoxels_4curves_' num2str(seedNo)]),...
    'classPerf','classPerfNull','classRange','cnrRange','nVoxelRange',...
    'tDetect','tDetectNull','seedNo');
toc;
end