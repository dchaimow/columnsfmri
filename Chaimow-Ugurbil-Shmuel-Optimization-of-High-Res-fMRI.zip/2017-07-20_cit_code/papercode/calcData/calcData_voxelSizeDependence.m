function calcData_voxelSizeDependence
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

parameters = cit_masterParameterSetting;

nTrials = 32;

% set parameters
rng(parameters.randomNumberSeed);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

downFactors = parameters.downFactors;
wRange = sim.L./(downFactors*sim.N);

rho = parameters.rho;
delta = parameters.delta;
fwhm = parameters.fwhm7TSE;
b = parameters.beta7TSE;
nT = parameters.nT;

TR = parameters.TR;
sliceThickness = parameters.sliceThickness;
area2DFlat = parameters.Aflat;
Volume3DIsoHemi = parameters.Vhemi;

noiseModel = '7T';

differentialFlag = true;

voxelV = sliceThickness.*wRange.^2;
voxelVIso = wRange.^3;

noiseOfWSingleVoxel    = cit_noiseModel(...
    voxelV,noiseModel,TR,1,nT,differentialFlag);
noiseOfWSingleVoxelIso  = cit_noiseModel(...
    voxelVIso,noiseModel,TR,1,nT,differentialFlag);

noiseOfWSingleVoxelFewData    = cit_noiseModel(...
    voxelV,noiseModel,TR,1,nT/10,differentialFlag);
noiseOfWSingleVoxelMuchData    = cit_noiseModel(...
    voxelV,noiseModel,TR,1,nT*10,differentialFlag);

nVoxels = area2DFlat./(wRange.^2);
nVoxelsIso = Volume3DIsoHemi./voxelVIso;

nW =length(wRange);

cr = zeros(1,length(wRange));
cor1 = zeros(1,length(wRange));
cor2 = zeros(1,length(wRange));
cor3 = zeros(1,length(wRange));
cor0 = zeros(1,length(wRange));

parfor zTrials = 1:nTrials
    rng(parameters.randomNumberSeed+zTrials);
    noise = cdt_noise2(sim);
    neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
    bold = cdt_bold2(sim,fwhm,b,neuronal);
        
    crTrial = zeros(1,nW);
    cor1Trial = zeros(1,nW);
    cor2Trial = zeros(1,nW);
    cor3Trial = zeros(1,nW);
    cor0Trial = zeros(1,nW);
    
    for zW = 1:length(wRange)
        w = wRange(zW);
        downFactor = sim.dx/w;
        [voxel,~] = cdt_mri2(sim,downFactor,bold);
        crTrial(zW) = std(voxel(:));

        measurementNoise = randn(size(voxel));
        
        voxelNoise = voxel + noiseOfWSingleVoxel(zW)*measurementNoise;
        upVoxel = real(upSample(voxelNoise,sim));
        c = corrcoef(b*neuronal,upVoxel);
        cor2Trial(zW) = c(1,2);
        
        voxelNoise = voxel + noiseOfWSingleVoxelFewData(zW)*measurementNoise;
        upVoxel = real(upSample(voxelNoise,sim));
        c = corrcoef(b*neuronal,upVoxel);
        cor1Trial(zW) = c(1,2);
        
        voxelNoise = voxel + noiseOfWSingleVoxelMuchData(zW)*measurementNoise;
        upVoxel = real(upSample(voxelNoise,sim));
        c = corrcoef(b*neuronal,upVoxel);
        cor3Trial(zW) = c(1,2);
        
        upVoxel = real(upSample(voxel,sim));
        c = corrcoef(b*neuronal,upVoxel);
        cor0Trial(zW) = c(1,2);
    end
    cr(zTrials,:) = crTrial;
    cor1(zTrials,:) = cor1Trial;
    cor2(zTrials,:) = cor2Trial;
    cor3(zTrials,:) = cor3Trial;
    cor0(zTrials,:) = cor0Trial;
end

cr = mean(cr,1);
cor1 = mean(cor1,1);
cor2 = mean(cor2,1);
cor3 = mean(cor3,1);
cor0 = mean(cor0,1);

cnr = cr./noiseOfWSingleVoxel;
cnrFew = cr./noiseOfWSingleVoxelFewData;
cnrMuch = cr./noiseOfWSingleVoxelMuchData;
cnrIso = cr./noiseOfWSingleVoxelIso;

snr2D = 1./noiseOfWSingleVoxel;
snrIso = 1./noiseOfWSingleVoxelIso;

snr = 1./noiseOfWSingleVoxel;

[maxCNR,idxCNR] = max(cnr);
[maxCNRFew,idxCNRFew] = max(cnrFew);
[maxCNRMuch,idxCNRMuch] = max(cnrMuch);
[maxCR,idxCR] = max(cr);
[maxSNR,idxSNR] = max(snr);

[maxCor1,idxCor1] = max(cor1);
[maxCor2,idxCor2] = max(cor2);
[maxCor3,idxCor3] = max(cor3);
[maxCor,~] = max([maxCor1 maxCor2 maxCor3]);

save(fullfile(dataDir,'data_voxelSizeDependence'),...
    'wRange', ...
    'nVoxels', ...
    'nVoxelsIso',...
    'noiseOfWSingleVoxel', ...
    'noiseOfWSingleVoxelIso', ...    
    'noiseOfWSingleVoxelFewData', ...
    'noiseOfWSingleVoxelMuchData', ...
    'cr', ...
    'cnr', ...
    'cnrIso', ...
    'cnrMuch', ...
    'cnrFew', ...
    'nT', ...
    'maxCor', ...
    'idxCor1', ...
    'idxCor2', ...
    'idxCor3', ...
    'maxCNR', ...
    'maxCNRFew', ...
    'maxCNRMuch', ...
    'idxCNR', ...
    'idxCNRFew', ...
    'idxCNRMuch', ...
    'maxCR', ...
    'idxCR', ...
    'maxSNR', ...
    'idxSNR', ...
    'cor0', ...
    'cor1', ...
    'cor2', ...
    'cor3',...
    'snr2D',...
    'snrIso');
end

function upPattern = upSample(pattern,sim)
Fy = fft2(pattern);
[m,n] = size(Fy); % size of the original matrix
nzsr = sim.N - m; % number of zero rows to add
nzsc = sim.N - n; % number of zero columns to add
% quadrants of the FFT, starting in the upper left
q1 = Fy(1:m/2,1:n/2);
q2 = Fy(1:m/2,n/2+1:n);
q3 = Fy(m/2+1:m,n/2+1:n);
q4 = Fy(m/2+1:m,1:n/2);
zpdr = zeros(nzsr,n/2);  % zeropad rows to insert
zpdc = zeros(nzsr+m,nzsc); % zeropad columns to insert
zpdFy = [ [q1;zpdr;q4] , zpdc , [q2;zpdr;q3] ]; % insert the zeros
upPattern = real(ifft2(zpdFy)) * sim.N^2/(m*n) ;
end