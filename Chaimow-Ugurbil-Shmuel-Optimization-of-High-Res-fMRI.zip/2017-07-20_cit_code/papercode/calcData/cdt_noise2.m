function y = cdt_noise2(sim)
y = randn(sim.N,sim.N);

