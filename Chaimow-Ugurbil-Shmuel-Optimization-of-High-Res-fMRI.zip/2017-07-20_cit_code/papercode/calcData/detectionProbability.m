function p = detectionProbability(cnr,N)
if numel(cnr)>1
    p = zeros(size(cnr));
    if numel(N)==1
        N = ones(size(cnr)) * N;
    end    
    for z=1:numel(cnr)
        p(z) = detectionProbability(cnr(z),N(z));
    end
else
    
    
    
    alpha = 0.05;
    x_crit = chi2inv(1-alpha,N);
    a = N/2;
    b = 2*(1+cnr^2);
    p = gamcdf(x_crit,a,b,'upper');
end
% gammacdf results from the following prior integration:
% p = integral2(@f,0,Inf,x_crit,Inf)/(cnr^2);
% 
%     function y = f(lambda,x)
%         y = ncx2pdf(x,N,lambda).*chi2pdf(lambda./cnr.^2,N);
%     end
end


function t = testStatAtLeastOneOneSided(alpha,N)
t = icdf(makedist('normal','mu',0,'sigma',1),(1-alpha)^(1/N));
end

function t = testStatAtLeastOneTwoSided(alpha,N)
t = icdf(makedist('normal','mu',0,'sigma',1),((1-alpha)^(1/N)+1)/2);
end

function alpha = alphaAtLeastOneTwoSided(threshold,N)
alpha = 1-(2*cdf(makedist('normal','mu',0,'sigma',1),threshold)-1)^N;
end

function alpha = alphaAtLeastOneOneSided(threshold,N)
alpha = 1-(cdf(makedist('normal','mu',0,'sigma',1),threshold))^N;
end

function p = pDetectAtLeastOne(cnr,tcrit,N)
nTest = 10000;
r = randn(nTest,N)*cnr;
r = r + randn(nTest,N);
p = mean(any(abs(r)>tcrit,2));
end

function p = pDetectMultivariate(cnr,tcrit,N)
lambda = cnr.^2 .* N;
p = 1 - ncx2cdf(tcrit,N,lambda);
end


function t = testStatChiSqOneSided(alpha,N)
t = ncx2inv(1-alpha,N,0);
end


function p = pDetect(crnr,tcrit)
p = zeros(size(crnr));
for z=1:length(crnr)
    p(z) = integral(@(cnr) pDetectR(cnr,tcrit).*...
        normpdf(cnr,0,crnr(z)),-Inf,Inf);
end
end

function p = pDetectR(cnr,tcrit)
p = (1/2) * (1+erf((cnr-tcrit)/sqrt(2))+erfc((cnr+tcrit)/sqrt(2)));
end

function t = testStatNormOneSided(alpha)
t = icdf(makedist('normal','mu',0,'sigma',1),1-alpha);
end

function t = testStatNormTwoSided(alpha)
t = icdf(makedist('normal','mu',0,'sigma',1),1-alpha/2);
end

