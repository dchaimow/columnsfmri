function [my,vSize] = cdt_mri2(sim,downFactor,y)
% downFactor between 0 and 1
L = sim.L;
% here N is defined, so that 2N covers the FOV in one dim
N = ceil(sim.N * downFactor * 0.5);
vSize = L/(2*N);

centerk = find(sim.k == 0);

yk = dcfft2(y,sim.dx);
downSampledY = yk(centerk-N:centerk+N-1,centerk-N:centerk+N-1);
my = real(fftshift(ifft2(ifftshift(downSampledY))))/vSize^2;



