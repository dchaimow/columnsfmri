function f = fitCDFModel(x,y,y0,cdf)
ft = fittype(...
    @(a,b,x) y0+(cdf(x,a,b)-cdf(0,a,b))*(1-y0),...
    'independent','x','dependent','y');

f = fit(x,y,ft,'Lower',[0 0]);
end