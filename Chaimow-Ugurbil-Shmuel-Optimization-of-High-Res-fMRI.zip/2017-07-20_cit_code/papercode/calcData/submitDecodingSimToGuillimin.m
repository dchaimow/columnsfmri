function submitDecodingSimToGuillimin(zTrial)
jobFolder = 'allDecodingDetectionCNRnVoxels';
codeFolder = 'allDecodingDetectionCNRnVoxels';
writeSubmissionScript(zTrial,jobFolder,codeFolder);

system(['scp ' fullfile(['myBatchFile_' num2str(zTrial) '.sh']) ...
    ' dchaimow@guillimin-p2.hpc.mcgill.ca:' ...
    fullfile('/sb/project/ngt-630-aa/denis/',jobFolder,...
    ['myBatchFile_' num2str(zTrial) '.sh'])]);

% submit job
disp(['submitting job number ' num2str(zTrial)]) 
system(['ssh dchaimow@guillimin-p2.hpc.mcgill.ca "qsub ' ...
    fullfile('/sb/project/ngt-630-aa/denis/',jobFolder,...
    ['myBatchFile_' num2str(zTrial) '.sh']) '"']);
delete(['myBatchFile_' num2str(zTrial) '.sh']);
end

function writeSubmissionScript(zTrial,jobFolder,codeFolder)

wallTimeInSec = 5*3600;
timeStr = datestr(wallTimeInSec/86400,'DD:HH:MM:SS');

runCommand = 'run_simulateAllDecodingDetectionCNRnVoxels.sh';
jobName = ['decSim_' num2str(zTrial)];

str0 =  '#!/bin/bash';
str1 =  '#PBS -A ngt-630-aa';
str2 = ['#PBS -N ' jobName];
str3 =  '#PBS -l nodes=1:ppn=1';

str4 =  '#PBS -l pmem=3gb';
str5 = ['#PBS -l walltime=' timeStr];
str6 = ['#PBS -o /sb/project/ngt-630-aa/denis/' jobFolder '/'...
    num2str(zTrial) '.out']; 
str7 = ['#PBS -e /sb/project/ngt-630-aa/denis/' jobFolder '/'...
    num2str(zTrial) '.err']; 
str8 =  '';
str9=  'export MATLAB=/software/CentOS-6/applications/matlab-2016a';
str10=  'export PATH=$PATH:$MATLAB/bin';
str11=  ['cd /sb/project/ngt-630-aa/denis/' jobFolder];
str12=  ['$HOME/matlab/' codeFolder '/' runCommand ' ' ...
    '$MATLAB ' num2str(zTrial) ' .' ...
    '  >> output_' num2str(zTrial) '.out 2>&1'];
str = [str0 '\n' str1 '\n' str2 '\n' str3 '\n' str4 '\n' str5 '\n' str6 ...
    '\n' str7 '\n' str8 '\n' str9 '\n' str10 '\n' str11 '\n' str12 '\n'];

fid = fopen(fullfile(['myBatchFile_' num2str(zTrial) '.sh']),'w');
fprintf(fid, str);
fclose(fid);
end
