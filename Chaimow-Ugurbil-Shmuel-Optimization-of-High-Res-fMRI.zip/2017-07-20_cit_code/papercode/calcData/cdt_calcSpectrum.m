function [s,k] = cdt_calcSpectrum(sim,y,nK)
FY = dcfft2(y,sim.dx);
[s,k] = cdt_calcSpectrumFromKSpace(sim,FY,nK);
end