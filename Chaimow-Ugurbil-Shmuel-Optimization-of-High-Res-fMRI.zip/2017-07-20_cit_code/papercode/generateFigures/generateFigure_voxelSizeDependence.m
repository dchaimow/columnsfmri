function generateFigure_voxelSizeDependence(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_voxelSizeDependence.mat'));



% fraction of contrastRange in which 10%, 20%, ... of voxel responses lie
columnHeight = 6;    % inch 9.45 = maximum
setFigureOptions;
f = figure;

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));
c = get(0,'DefaultAxesColorOrder');

fontSize = 12;
set(0,'DefaultAxesFontSize',fontSize);

p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;



p.pack(2,2);

p(1,1).select();
ax = visualize1d2func(wRange,[100*cr; 1./noiseOfWSingleVoxel]',...
    'voxel width [mm]',...
    {'signal change [%]','SNR'},'',{'k',c(3,:)});
axis(ax(1),[0 4 0 max(100*cr)*1.5]);
axis(ax(2),[0 4 0 max(1./noiseOfWSingleVoxel)*1.5]);
set(ax(1),'YTick',[0 0.5 1 1.5 2]);
set(ax(2),'YTick',[0 100 200 300 400 500]);
putGridLines(1,[],1);
box off;
% p(1,1).title(...
%     {'\bf A  Contrast range and distribution of ',...
%     'differential responses',...
%     'as a function of voxel width'});

p(1,2).select();
nFractions = 5;
%plotNormPFractions(wRange,cnr',nFractions,hsv2rgb([0.3 1 0.5]));
plotNormPFractions(wRange,cnr',nFractions,hsv2rgb([0.1 1 0.5]));
hold on;
xlabel('voxel width [mm]');
ylabel('response ratio');

axis([0 4 0 1.5*max(cnr)]);
putGridLines(1,[]);
box off;
%p(1,2).title(...
%    {'\bf B CNR and distribution of ',...
%    'differential responses relative to noise',...
%    'as a function of voxel width'});

[maxCNR,maxCNRIdx] = max(cnr);
line(wRange(maxCNRIdx)*[1 1],[0 1.5*max(cnr)],...
    'Color',hsv2rgb([0.1 1 0.5]),'LineStyle',':');


p(2,1).select()
cDefault = get(0,'DefaultAxesColorOrder');
c = cDefault(2,:);
cnrRange = linspace(0,10,100);
cGray = (0.6*c + 0.4*[1 1 1]);
cWhite = [1 1 1];

nFractions = 5;
cnrFractions = norminv(0.5+ (0:1/nFractions:1)/2,0,1);
detectionProbabilities = zeros(length(cnrRange),nFractions+1);
for z=1:nFractions
    detectionProbabilities(:,z) = ...
        detectionProbabilityResponse(cnrRange*cnrFractions(z));
end
detectionProbabilities(:,z+1) = ones(length(cnrRange),1);
detectionProbabilityAvg = detectionProbability(cnrRange,1);

altFlag = 0;
if altFlag
   diffRespRelToNoise = abs(bsxfun(@times,randn(100,100),cnrRange));
   A = detectionProbabilityResponse(diffRespRelToNoise);
   cGray = (0.6*c + 0.4*[1 1 1]);
   X = repmat(cnrRange,[100 1]);
   dcScatterTransparent(X(:),A(:),30,cGray);
   hold on;
else
    for z=1:nFractions
        a = (z-1)/(nFractions);
        cArea = cWhite * a + (1 - a) * cGray;
        plot_area(cnrRange,...
            detectionProbabilities(:,z+1)',detectionProbabilities(:,z)',...
            cArea);
        hold on;
    end
end
plot(cnrRange,detectionProbabilityAvg,'Color',c);
box off;
%p(2,1).title(...
%    {'\bf C Average univariate detection probability',...
%    'as a function of CNR'});

xlabel('contrast range to noise ratio');
ylabel('probability');


p(2,2).select()
pDetect = detectionProbability(cnr,1);
visualize1d(wRange,pDetect,...
    'voxel width [mm]','probability','',cDefault(2,:));
[maxP,maxPIdx] = max(pDetect);
line(wRange(maxPIdx)*[1 1],[0 1],'Color',cDefault(2,:),'LineStyle',':');
text(wRange(maxPIdx)+0.1,0.7,['w_{opt} = ' ...
     num2str(wRange(maxPIdx),2) ' mm'],'FontSize',12);
axis([0 4 0 1.1]);


%p(2,2).title(...
%    {'\bf D Optimal voxel width', 'for univariate detection'});
box off;

p.de.margin = 25;
p.margintop =  15;
%p.marginright = 15;
%p.marginleft = 15;
%p.marginbottom = 12;
%p.margintop = 20;
%p(1,1).marginright = 30;



axes('Position',[0 0 1 1],'YDir','reverse','visible','off');

t1 = text(0.0238, 0.0,...
    {'A  Contrast range and distribution of ',...
    'differential responses as a function',...
    'of voxel width'},...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t2 = text(0.5496, 0.0,...
    {'B CNR and distribution of ',...
    'differential responses relative to noise',...
    'as a function of voxel width'},...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t3 = text(0.0238, 0.5023,...
    {'C Average univariate detection probability',...
    'as a function of CNR'},...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t4 = text(0.5496, 0.5023,...
    {'D Optimal voxel width for univariate','detection'},...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',...
    [figNumberStr 'voxelSizeDependence']));
end

function AX=visualize1d2func(xRange,data,xLabel,yLabel,titleText,lineStyle)
nFractions = 5;
color = [0 0 0];
plotFunction1 = @(x,y) plotNormPFractions(x,y,nFractions,color);
plotFunction2 = 'plot';

[AX,H1,H2] = plotyy(xRange, data(:,1),xRange,data(:,2),plotFunction1,plotFunction2);
hold on;
set(get(AX(1),'Ylabel'),'String',yLabel(1));
%set(get(AX(1),'Ylabel'));
set(get(AX(2),'Ylabel'),'String',yLabel(2));
%set(get(AX(2),'Ylabel'));
xlabel(xLabel);
if exist('lineStyle','var')
%    set(H1,'Color',lineStyle{1});
%    set(AX(1),'YColor',lineStyle{1});
    set(get(AX(1),'Ylabel'),'Color',lineStyle{1});
    set(H2,'Color',lineStyle{2});
    set(AX(2),'YColor',lineStyle{2})
    set(get(AX(2),'Ylabel'),'Color',lineStyle{2});
end
title(titleText);
uistack(AX(2));
end

function visualize1d(xRange,data,xLabel,yLabel,titleText,lineStyle)
if ~exist('lineStyle','var')
    lineStyle = 'k';
end

if isnumeric(lineStyle)
    plot(xRange, data,'Color',lineStyle);
else
    plot(xRange, data,lineStyle);
end
xlabel(xLabel);
ylabel(yLabel);
title(titleText);
end

function putGridLines(xRes,yRes,leaveOutLast)
ax = axis(gca);
if ~isempty(xRes)
    startX = floor(ax(1)/xRes)*xRes;
    endX = ceil(ax(2)/xRes)*xRes;
    if exist('leaveOutLast','var') && leaveOutLast
        endX = endX - xRes;
    end
    for x=startX:xRes:endX
        l = line([x x],[ax(3) ax(4)],'LineStyle',':','Color','k','LineWidth',1);
        uistack(l,'bottom');
    end
end
if ~isempty(yRes)
    startY = ceil(ax(3)/yRes)*yRes;
    endY = ceil(ax(4)/yRes)*yRes;
    for y=startY:yRes:endY
        l = line([ax(1) ax(2)],[y y],'LineStyle',':','Color','k','LineWidth',1);
        uistack(l,'bottom');
    end
end
end

function h = plotNormPFractions(x,y,nFractions,c)
yFractions = norminv(0.5+ (0:1/nFractions:1)/2,0,1);
cGray = (0.6*c + 0.4*[1 1 1]);
cWhite = [1 1 1];
for z=1:nFractions
    a = (z-1)/(nFractions);
    cArea = cWhite * a + (1 - a) * cGray;
    plot_area(x,...
        y'*yFractions(z+1),y'*yFractions(z),cArea);
    hold on;
end
h = plot(x,y,'Color',c);
hold off;
end

function h = plot_area(x,lower,upper,color)
lower(isinf(lower)) = 10*sign(lower(isinf(lower))); % check if 10 factor is large enough
upper(isinf(upper)) = 10*sign(lower(isinf(upper))); % check if 10 factor is large enough

h = set(fill([x,x(end:-1:1)],...
    [upper,lower(end:-1:1)],color),'EdgeColor',color);
end