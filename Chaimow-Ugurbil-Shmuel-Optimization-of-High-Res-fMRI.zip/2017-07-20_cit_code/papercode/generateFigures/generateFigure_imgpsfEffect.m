function generateFigure_imgpsfEffect(figNumber,quadraticFlag)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

if exist('quadraticFlag','var') && quadraticFlag
    load(fullfile(dataDir,'data_imgpsfEffect_quadratic.mat'));
else    
    load(fullfile(dataDir,'data_imgpsfEffect.mat'));
end
columnHeight = 6;    % inch 9.45 = maximum
setFigureOptions;
c = get(0,'DefaultAxesColorOrder');
f = figure;

fontSize = 12;
set(0,'DefaultAxesFontSize',fontSize);

p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;

p.pack('v',2);

p(1).pack('h',2);
p(1,1).pack('h',2);
p(1,2).pack('h',2);

% GE

p(1,1,1).select();
plot(wRange,...
    squeeze(cnrWithoutIMGPSFEffect(1,:,strcmpi(GESErange,'ge'))));
hold on;
plot(wRange,...
    squeeze(cnrWithIMGPSFEffect(1,:,strcmpi(GESErange,'ge'))));
xlabel('voxel width [mm]');
ylabel('CNR');
l1 = legend({'PSF independent of voxel width',...
    'imaging PSF changes with voxel width'},...
    'location','southoutside','box','off');

axis([0 4 0 2.5]);
box off;
hold off;

p(1,1,2).select();
plot(wRange,...
    squeeze(corWithoutIMGPSFEffect(1,:,strcmpi(GESErange,'ge'))));
hold on;
plot(wRange,...
    squeeze(corWithIMGPSFEffect(1,:,strcmpi(GESErange,'ge'))));
xlabel('voxel width [mm]');
ylabel('correlation');

axis([0 4 0 1]);
box off;
hold off;

%SE 
p(1,2,1).select();
plot(wRange,...
    squeeze(cnrWithoutIMGPSFEffect(1,:,strcmpi(GESErange,'se'))));
hold on;
plot(wRange,...
    squeeze(cnrWithIMGPSFEffect(1,:,strcmpi(GESErange,'se'))));
xlabel('voxel width [mm]');
ylabel('CNR');
%legend({['PSF independent' char(10) 'of voxel width'],...
%    ['imaging PSF changes' char(10) 'with voxel width']},'location','ne','box','off');
axis([0 4 0 2.5]);
box off;
hold off;

p(1,2,2).select();
plot(wRange,...
    squeeze(corWithoutIMGPSFEffect(1,:,strcmpi(GESErange,'se'))));
hold on;
plot(wRange,...
    squeeze(corWithIMGPSFEffect(1,:,strcmpi(GESErange,'se'))));
xlabel('voxel width [mm]');
ylabel('correlation');
%legend({['PSF independent' char(10) 'of voxel width'],...
%    ['imaging PSF changes' char(10) 'with voxel width']},'location','ne','box','off');
axis([0 4 0 1]);
box off;
hold off;


%% longer total read-out duration and PF
p(2).pack('h',2);
p(2,1).pack('h',2);
p(2,2).pack('h',2);

c = get(0,'DefaultAxesColorOrder');
% GE
p(2,1,1).select();
plot(wRange,...
    squeeze(cnrWithIMGPSFEffect(1,:,strcmpi(GESErange,'ge'))),'Color',c(2,:));
hold on;
plot(wRange,...
    squeeze(cnrWithIMGPSFEffectDoubleTrd(1,:,strcmpi(GESErange,'ge'))),'Color',c(3,:));
plot(wRange,...
    squeeze(cnrWithIMGPSFEffectPF(1,:,strcmpi(GESErange,'ge'))),'Color',c(4,:));
plot(wRange,...
    squeeze(cnrWithIMGPSFEffectDoubleTrdPF(1,:,strcmpi(GESErange,'ge'))),'Color',c(5,:));

xlabel('voxel width [mm]');
ylabel('CNR');

axis([0 4 0 3]);
box off;
hold off;



l2 = legend({'imaging PSF changes with voxel width (same as in A)',...
    'effect of doubling total read-out duration',...
    'effect of 3/4 partial Fourier',...
    'combined effect of doubling total read-out duration and 3/4 partial Fourier acquisition'},...
    'location','southoutside','box','off');


p(2,1,2).select();
plot(wRange,...
    squeeze(corWithIMGPSFEffect(1,:,strcmpi(GESErange,'ge'))),'Color',c(2,:));
hold on;
plot(wRange,...
    squeeze(corWithIMGPSFEffectDoubleTrd(1,:,strcmpi(GESErange,'ge'))),'Color',c(3,:));
plot(wRange,...
    squeeze(corWithIMGPSFEffectPF(1,:,strcmpi(GESErange,'ge'))),'Color',c(4,:));
plot(wRange,...
    squeeze(corWithIMGPSFEffectDoubleTrdPF(1,:,strcmpi(GESErange,'ge'))),'Color',c(5,:));

xlabel('voxel width [mm]');
ylabel('correlation');


axis([0 4 0 1]);
box off;
hold off;


%SE 



p(2,2,1).select();
plot(wRange,...
    squeeze(cnrWithIMGPSFEffect(1,:,strcmpi(GESErange,'se'))),'Color',c(2,:));
hold on;
plot(wRange,...
    squeeze(cnrWithIMGPSFEffectDoubleTrd(1,:,strcmpi(GESErange,'se'))),'Color',c(3,:));
plot(wRange,...
    squeeze(cnrWithIMGPSFEffectPF(1,:,strcmpi(GESErange,'se'))),'Color',c(4,:));
plot(wRange,...
    squeeze(cnrWithIMGPSFEffectDoubleTrdPF(1,:,strcmpi(GESErange,'se'))),'Color',c(5,:));


xlabel('voxel width [mm]');
ylabel('CNR');
%legend({['PSF independent' char(10) 'of voxel width'],...
%    ['imaging PSF changes' char(10) 'with voxel width']},'location','ne','box','off');
axis([0 4 0 3]);
box off;
hold off;

p(2,2,2).select();
plot(wRange,...
    squeeze(corWithIMGPSFEffect(1,:,strcmpi(GESErange,'se'))),'Color',c(2,:));
hold on;
plot(wRange,...
    squeeze(corWithIMGPSFEffectDoubleTrd(1,:,strcmpi(GESErange,'se'))),'Color',c(3,:));
plot(wRange,...
    squeeze(corWithIMGPSFEffectPF(1,:,strcmpi(GESErange,'se'))),'Color',c(4,:));
plot(wRange,...
    squeeze(corWithIMGPSFEffectDoubleTrdPF(1,:,strcmpi(GESErange,'se'))),'Color',c(5,:));


xlabel('voxel width [mm]');
ylabel('correlation');
%legend({['PSF independent' char(10) 'of voxel width'],...
%    ['imaging PSF changes' char(10) 'with voxel width']},'location','ne','box','off');
axis([0 4 0 1]);
box off;
hold off;










p.de.margin = 10;
p.margintop =  13;
p.marginbottom =  40;
p(1).marginbottom = 40;
p(1,1).marginright = 20;
p(2,1).marginright = 20;
p(1,1,2).marginleft = 15;
p(1,2,2).marginleft = 15;
p(2,1,2).marginleft = 15;
p(2,2,2).marginleft = 15;
%p.marginright = 15;
%p.marginleft = 15;
%p.marginbottom = 12;
%p.margintop = 20;
%p(1,1).marginright = 30;





axes('Position',[0 0 1 1],'YDir','reverse','visible','off');

t1 = text(0.0238, 0.01,...
    'A Effect of modeling a voxel width dependent imaging PSF  ',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t2 = text(0.0238, 0.45,...
    'B Effect of increased total read-out duration and/or partial Fourier acquisition',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t3 = text(0.05, 0.05,...
    'GE',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t4 = text(0.55, 0.05,...
    'SE',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t5 = text(0.05, 0.49,...
    'GE',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t6 = text(0.55, 0.49,...
    'SE',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');


l1.Position(1) = 0.04;
l2.Position(1) = 0.04;

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end
if exist('quadraticFlag','var') && quadraticFlag
    printFigureOnPaper(twoColumnWidth, columnHeight,...
        fullfile(rootDir,'figures',[figNumberStr 'imgpsfEffect_quadratic']));
else
    printFigureOnPaper(twoColumnWidth, columnHeight,...
        fullfile(rootDir,'figures',[figNumberStr 'imgpsfEffect']));
end
end