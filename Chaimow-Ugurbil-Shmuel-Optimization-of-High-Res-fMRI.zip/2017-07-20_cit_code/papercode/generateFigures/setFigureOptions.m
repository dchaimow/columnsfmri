figDir  = 'figures';

reset(0);

c = [...
    0.6   1      0.7    ;...
    1      1  0.9   ;...
    0.1  1 1      ;...
    0.8 1 0.6    ;...
    0.3333  1 0.5;...
    0.58   0.67   0.9];

set(0,'DefaultAxesColorOrder',hsv2rgb(c));

c = get(0,'DefaultAxesColorOrder');
 
minIntensity = 0.3;
steps4 = linspace(minIntensity,1,4);
steps3 = linspace(minIntensity,1,3);

% set line properties:
set(0,'DefaultLineLineWidth',1.5);
set(0,'DefaultLineMarkerSize',4);

% set axes Properties
set(0,'DefaultAxesLineWidth',1);
set(0,'DefaultAxesFontSize',8);
set(0,'DefaultAxesFontName','Arial');
set(0,'DefaultAxesColor','None');

twoColumnWidth = 7;             % inch
if ~exist('columnHeight','var')
    columnHeight = 9.45;        % inch 9.45 = maximum
end
ptsPerInch = 72;        %
figureWidth = twoColumnWidth; % inch
figureHeight = columnHeight;     % inch
figurePos = [0 0 figureWidth figureHeight];

% set figure properties
set(0,'DefaultFigureUnits','inches');
set(0,'DefaultFigureColor','White');
set(0,'DefaultFigurePosition',figurePos);
set(0,'DefaultFigureMenubar','none');

% add some helper packages to path
addpath('~/Documents/matlab/tools/freezeColors');
addpath('~/Documents/matlab/tools/cm_and_cb_utilities');
addpath('~/Documents/matlab/tools/scalebar');
addpath('~/Documents/matlab/tools/panel-2.11');
addpath('~/Documents/matlab/tools/plot2svg_20120915');
