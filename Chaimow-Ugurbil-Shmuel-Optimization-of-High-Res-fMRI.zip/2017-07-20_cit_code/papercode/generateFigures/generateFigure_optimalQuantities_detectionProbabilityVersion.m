function generateFigure_optimalQuantities_detectionProbabilityVersion(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_optimalVoxelQuantities'));

pPlotRange = [0 1];
rPlotRange = [0.5 1];
corPlotRange = [0 max(optCor(:))];


%% visualize
columnHeight = 7;    % inch 9.45 = maximum
setFigureOptions;

c = get(0,'DefaultAxesColorOrder');

c0 = [1 1 1];
cmap1 = linspace(0,1,64)' * c(2,:) + linspace(1,0,64)' * c0;
cmap2 = linspace(0,1,64)' * c(5,:) + linspace(1,0,64)' * c0;
cmap3 = linspace(0,1,64)' * c(1,:) + linspace(1,0,64)' * c0;

fontSize = 12;
set(0,'DefaultAxesFontSize',fontSize);

f = figure;
p = panel();

% layout a variety of sub-panels
p.fontname = 'Arial';
p.fontsize = fontSize;

p.pack('h',[0.2 0.8]);
p(2).pack('v',[0.98 0.02]);
p(2,1).pack(3,3);
p(2,2).pack('h',3);

%% First figure: optimal voxel size
% FWHM = 0.5
% detect single
dcvisualize2d(p(2,1,1,1),optPDetectSingle(:,:,1),1./rhoRange,deltaRange,...
    '',...
    '',...
    {['\bf\color[rgb]{' sprintf('%f,%f,%f',c(2,:)) '}' ...
    'univariate'],'detection probability'},...
    'voxel width [mm]',pPlotRange);
set(gca,'XTickLabel','');
%colormap(gca,cmap1);


% detect multi
dcvisualize2d(p(2,1,1,2),optRDecodeMVCNR{1}(:,:,1),1./rhoRange,deltaRange,...
    '',...
    '',...
    ['\bf\color[rgb]{' sprintf('%f,%f,%f',c(5,:)) '}' ...
    'decoding accuracy'],...
    'voxel width [mm]',rPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');
%colormap(gca,cmap2);

% Correlation
dcvisualize2d(p(2,1,1,3),optCor(:,:,1),1./rhoRange,deltaRange,...
    '',...
    '',...
    ['\bf\color[rgb]{' sprintf('%f,%f,%f',c(1,:)) '}' ...
    'pattern correlation'],...
    'voxel width [mm]',corPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');
%colormap(gca,cmap3);

% FWHM = 1
% detect single
dcvisualize2d(p(2,1,2,1),optPDetectSingle(:,:,2),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',pPlotRange);
set(gca,'XTickLabel','');
%colormap(gca,cmap1);

% detect multi
p(2,1,2,1);
dcvisualize2d(p(2,1,2,2),optRDecodeMVCNR{1}(:,:,2),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',rPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');
%colormap(gca,cmap2);

% Correlation
dcvisualize2d(p(2,1,2,3),optCor(:,:,2),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',corPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');
%colormap(gca,cmap3);

% FWHM = 2
% detect single
cb = dcvisualize2d(p(2,1,3,1),optPDetectSingle(:,:,3),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'probability',pPlotRange,1);
p(2,2,1).select(cb);
%%colormap(gca,cmap1);

% detect multi
cb = dcvisualize2d(p(2,1,3,2),optRDecodeMVCNR{1}(:,:,3),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'accuracy',rPlotRange,1);
set(gca,'YTickLabel','')
p(2,2,2).select(cb);
%%colormap(gca,cmap2);

% Correlation
cb = dcvisualize2d(p(2,1,3,3),optCor(:,:,3),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'correlation',corPlotRange,1);
set(gca,'YTickLabel','');
p(2,2,3).select(cb);
%%colormap(gca,cmap3);


p(2,1).ylabel('relative irregularity (\delta/\rho)');
p(2,1).xlabel('columnar cycle [mm]');



p.de.margin = 5;
p.margintop = 20;
p.marginright = 10;
p(2,1).marginbottom = 15;

axes('Position',[0 0 1 1],'YDir','reverse','visible','off');
text(0.27,0.03,'Maximally obtainable:','FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');
text(0.01,0.12,{'BOLD PSF','FWHM = 0.5 mm'},'FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');
text(0.01,0.12+0.245,{'BOLD PSF','FWHM = 1 mm'},'FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');
text(0.01,0.12+2*0.245,{'BOLD PSF','FWHM = 2 mm'},'FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',[figNumberStr 'optimalQuantities']));

end


function h_colorbar_axis = dcvisualize2d(p,data,xRange,yRange,...
    xLabel,yLabel,titleText,barText,cRange,hBar)
p.select();

xiRange = linspace(xRange(1),xRange(end),length(xRange));
yiRange = linspace(yRange(1),yRange(end),length(yRange));

[Y,X] = meshgrid(yRange,xRange);
[YI,XI] = meshgrid(yiRange,xiRange);

dataI = interp2(Y,X,data,YI,XI);

if exist('cRange','var')
    imagesc(xRange,yRange,dataI',cRange);
else
    imagesc(xRange,yRange,dataI');
end

axis image;
axis xy;
p.xlabel(xLabel);
p.ylabel(yLabel);
p.title(titleText);

if exist('hBar','var') && hBar
    h_colorbar_axis = colorbar('peer',gca,'h');
    h_colorbar_axis.Label.String = barText;
    x1=get(gca,'position');
    x=get(h_colorbar_axis,'Position');
    x(4)=0.02;
    set(h_colorbar_axis,'Position',x);   
    set(gca,'position',x1)
else
    h_colorbar_axis = [];
end
axis square;
end
