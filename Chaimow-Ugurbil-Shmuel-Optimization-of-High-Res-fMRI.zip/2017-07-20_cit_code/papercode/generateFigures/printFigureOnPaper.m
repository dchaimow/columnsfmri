function printFigureOnPaper(width, height, fileName)
% options for figure on letter page

axes('Position',[0 0 1 1],'YDir','reverse','visible','off');
axis([0 1 0 1]);

% line([0 .1],[0 0],'Color','k');
% line([0  0],[0 0.1],'Color','k');
% 
% line([0.9 1],[0 0],'Color','k');
% line([1 1],[0 0.1],'Color','k');
% 
% line([0 .1],[1 1],'Color','k');
% line([0  0],[0.9 1],'Color','k');
% 
% line([0.9 1],[1 1],'Color','k');
% line([1 1],[0.9 1],'Color','k');

paperSize = [8.5 11];
set(gcf,'PaperSize',paperSize);

leftMargin = (paperSize(1)-width)/2;
bottomMargin = (paperSize(2)-height-1);
set(gcf, 'PaperPosition', ...
    [leftMargin bottomMargin width height]);
set(gcf,'PaperPositionMode','auto'); 
print('-dtiff','-r1000',fileName);
print('-dpdf',fileName);
% print('-depsc2',[fileName '_tmp']);
% system(['/usr/local/bin/eps2eps ' ...
%     fileName '_tmp.eps ' ...
%     fileName '.eps']);
% delete([fileName '_tmp.eps']);
% system(['/usr/local/bin/ps2pdf ' ...
%     fileName '.eps ' ...
%     fileName '.pdf']);
end


