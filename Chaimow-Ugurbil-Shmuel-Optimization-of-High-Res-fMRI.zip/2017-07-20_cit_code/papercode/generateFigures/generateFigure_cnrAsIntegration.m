function generateFigure_cnrAsIntegration(figNumber)
% Illustrates how contrast range is generated as an integral in k-space
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_cnrAsIntegration.mat'));

columnHeight = 3;    % inch 9.45 = maximum
setFigureOptions;

fontSize = 10;
set(0,'DefaultAxesFontSize',fontSize);

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));

c = get(0,'DefaultAxesColorOrder');

f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;


p.pack(1,3);

p(1,1).select();
hold off;
l1 = plot(spectrumK,neuronalSpectrum/max(neuronalSpectrum),'Color',[0.5 0.5 0.5],'LineWidth',2);
hold on;
l2 = plot(spectrumK,mtfSpectrum/max(mtfSpectrum),':','Color',c(2,:),'LineWidth',2);

[~,idx] = max(boldSpectrum);
rhoApparent = spectrumK(idx);

line([rho rho],[0 1],'LineStyle','-','Color',[0.5 0.5 0.5],'LineWidth',1);
line([rhoApparent rhoApparent],[0 1],'LineStyle','-','Color',c(2,:),'LineWidth',1);
%line([rhoApparent rhoApparent],[0 1],'LineStyle','--','Color',[0.5 0.5 0.5],'LineWidth',1);



%plot(spectrumK,sqrt(mtfSpectrum/max(mtfSpectrum)),'r','LineWidth',2);
plot(spectrumK,neuronalSpectrum/max(neuronalSpectrum),'Color',[0.5 0.5 0.5],'LineWidth',2);
l3 = plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),'Color',c(2,:),'LineWidth',2);
%plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',2);
ylabel('normalized power [a.u.]');
%xlabel('spatial frequency [mm^{-1}]');
axis([0 max(spectrumK) 0 1]);
axis square;
box off;
42;


[hl0,icns] = legend([l1,l2,l3],{'orig. pattern','BOLD MTF','BOLD pattern'},...
    'location','ne',...
    'Box','off','FontSize',fontSize);
shortenLegendLines(icns,0.05);






% p(1,1).select();
% hold off;
% plot(spectrumK,neuronalSpectrum/(max(neuronalSpectrum)),'Color',[0.5 0.5 0.5],'LineWidth',2);
% hold on;
% plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',2);
% line([rho rho],[0 1.25],'LineStyle','--','Color',[0 0 0],'LineWidth',1.5);
% plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),'r','LineWidth',2);
% plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',2);
% plot(spectrumK,neuronalSpectrum/(max(neuronalSpectrum)),'Color',[0.5 0.5 0.5],'LineWidth',2);
% ylabel('normalized power');
% xlabel('spatial frequency [mm^{-1}]');
% axis([0 max(spectrumK) 0 1.25]);
% axis square;
% box off;

p(1,2).select();
hold off;
plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',2);
hold on;
%line([rhoApparent rhoApparent],[0 0.1],'LineStyle','--','Color',[0.5 0.5 0.5],'LineWidth',1);
line([rhoApparent rhoApparent],[0 0.1],'LineStyle','-','Color',c(2,:),'LineWidth',1);
%line([rho rho],[0 0.25],'LineStyle','--','Color',[0 0 0],'LineWidth',1.5);
hw1 = plot(spectrumK,voxelSpectrum4/maxVoxelSpectrum*0.02,...
    'Color',c(1,:),'LineWidth',2);
hw2 = plot(spectrumK,voxelSpectrum3/maxVoxelSpectrum*0.02,...
    'Color',c(3,:),'LineWidth',2);
hw3 = plot(spectrumK,voxelSpectrum2/maxVoxelSpectrum*0.02,...
    'Color',c(4,:),'LineWidth',2);
hw4 = plot(spectrumK,voxelSpectrum1/maxVoxelSpectrum*0.02,...
    'Color',c(5,:),'LineWidth',2);

plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),'Color',c(2,:),'LineWidth',2);
%plot(spectrumK,boldSpectrum/(max(neuronalSpectrum)*b^2),...
%    'Color',[0.5 0.5 0.5],'LineStyle','--','LineWidth',2);
%text(kVoxel1-0.1,0.06,'4 mm','FontSize',fontSize,'Rotation',45);
%text(kVoxel2-0.1,0.06,'2 mm','FontSize',fontSize,'Rotation',45);
%text(kVoxel3-0.1,0.06,'1 mm','FontSize',fontSize,'Rotation',45);
%text(kVoxel4-0.1,0.06,'0.5 mm','FontSize',fontSize,'Rotation',45);
axis([0  max(spectrumK) 0 0.1]);
ylabel('normalized power [a.u.]');
%xlabel('spatial frequency [mm^{-1}]');
axis square;
box off;
[hl,icns] = legend([hw4,hw3,hw2,hw1],{'4 mm','2 mm','1 mm','0.5 mm'},...
    'location','ne',...
    'Box','off','FontSize',fontSize);
shortenLegendLines(icns,0.05);
hlt = text(...
    'Parent', hl.DecorationContainer, ...
    'String', {'integration range [a.u.]','for voxel width:'}, ...
    'HorizontalAlignment', 'right', ...
    'VerticalAlignment', 'bottom', ...
    'Position', [0.9, 1.05, 0], ...
    'Units', 'normalized');




p(1,3).select();
hold off;
plot(kRange/2,100*cr,'k','LineWidth',2);
hold on;
%line([rhoApparent rhoApparent],[0 100*max(cr)],'LineStyle','-','Color',[0.5 0.5 0.5],'LineWidth',1);
line([rhoApparent rhoApparent],[0 100*max(cr)],'LineStyle','-','Color',c(2,:),'LineWidth',1);
lc = plot(kRange/2,100*cr,'k','LineWidth',2);
plot(kVoxel1,100*cr(kRange == kVoxel1*2),'.','MarkerSize',25,'Color',c(5,:),'LineWidth',2);
plot(kVoxel2,100*cr(kRange == kVoxel2*2),'.','MarkerSize',25,'Color',c(4,:),'LineWidth',2);
plot(kVoxel3,100*cr(kRange == kVoxel3*2),'.','MarkerSize',25,'Color',c(3,:),'LineWidth',2);
plot(kVoxel4,100*cr(kRange == kVoxel4*2),'.','MarkerSize',25,'Color',c(1,:),'LineWidth',2);
%text(kVoxel1-0.1,100*cr(kRange == kVoxel1*2)+0.14,'4 mm','FontSize',fontSize,'Rotation',45);
%text(kVoxel2-0.1,100*cr(kRange == kVoxel2*2)+0.14,'2 mm','FontSize',fontSize,'Rotation',45);
%text(kVoxel3-0.1,100*cr(kRange == kVoxel3*2)+0.14,'1 mm','FontSize',fontSize,'Rotation',45);
%text(kVoxel4-0.1,100*cr(kRange == kVoxel4*2)+0.14,'0.5 mm','FontSize',fontSize,'Rotation',45);
ylabel('signal change [%]');
%xlabel('spatial frequency [mm^{-1}]');
axis([0 max(spectrumK) 0 100*max(cr)]);
axis square;
box off;

[hlc,icns] = legend(lc,{'contrast range'},...
    'location','ne','Box','off','FontSize',fontSize);
shortenLegendLines(icns,0.05);



p.xlabel('spatial frequency [mm^{-1}]');

p.de.margin = 15;
p.margintop = 20;
p(1,1).marginright = 25;

hl0.Position = [0.1390    0.5533    0.2046    0.1829];
hl.Position = [ 0.5170    0.3838    0.1495    0.2384];
hlc.Position = [ 0.7829    0.5359    0.2102    0.1250];

axes('Position',[0 0 1 1],'YDir','reverse','visible','off');
t1 = text(0.0250,0.03 ,'A','FontSize',12,'FontName','Arial',...
    'FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');
t2 = text(0.0650,0.0350 ,{'BOLD response:', 'low-pass filtering in',...
    'spatial frequency space'},'FontSize',12,'VerticalAlignment','top');

t3 = text(0.3760,0.03 ,'B','FontSize',12,'FontName','Arial',...
    'FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');
t4 = text(0.4160,0.035 ,{'Contrast range:', 'voxel size dependent integration',...
    'in spatial frequency space'},'FontSize',12,'VerticalAlignment','top');


if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
   fullfile(rootDir,'figures',[figNumberStr 'cnrAsIntegration']));
end
