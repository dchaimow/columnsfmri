function sigma = cit_noiseModel_tmp(V,noiseType,TR,smoothFactor,nT,differentialFlag)
% smoothFactor is the Volume ratio between averaged data points and
% measured data points, based on Triantafyllou 2006
% can be same length as V
% it is used to scale the thermal noise factor, assuming thermal noise in
% uncorrelated in space
 
% nT is the number of volumes to be averaged:
% it is used to scale the thermal noise factor, assuming thermal noise in
% uncorrelated in time
% AND it is used to scale the physiological noise factor under the
% assuption that physiological noise is a AR(1) process with
% q = exp(-TR/tau), tau = 15 s (Purdon and Weisskoff 1998)
%
% with set differential flag nT/2 volumes belong to condition A dn nT/2
% volumes to condition B
 
 
if ~exist('smoothFactor','var')
    smoothFactor = 1;
end
TR0 = 5.4;
if isnumeric(noiseType)
    kappa = noiseType(1);
    lambda = noiseType(2);
    T1 = noiseType(3);
elseif strcmp(noiseType,'3T') % from estimateNoiseModelFromTriantafyllou2005.m
    kappa = 6.6567;
    lambda = 0.0129;
    T1 = 1.607;
elseif strcmp(noiseType,'7T')
    kappa = 9.9632;
    lambda = 0.0113;
    T1 = 1.939;
elseif strcmp(noiseType,'Thermal')
    kappa = 9.9632;
    lambda = 0;
    T1 = 1.939;
elseif strcmp(noiseType,'Physiological')
    kappa = 1/eps;
    lambda = 0.0113;
    T1 = 1.939;
end
% F = SNR0 correction
F = sqrt(tanh(TR/(2*T1))/tanh(TR0/(2*T1)));
% CTh = thermal noise averaging correction"
if exist('differentialFlag','var') && differentialFlag
    CTh = smoothFactor*nT/(2^2);
else
    CTh = smoothFactor*nT;
end
 
% CPh = physiological noise averaging correction"
q = exp(-TR/15);
%C = q.^toeplitz(0:nT-1,0:nT-1);
%Var = sum(C(:));
% faster method:
z = 1:nT-1;
Var = sum(q.^z .* (nT-z) * 2)+nT;
if exist('differentialFlag','var') && differentialFlag
    CPh = nT^2/(2^2*Var);
else
    CPh = nT^2/Var;
end
tSNR = (kappa .* V .*F)./...
    sqrt(1./CTh+lambda.^2.*(kappa.*V.*F).^2/CPh);
sigma = 1./tSNR;
end
 
%% T1 constants from Water proton T1 measurements in brain tissue at 7, 3, and 1.5T using IR-EPI, IR-TSE, and MPRAGE: results and optimization
% P. J. Wright, O. E. Mougin, J. J. Totman, A. M. Peters, M. J. Brookes, R. Coxon, P. E. Morris, M. Clemence, S. T. Francis and R. W. Bowtell, et al.
% GM 3T:  1.607 s
% GM 7T:  1.939 s