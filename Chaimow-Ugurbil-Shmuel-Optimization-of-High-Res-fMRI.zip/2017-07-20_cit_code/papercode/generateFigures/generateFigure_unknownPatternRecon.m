function generateFigure_unknownPatternRecon(figNumber)
addpath ~/Documents/matlab/tools/legendflex/;
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

% set parameters
parameters = cit_masterParameterSetting;
rng(parameters.randomNumberSeed);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

rho = parameters.rho;
delta = parameters.delta;
fwhm = parameters.fwhm7TGE;
b = parameters.beta7TGE;
nT = parameters.nT;
TR = parameters.TR;
sliceThickness = parameters.sliceThickness;

w1 = parameters.unkownPatternFigure.w1;
w2 = parameters.unkownPatternFigure.w2;
nyq1 = (1/(2*w1));
nyq2 = (1/(2*w2));

downFactor1 = sim.dx/w1;
assert(sim.L/(2* ceil(sim.N * downFactor1 * 0.5)) == w1);
downFactor2 = sim.dx/w2;
assert(sim.L/(2* ceil(sim.N * downFactor2 * 0.5)) == w2);

simV1 = cdt_setupsim(N*downFactor1, L);
simV2 = cdt_setupsim(N*downFactor2, L);

voxelV1 = w1^2*sliceThickness;
voxelV2 = w2^2*sliceThickness;
differentialFlag = true;
noiseOfW1 = cit_noiseModel(voxelV1,'7T',TR,1,nT,differentialFlag);
noiseOfW2 = cit_noiseModel(voxelV2,'7T',TR,1,nT,differentialFlag);

noise = cdt_noise2(sim);
neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
[P,kRange]=calcPowerSpectrum(neuronal,sim);
bold = cdt_bold2(sim,fwhm,b,neuronal);
[voxel1Raw,~] = cdt_mri2(sim,downFactor1,bold);
voxel1 = voxel1Raw + noiseOfW1*randn(size(voxel1Raw));
[P1V,kRangeV1]=calcPowerSpectrum(voxel1,simV1);

[voxel2Raw,~] = cdt_mri2(sim,downFactor2,bold);
voxel2 = voxel2Raw + noiseOfW2*randn(size(voxel2Raw));
[P2V,kRangeV2]=calcPowerSpectrum(voxel2,simV2);

%% visualize
columnHeight = 6;    % inch 9.45 = maximum
setFigureOptions;
f = figure;

fontSize = 10;
set(0,'DefaultAxesFontSize',fontSize);

p = panel();


% layout a variety of sub-panels
p.fontname = 'Arial';
p.fontsize = fontSize;

p.pack('v',3);


%displayPanel(p(1),neuronal,sim,kRange,[-2 2],'a.u.',P,PMTF);
displayPanel(p(1),neuronal,sim,kRange,[-2 2],'a.u.',P,[]);
displayPanel(p(2),voxel1,simV1,kRangeV1,[-.05 .05],'relative change',P1V,[],nyq1);
displayPanel(p(3),voxel2,simV2,kRangeV2,[-.02 .02],'relative change',P2V,[],nyq2);

p.de.margin = 6;
p(1,1).marginright = 30;
p(1,2).marginleft = 30;
p(2,1).marginright = 30;
p(2,2).marginleft = 30;
p(3,1).marginright = 30;
p(3,2).marginleft = 30;

p.marginleft = 50;
p(1).marginbottom = 20;
p(2).marginbottom = 20;

axes('Position',[0 0 1 1],'YDir','reverse','visible','off');
text(0.02,0.03,'\bfA \rmTrue columnar pattern',...
    'FontName','Arial','FontSize',12,...
    'HorizontalAlignment','left','VerticalAlignment','top');
text(0.02,0.36,'\bfB \rmAdequate voxel width',...
    'FontName','Arial','FontSize',12,...
    'HorizontalAlignment','left','VerticalAlignment','top');
text(0.02,0.7,'\bfC \rmVoxel width too large',...
    'FontName','Arial','FontSize',12,...
    'HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',[figNumberStr 'unknownPatternSampling']));

end

function displayPanel(p,map,sim,kRange,imageRange,barLabel,P,MTF,lineValue)
p.pack('h',2);

displayMap(p(1),map,sim,imageRange,barLabel);
if exist('lineValue','var')
    displayPlot(p(2),kRange,P,MTF,lineValue);
else
    displayPlot(p(2),kRange,P,MTF);
end
end


function displayMap(p,map,sim,imageRange,barLabel)
p.select();
dcvisualize2d(map,sim.x,sim.x,'space [mm]','','',barLabel,imageRange);
axis image;
axis square;
axis([-5 5 -5 5]);
colormap gray
end

function displayPlot(p,kRange,P,MTF,lineValue)
p.select();
plot(kRange,P/max(P(:)),'k');
axis([0 1.5 0 1]);
hold on;
if ~isempty(MTF)
    plot(kRange,MTF/max(MTF(:)),'r');
end
hold off;
xlabel('spatial frequency');
ylabel('normalized spectrum');
axis square;
box off;
if exist('lineValue','var')
%    line([lineValue lineValue],[0 1],'LineWidth',1,'Color',[0 0.8 0],...
%        'LineStyle','-');
line([lineValue lineValue],[0 1],'LineWidth',1,'Color',hsv2rgb([0.1 1 0.5]),...
    'LineStyle','-');
line(sqrt(2)*[lineValue lineValue],[0 1],'LineWidth',1,'Color',hsv2rgb([0.1 1 0.5]),...
    'LineStyle',':');
    hold on;
    plot(kRange,P/max(P(:)),'k');
    hold off;
end
end

function [P,kRange]=calcPowerSpectrum(y,sim)
dk = 0.02;
F = dcfft2(y,sim.dx);
k = sqrt(sim.k1.^2+sim.k2.^2);
kRange = 0:dk:ceil(max(k(:))/dk)*dk;
P = zeros(size(kRange));
for zK=1:length(kRange)
    P(zK) = mean(abs(F(abs(k-kRange(zK))<dk/2)).^2);
end
end

function upPattern = upSample(pattern,sim)
Fy = fft2(pattern);
[m,n] = size(Fy); % size of the original matrix
nzsr = sim.N - m; % number of zero rows to add
nzsc = sim.N - n; % number of zero columns to add
% quadrants of the FFT, starting in the upper left
q1 = Fy(1:m/2,1:n/2);
q2 = Fy(1:m/2,n/2+1:n);
q3 = Fy(m/2+1:m,n/2+1:n);
q4 = Fy(m/2+1:m,1:n/2);
zpdr = zeros(nzsr,n/2);  % zeropad rows to insert
zpdc = zeros(nzsr+m,nzsc); % zeropad columns to insert
zpdFy = [ [q1;zpdr;q4] , zpdc , [q2;zpdr;q3] ]; % insert the zeros
upPattern = real(ifft2(zpdFy)) * sim.N^2/(m*n) ;
end

