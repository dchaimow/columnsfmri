function generateFigureComponents_modelOverview
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');
addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));

addpath('~/Documents/matlab/tools/panel-2.11');
figdir = fullfile(rootDir,'figures');
 
fontSize = 14;
reset(0);
% set line properties:
set(0,'DefaultLineLineWidth',1.5);
set(0,'DefaultLineMarkerSize',4);
% set axes Properties
set(0,'DefaultAxesLineWidth',1);
set(0,'DefaultAxesFontSize',fontSize);
set(0,'DefaultAxesFontName','Arial');
set(0,'DefaultAxesColor','None');

figureWidth = 2.7;             % inch
figureHeight = 2.2;        % inch 9.45 = maximum
ptsPerInch = 72;        %
figurePos = [0 0 figureWidth figureHeight];

% set figure properties
set(0,'DefaultFigureUnits','inches');
set(0,'DefaultFigureColor','White');
set(0,'DefaultFigurePosition',figurePos);
set(0,'DefaultFigureMenubar','none');

% set parameters
parameters = cit_masterParameterSetting;
N = parameters.N;
L = parameters.L;
rho = parameters.rho;
delta = parameters.delta;
fwhm = parameters.fwhmExample;
b = parameters.betaExample; 
nT = parameters.nT; 
TR = parameters.TR;
sliceThickness = parameters.sliceThickness;
voxelWidth = parameters.voxelWidthExample;  % voxel width

dispL = voxelWidth * round(sqrt(parameters.Aflat)/voxelWidth);

% simulate
rng(parameters.randomNumberSeed);
sim = cdt_setupsim(N,L);
noise = cdt_noise2(sim);
neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
bold = cdt_bold2(sim,fwhm,b,neuronal);

downFactor = sim.dx/voxelWidth;
voxelVolume = sliceThickness.*voxelWidth.^2;
differentialFlag = true;
noiseOfWSingleVoxel    = ...
    cit_noiseModel(voxelVolume,'7T',TR,1,nT,differentialFlag);
[voxel,actualVoxelWidth] = cdt_mri2(sim,downFactor,bold);
assert(voxelWidth==actualVoxelWidth);            
noiseimage = noiseOfWSingleVoxel*randn(size(voxel));
voxelNoise = voxel + noiseimage;

x1disp = sim.x1(abs(sim.x1)<=dispL/2 & abs(sim.x2)<=dispL/2);
xdisprange = unique(x1disp(:,1));
dispN = length(xdisprange);
dispNMRI = ceil(dispN * downFactor * 0.5)*2;


% histogram

f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;
p.select();
minC = -max(abs(100*voxel(:)));
maxC = +max(abs(100*voxel(:)));
%x = floor(minC*2)/2+0.1/2:0.5:ceil(maxC*2)/2-0.5/2;
nBars = 10;
x = (maxC/(nBars/2))*(-(nBars/2+0.5):+(nBars/2+0.5));
[n,x] = hist(100 * voxel(:),x);
bar(x,n,0.9,'FaceColor',[0.2 0.2 0.2],'EdgeColor','none');
xlim([minC maxC]);
box off;
set(gca,'box','off','YTick',[],'color','None','YColor','none');
xlabel('% change');
axis square;
p.margintop = 0;
p.marginleft = 0;
p.marginright = 0;
p.marginbottom = 13;
dcprintfig('fig1_hist',figureWidth,figureHeight,figdir);

close(f);


% noise
f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;
p.select();
imagesc(xdisprange,xdisprange,noise(1:dispN,1:dispN),[-1 1]);axis image
%xlabel('space [mm]');
colormap gray;
cb = colorbar; set(get(cb,'ylabel'),'String', 'a.u.'); set(get(cb,'ylabel'),'FontSize', fontSize);
set(gca,'YTickLabel','');
set(gca,'XTickLabel','');
box on;
p.margintop = 3;
p.marginleft = 0;
p.marginright = 24;
p.marginbottom = 13;
dcprintfig('fig1_noise',figureWidth,figureHeight,figdir);
close(f);

% neuronal
f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;
p.select();
imagesc(xdisprange,xdisprange,neuronal(1:dispN,1:dispN),[-2.5 2.5]);axis image
%xlabel('space [mm]');
colormap gray;
cb = colorbar; set(get(cb,'ylabel'),'String', 'a.u.'); set(get(cb,'ylabel'),'FontSize', fontSize);
set(gca,'YTickLabel','');
set(gca,'XTickLabel','');
box on;
p.margintop = 3;
p.marginleft = 0;
p.marginright = 24;
p.marginbottom = 13;
dcprintfig('fig1_neuronal',figureWidth,figureHeight,figdir);

close(f);

% bold
f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;
p.select();
imagesc(xdisprange,xdisprange,100 * bold(1:dispN,1:dispN),...
    round(100*std(voxel(:))*3)*[-1 1]);
axis image;
%xlabel('space [mm]');
colormap gray;
cb = colorbar; 
set(get(cb,'ylabel'),'String', '% change'); set(get(cb,'ylabel'),'FontSize', fontSize);
set(gca,'YTickLabel','');
set(gca,'XTickLabel','');
box on;
p.margintop = 3;
p.marginleft = 0;
p.marginright = 24;
p.marginbottom = 13;
dcprintfig('fig1_bold',figureWidth,figureHeight,figdir);

close(f);

% voxel
f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;
p.select();
imagesc(xdisprange,xdisprange,100* voxel(1:dispNMRI,1:dispNMRI),...
    round(100*std(voxel(:))*3)*[-1 1]);
axis image;
xlabel('space [mm]');
colormap gray;
cb = colorbar; set(get(cb,'ylabel'),'String', '% change'); set(get(cb,'ylabel'),'FontSize', fontSize);
set(gca,'YTickLabel','');
box on;
p.margintop = 3;
p.marginleft = 0;
p.marginright = 24;
p.marginbottom = 13;
dcprintfig('fig1_voxel',figureWidth,figureHeight,figdir);

close(f);
disp(100*std(voxel(:)));

% voxel + noise
f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;
p.select();
imagesc(xdisprange,xdisprange,100 * voxelNoise(1:dispNMRI,1:dispNMRI),...
    round(100*std(voxel(:))*3)*[-1 1]);
axis image;
xlabel('space [mm]');
colormap gray;
set(gca,'YTickLabel','');
cb = colorbar; set(get(cb,'ylabel'),'String', '% change'); set(get(cb,'ylabel'),'FontSize', fontSize);
box on;
p.margintop = 3;
p.marginleft = 0;
p.marginright = 24;
p.marginbottom = 13;
dcprintfig('fig1_voxelnoise',figureWidth,figureHeight,figdir);

close(f);
end