function  generateFigure_optimalScannerSpecific_extract_pDetect(figNumber)
addpath ~/Documents/matlab/tools/legendflex/;
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

dataFile = fullfile(dataDir,'data_optimalVoxelQuantitiesScannerSpecific');
load(dataFile);

deltaIndcs = [1 11 21];

%% visualize
columnHeight = 9.45;    % inch 9.45 = maximum
setFigureOptions;
f = figure;

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));
c = get(0,'DefaultAxesColorOrder');

p = panel();

% layout a variety of sub-panels
p.fontname = 'Arial';
p.fontsize = 10;

p.pack('v',3);
p(1).pack(2,3);
p(2).pack(2,3);
p(3).pack(2,3);

p.de.margin = 0;
p.margintop = 20;
p.marginleft = 35;
p(1).marginbottom = 20;
p(2).marginbottom = 20;

p(1,1).marginbottom = 5;
p(2,1).marginbottom = 5;
p(3,1).marginbottom = 5;


[l,bSingle3TGE,bMulti3TGE,bRecon3TGE] = ...
    visualizePanel(p(1),1,dataFile,deltaIndcs,steps3);
[~,bSingle7TGE,bMulti7TGE,bRecon7TGE] = ...
    visualizePanel(p(2),2,dataFile,deltaIndcs,steps3);
[~,bSingle7TSE,bMulti7TSE,bRecon7TSE] = ...
    visualizePanel(p(3),3,dataFile,deltaIndcs,steps3);

fprintf('\n3T single detection\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bSingle3TGE(end,1),bSingle3TGE(1,1),bSingle3TGE(2,1),...
    bSingle3TGE(end,2),bSingle3TGE(1,2),bSingle3TGE(2,2),...
    bSingle3TGE(end,3),bSingle3TGE(1,3),bSingle3TGE(2,3)); 
fprintf('\n3T multi detection\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bMulti3TGE(end,1),bMulti3TGE(1,1),bMulti3TGE(2,1),...
    bMulti3TGE(end,2),bMulti3TGE(1,2),bMulti3TGE(2,2),...
    bMulti3TGE(end,3),bMulti3TGE(1,3),bMulti3TGE(2,3)); 
fprintf('\n3T recon\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bRecon3TGE(end,1),bRecon3TGE(1,1),bRecon3TGE(2,1),...
    bRecon3TGE(end,2),bRecon3TGE(1,2),bRecon3TGE(2,2),...
    bRecon3TGE(end,3),bRecon3TGE(1,3),bRecon3TGE(2,3)); 


fprintf('\n7TGE single detection\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bSingle7TGE(end,1),bSingle7TGE(1,1),bSingle7TGE(2,1),...
    bSingle7TGE(end,2),bSingle7TGE(1,2),bSingle7TGE(2,2),...
    bSingle7TGE(end,3),bSingle7TGE(1,3),bSingle7TGE(2,3)); 
fprintf('\n7TGE multi detection\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bMulti7TGE(end,1),bMulti7TGE(1,1),bMulti7TGE(2,1),...
    bMulti7TGE(end,2),bMulti7TGE(1,2),bMulti7TGE(2,2),...
    bMulti7TGE(end,3),bMulti7TGE(1,3),bMulti7TGE(2,3)); 
fprintf('\n7TGE recon\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bRecon7TGE(end,1),bRecon7TGE(1,1),bRecon7TGE(2,1),...
    bRecon7TGE(end,2),bRecon7TGE(1,2),bRecon7TGE(2,2),...
    bRecon7TGE(end,3),bRecon7TGE(1,3),bRecon7TGE(2,3)); 

fprintf('\n7TSE single detection\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bSingle7TSE(end,1),bSingle7TSE(1,1),bSingle7TSE(2,1),...
    bSingle7TSE(end,2),bSingle7TSE(1,2),bSingle7TSE(2,2),...
    bSingle7TSE(end,3),bSingle7TSE(1,3),bSingle7TSE(2,3)); 
fprintf('\n7TSE multi detection\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bMulti7TSE(end,1),bMulti7TSE(1,1),bMulti7TSE(2,1),...
    bMulti7TSE(end,2),bMulti7TSE(1,2),bMulti7TSE(2,2),...
    bMulti7TSE(end,3),bMulti7TSE(1,3),bMulti7TSE(2,3)); 
fprintf('\n7TSE recon\n')
fprintf(...
    'REG min %.1f opt %.1f mm + %.1f x \t AVG min %.1f opt %.1f mm + %.1f x \t  IRR min %.1f opt %.1f mm + %.1f x \n',...
    bRecon7TSE(end,1),bRecon7TSE(1,1),bRecon7TSE(2,1),...
    bRecon7TSE(end,2),bRecon7TSE(1,2),bRecon7TSE(2,2),...
    bRecon7TSE(end,3),bRecon7TSE(1,3),bRecon7TSE(2,3)); 






h = axes('Position',[0 0 1 1],'YDir','reverse','visible','off');

lf = legendflex(l, {'regular','moderately irreg.','irregular'},'bufferunit','normalized',...
    'anchor', [1 1], 'buffer', [0.02 -0.01],'title','pattern:','box','off','ref',h,'FontSize',10);
lf.Position(1) = 0;

t1 = text(0.01,0.09+0*0.31,...
    '3T GE',...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t2 = text(0.01,0.09+1*0.31,...
    '7T GE',...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t3 = text(0.01,0.09+2*0.31,...
    '7T SE',...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t4 = text(0.252+0*0.26,0.01,...
    {'Univariate','detection'},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(2,:));
t5 = text(0.252+1*0.26,0.01,...
    {'Multivariate','detection/decoding'},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(5,:));
t6 = text(0.252+2*0.26,0.01,...
    'Reconstruction',...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(1,:));


if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',...
    [figNumberStr 'optimalScannerSpecific_extract']));
end

function [l,bSingle,bMulti,bRecon] = ...
    visualizePanel(p,scannerIdx,dataFile,deltaIndcs,steps3)
load(dataFile);

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));
c = get(0,'DefaultAxesColorOrder');

parameters = cit_masterParameterSetting;
pThreshold = parameters.pThreshold;
corThreshold = parameters.corThreshold;

belowThresholdSingle = optPDetectSingle < pThreshold;
belowThresholdMulti = optPDetectMulti <pThreshold;
belowThresholdCor = optCor<corThreshold;


[l,bSingle] = plotOptimalVoxel(p(1,1),...
    rhoRange,optVoxelPDetectSingle(:,deltaIndcs,scannerIdx),...
    belowThresholdSingle(:,deltaIndcs,scannerIdx),c(2,:),steps3);
[~,bMulti] = plotOptimalVoxel(p(1,2),rhoRange,...
    optVoxelMVCNR(:,deltaIndcs,scannerIdx),...
    belowThresholdMulti(:,deltaIndcs,scannerIdx),c(5,:),steps3);
[~,bRecon] = plotOptimalVoxel(p(1,3),rhoRange,...
    optVoxelCor(:,deltaIndcs,scannerIdx),...
    belowThresholdCor(:,deltaIndcs,scannerIdx),c(1,:),steps3);

plotOptimalQuantity(p(2,1),rhoRange,optPDetectSingle(:,deltaIndcs,scannerIdx,:),...
    belowThresholdSingle(:,deltaIndcs,scannerIdx,:),...
    fwhmSteps(scannerIdx),1,'probability',c(2,:),steps3);
plotOptimalQuantity(p(2,2),rhoRange,optRDecodeMVCNR{1}(:,deltaIndcs,scannerIdx),...
    belowThresholdMulti(:,deltaIndcs,scannerIdx),...
    fwhmSteps(scannerIdx),1,'accuracy',c(5,:),steps3);
ax = axis;
ax(3) = 0.5;
axis(ax);
plotOptimalQuantity(p(2,3),rhoRange,optCor(:,deltaIndcs,scannerIdx),...
    belowThresholdCor(:,deltaIndcs,scannerIdx),...
    fwhmSteps(scannerIdx),1,'correlation',c(1,:),steps3);
end

function [l,b] = plotOptimalVoxel(p,rhoRange,optVoxel,belowThreshold,c,steps3)
optVoxel = squeeze(optVoxel);
belowThreshold = squeeze(belowThreshold);

p.select();
cycleLength = 1./rhoRange;
maxCycle = max(cycleLength);

colors =  (1-steps3(end:-1:1)') * [1 1 1] + steps3(end:-1:1)' * c;
%colors = (1-[1 0.7 0.4]') * [1 1 1] + [1 0.7 0.4]' * c;

defaultColors = get(gca,'ColorOrder');
set(gca,'ColorOrder',colors);
plot([0 maxCycle],0.5 * [0 maxCycle],'k--','LineWidth',1);
hold on;

optVoxelBelowThreshold = optVoxel;
optVoxelAboveThreshold = optVoxel;
optVoxelBelowThreshold(~belowThreshold) = NaN;
optVoxelAboveThreshold(belowThreshold)  = NaN;

thresholdCycle1 = cycleLength(find(~belowThreshold(:,1),1,'last'));
thresholdCycle2 = cycleLength(find(~belowThreshold(:,2),1,'last'));
thresholdCycle3 = cycleLength(find(~belowThreshold(:,3),1,'last'));

%disp([thresholdCycle1 thresholdCycle2 thresholdCycle3]);
if ~isempty(thresholdCycle1)
    line([thresholdCycle1 thresholdCycle1],[0 maxCycle/2],'LineWidth',1,...
        'LineStyle','--','Color',colors(1,:));

    fit1 = fitlm(cycleLength,optVoxelAboveThreshold(:,1));
    fit1C = fit1.Coefficients.Estimate;
else
    fit1C = [NaN; NaN];
end
if ~isempty(thresholdCycle1)
    
    line([thresholdCycle2 thresholdCycle2],[0 maxCycle/2],'LineWidth',1,...
        'LineStyle','--','Color',colors(2,:));
    fit2 = fitlm(cycleLength,optVoxelAboveThreshold(:,2));
    fit2C = fit2.Coefficients.Estimate;
else
    fit2C = [NaN; NaN];
end
if ~isempty(thresholdCycle1) 
    line([thresholdCycle3 thresholdCycle3],[0 maxCycle/2],'LineWidth',1,...
        'LineStyle','--','Color',colors(3,:));
    fit3 = fitlm(cycleLength,optVoxelAboveThreshold(:,3));
    fit3C = fit3.Coefficients.Estimate;
else
    fit3C = [NaN; NaN];
end

%plot(cycleLength,optVoxelBelowThreshold',':');
%l = plot(cycleLength,optVoxelAboveThreshold');
l = plot(cycleLength,optVoxel');


%xlabel('cycle length [mm]');
ylabel('optimal voxel [mm]');
axis([0 maxCycle 0 maxCycle/2]);
axis square;
box off;
set(gca,'ColorOrder',defaultColors);
set(gca,'XTick',[0 1 2 3 4 5]);
set(gca,'YTick',[0 0.5 1 1.5 2 2.5]);

% linear fit coefficient and minimum cycle length
b = [...
    [fit1C;...
    cycleLength(find(~isnan(optVoxelAboveThreshold(:,1)),1,'last'))] ...
    [fit2C;...
    cycleLength(find(~isnan(optVoxelAboveThreshold(:,2)),1,'last'))] ...
    [fit3C;...
    cycleLength(find(~isnan(optVoxelAboveThreshold(:,3)),1,'last'))]]; 
set(gca,'XTickLabel','');
end

function plotOptimalQuantity(p,rhoRange,optQuantity,belowThreshold,...
    fwhm,maxQuantity,quantityString,c,steps3)
optQuantity = squeeze(optQuantity);
belowThreshold = squeeze(belowThreshold);

p.select();
cycleLength = 1./rhoRange;
maxCycle = max(cycleLength);
colors =  (1-steps3(end:-1:1)') * [1 1 1] + steps3(end:-1:1)' * c;
%colors = (1-[1 0.7 0.4]') * [1 1 1] + [1 0.7 0.4]' * c;
defaultColors = get(gca,'ColorOrder');
set(gca,'ColorOrder',colors);

%line([fwhm fwhm],[0 maxQuantity],'LineWidth',1,...
%    'LineStyle','--','Color',[0 0 0]);

optQuantityBelowThreshold = optQuantity;
optQuantityAboveThreshold = optQuantity;
optQuantityBelowThreshold(~belowThreshold) = NaN;
optQuantityAboveThreshold(belowThreshold)  = NaN;

thresholdCycle1 = cycleLength(find(~belowThreshold(:,1),1,'last'));
thresholdCycle2 = cycleLength(find(~belowThreshold(:,2),1,'last'));
thresholdCycle3 = cycleLength(find(~belowThreshold(:,3),1,'last'));

disp([thresholdCycle1 thresholdCycle2 thresholdCycle3]);
if ~isempty(thresholdCycle1)
    line([thresholdCycle1 thresholdCycle1],[0 maxQuantity],'LineWidth',1,...
        'LineStyle','--','Color',colors(1,:));
end
if ~isempty(thresholdCycle2) 
    line([thresholdCycle2 thresholdCycle2],[0 maxQuantity],'LineWidth',1,...
        'LineStyle','--','Color',colors(2,:));
end
if ~isempty(thresholdCycle3)
    line([thresholdCycle3 thresholdCycle3],[0 maxQuantity],'LineWidth',1,...
        'LineStyle','--','Color',colors(3,:));
end

hold on;
%plot(cycleLength,optQuantityBelowThreshold',':');
%plot(cycleLength,optQuantityAboveThreshold');
plot(cycleLength,optQuantity');
hold off;

xlabel('cycle length [mm]');
ylabel(quantityString);
axis([0 maxCycle 0 maxQuantity]);
axis square;
box off;
set(gca,'ColorOrder',defaultColors);
set(gca,'XTick',[0 1 2 3 4 5]);
end