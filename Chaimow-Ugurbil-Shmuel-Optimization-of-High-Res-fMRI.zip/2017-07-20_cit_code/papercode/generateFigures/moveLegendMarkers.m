function moveLegendMarkers(icons,l)
nLines = length(icons)/3;
for z= nLines+(1:2:(nLines*2))+1
   xData = get(icons(z),'xdata');
   set(icons(z),'xdata',xData+l);
end
end