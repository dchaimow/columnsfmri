function generateFigure_optimal_extract_pDetect(figNumber)
addpath ~/Documents/matlab/tools/legendflex/;
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

dataFile = fullfile(dataDir,'data_optimalVoxelQuantities');
load(dataFile);

deltaIndcs = [1 11 21];

%% visualize
columnHeight = 9.45;    % inch 9.45 = maximum
setFigureOptions;
c = get(0,'DefaultAxesColorOrder');

f = figure;

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));

p = panel();

% layout a variety of sub-panels
p.fontname = 'Arial';
p.fontsize = 10;

p.pack('v',3);
p(1).pack(2,3);
p(2).pack(2,3);
p(3).pack(2,3);

l = visualizePanel(p(1),deltaIndcs(1),dataFile,steps3);
visualizePanel(p(2),deltaIndcs(2),dataFile,steps3);
visualizePanel(p(3),deltaIndcs(3),dataFile,steps3);


p.de.margin = 0;
p.margintop = 20;
p.marginleft = 35;
p(1).marginbottom = 20;
p(2).marginbottom = 20;

p(1,1).marginbottom = 5;
p(2,1).marginbottom = 5;
p(3,1).marginbottom = 5;

h = axes('Position',[0 0 1 1],'YDir','reverse','visible','off');

lf = legendflex(l, {'0.5 mm','1 mm','2 mm'},'bufferunit','normalized',...
    'anchor', [1 1], 'buffer', [0.02 -0.01],'title','PSF FWHM:','box','off','ref',h,'FontSize',10);
lf.Position(1) = 0;

t1 = text(0.01,0.09+0*0.31,...
    {'regular', ['(\delta/\rho ~ ' num2str(deltaRange(deltaIndcs(1))) ')']},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t2 = text(0.01,0.09+1*0.31,...
    {'moderately irreg.',['(\delta/\rho = ' num2str(deltaRange(deltaIndcs(2))) ')']},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t3 = text(0.01,0.09+2*0.31,...
    {'irregular',['(\delta/\rho = ' num2str(deltaRange(deltaIndcs(3))) ')']},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t4 = text(0.252+0*0.26,0.01,...
    {'Univariate','detection'},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(2,:));
t5 = text(0.252+1*0.26,0.01,...
    {'Multivariate','detection/decoding'},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(5,:));
t6 = text(0.252+2*0.26,0.01,...
    'Reconstruction',...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(1,:));

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',...
    [figNumberStr 'optimalVoxeloptimalQuantities_extract']));
end

function l = visualizePanel(p,deltaIdx,dataFile,steps3)
load(dataFile);

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));
c = get(0,'DefaultAxesColorOrder');

parameters = cit_masterParameterSetting;
pThreshold = parameters.pThreshold;
corThreshold = parameters.corThreshold;

belowThresholdSingle = optPDetectSingle < pThreshold;
belowThresholdMulti = optPDetectMulti <pThreshold;
belowThresholdCor = optCor<corThreshold;


l = plotOptimalVoxel(p(1,1),rhoRange,optVoxelPDetectSingle(:,deltaIdx,:),...
    belowThresholdSingle(:,deltaIdx,:),c(2,:),steps3);
plotOptimalVoxel(p(1,2),rhoRange,optVoxelMVCNR(:,deltaIdx,:),...
    belowThresholdMulti(:,deltaIdx,:),c(5,:),steps3);
plotOptimalVoxel(p(1,3),rhoRange,optVoxelCor(:,deltaIdx,:),...
    belowThresholdCor(:,deltaIdx,:),c(1,:),steps3);

plotOptimalQuantity(p(2,1),rhoRange,optPDetectSingle(:,deltaIdx,:),...
    belowThresholdSingle(:,deltaIdx,:),fwhmSteps,1,'probability',c(2,:),steps3);
plotOptimalQuantity(p(2,2),rhoRange,optRDecodeMVCNR{1}(:,deltaIdx,:),...
    belowThresholdMulti(:,deltaIdx,:),fwhmSteps,1,'accuracy',c(5,:),steps3);
ax = axis;
ax(3) = 0.5;
axis(ax);
plotOptimalQuantity(p(2,3),rhoRange,optCor(:,deltaIdx,:),...
    belowThresholdCor(:,deltaIdx,:),fwhmSteps,1,'correlation',c(1,:),steps3);
end

function l = plotOptimalVoxel(p,rhoRange,optVoxel,belowThreshold,c,steps3)
optVoxel = squeeze(optVoxel);
belowThreshold = squeeze(belowThreshold);

p.select();
cycleLength = 1./rhoRange;
maxCycle = max(cycleLength);

colors =  (1-steps3(end:-1:1)') * [1 1 1] + steps3(end:-1:1)' * c;

%colors = (1-[1 0.65 0.4]') * [1 1 1] + [1 0.65 0.4]' * c;

defaultColors = get(gca,'ColorOrder');
set(gca,'ColorOrder',colors);
plot([0 maxCycle],0.5 * [0 maxCycle],'k--','LineWidth',1);
hold on;

optVoxelBelowThreshold = optVoxel;
optVoxelAboveThreshold = optVoxel;
optVoxelBelowThreshold(~belowThreshold) = NaN;
optVoxelAboveThreshold(belowThreshold)  = NaN;

thresholdCycle1 = cycleLength(find(~belowThreshold(:,1),1,'last'));
thresholdCycle2 = cycleLength(find(~belowThreshold(:,2),1,'last'));
thresholdCycle3 = cycleLength(find(~belowThreshold(:,3),1,'last'));

disp([thresholdCycle1 thresholdCycle2 thresholdCycle3]);
if ~isempty(thresholdCycle1)
    line([thresholdCycle1 thresholdCycle1],[0 maxCycle/2],'LineWidth',1,...
        'LineStyle','-','Color',colors(1,:));
end
if ~isempty(thresholdCycle2)
    line([thresholdCycle2 thresholdCycle2],[0 maxCycle/2],'LineWidth',1,...
        'LineStyle','-','Color',colors(2,:));
end
if ~isempty(thresholdCycle3)
    line([thresholdCycle3 thresholdCycle3],[0 maxCycle/2],'LineWidth',1,...
        'LineStyle','-','Color',colors(3,:));
end

%plot(cycleLength,optVoxelBelowThreshold','-');
%l = plot(cycleLength,optVoxelAboveThreshold');
l = plot(cycleLength,optVoxel');

%xlabel('cycle length [mm]');
ylabel('optimal voxel [mm]');
axis([0 maxCycle 0 maxCycle/2]);
axis square;
box off;
set(gca,'ColorOrder',defaultColors);
set(gca,'XTick',[0 1 2 3 4 5]);
set(gca,'YTick',[0 0.5 1 1.5 2 2.5]);

set(gca,'XTickLabel','');
end

function plotOptimalQuantity(p,rhoRange,optQuantity,belowThreshold,...
    fwhmSteps,maxQuantity,quantityString,c,steps3)
optQuantity = squeeze(optQuantity);
belowThreshold = squeeze(belowThreshold);

p.select();
cycleLength = 1./rhoRange;
maxCycle = max(cycleLength);

colors =  (1-steps3(end:-1:1)') * [1 1 1] + steps3(end:-1:1)' * c;
%colors = (1-[1 0.65 0.4]') * [1 1 1] + [1 0.65 0.4]' * c;

defaultColors = get(gca,'ColorOrder');
set(gca,'ColorOrder',colors);

optQuantityBelowThreshold = optQuantity;
optQuantityAboveThreshold = optQuantity;
optQuantityBelowThreshold(~belowThreshold) = NaN;
optQuantityAboveThreshold(belowThreshold)  = NaN;

thresholdCycle1 = cycleLength(find(~belowThreshold(:,1),1,'last'));
thresholdCycle2 = cycleLength(find(~belowThreshold(:,2),1,'last'));
thresholdCycle3 = cycleLength(find(~belowThreshold(:,3),1,'last'));

disp([thresholdCycle1 thresholdCycle2 thresholdCycle3]);
if ~isempty(thresholdCycle1)
    line([thresholdCycle1 thresholdCycle1],[0 maxQuantity],'LineWidth',1,...
        'LineStyle','-','Color',colors(1,:));
end
if ~isempty(thresholdCycle2)
    line([thresholdCycle2 thresholdCycle2],[0 maxQuantity],'LineWidth',1,...
        'LineStyle','-','Color',colors(2,:));
end
if ~isempty(thresholdCycle3)
    
    line([thresholdCycle3 thresholdCycle3],[0 maxQuantity],'LineWidth',1,...
        'LineStyle','-','Color',colors(3,:));
end

hold on;
plot(cycleLength,optQuantity);
%plot(cycleLength,optQuantityBelowThreshold','-');
%plot(cycleLength,optQuantityAboveThreshold');
hold off;

xlabel('cycle length [mm]');
ylabel(quantityString);
axis([0 maxCycle 0 maxQuantity]);
axis square;
box off;
set(gca,'ColorOrder',defaultColors);
set(gca,'XTick',[0 1 2 3 4 5]);
end