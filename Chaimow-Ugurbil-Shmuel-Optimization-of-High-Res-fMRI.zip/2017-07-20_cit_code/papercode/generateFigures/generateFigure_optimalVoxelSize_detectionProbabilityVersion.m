function generateFigure_optimalVoxelSize_detectionProbabilityVersion(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_optimalVoxelQuantities'));

vPlotRange = [0 max([optVoxelPDetectSingle(:);optVoxelPDetectMulti(:);...
    optVoxelCor(:)])];
[~,rho] = meshgrid(deltaRange,rhoRange);
cycleLength = 1./rho;


%% visualize
columnHeight = 7;    % inch 9.45 = maximum
setFigureOptions;
c = get(0,'DefaultAxesColorOrder');

fontSize = 12;
set(0,'DefaultAxesFontSize',fontSize);

f = figure;

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));

p = panel();


% layout a variety of sub-panels
p.fontname = 'Arial';
p.fontsize = fontSize;

p.pack('h',[0.2 0.8]);
p(2).pack('v',[0.98 0.02]);
p(2,1).pack(3,3);
p(2,2).pack('h',3);


%% First figure: optimal voxel size
% FWHM = 0.5
% detect single
dcvisualize2d(p(2,1,1,1),optVoxelPDetectSingle(:,:,1),1./rhoRange,deltaRange,...
    '',...
    '',...
    {['\bf\color[rgb]{' sprintf('%f,%f,%f',c(2,:)) '}' ...
    'Univariate'],...
    'detection'},...
    'voxel width [mm]',vPlotRange);
set(gca,'XTickLabel','');


% detect multi
dcvisualize2d(p(2,1,1,2),optVoxelMVCNR(:,:,1),1./rhoRange,deltaRange,...
    '',...
    '',...
    {['\bf\color[rgb]{' sprintf('%f,%f,%f',c(5,:)) '}' ...
    'Multivariate'],...
    'detection/decoding'},...
    'voxel width [mm]',vPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');


% Correlation
dcvisualize2d(p(2,1,1,3),optVoxelCor(:,:,1),1./rhoRange,deltaRange,...
    '',...
    '',...
    ['\bf\color[rgb]{' sprintf('%f,%f,%f',c(1,:)) '}' ...
    'Reconstruction'],...
    'voxel width [mm]',vPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');

% FWHM = 1
% detect single
dcvisualize2d(p(2,1,2,1),optVoxelPDetectSingle(:,:,2),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',vPlotRange);
set(gca,'XTickLabel','');


% detect multi
p(2,1,2,1);
dcvisualize2d(p(2,1,2,2),optVoxelMVCNR(:,:,2),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',vPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');


% Correlation
dcvisualize2d(p(2,1,2,3),optVoxelCor(:,:,2),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',vPlotRange);
set(gca,'XTickLabel','');
set(gca,'YTickLabel','');


% FWHM = 2
% detect single
dcvisualize2d(p(2,1,3,1),optVoxelPDetectSingle(:,:,3),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',vPlotRange);


% detect multi
dcvisualize2d(p(2,1,3,2),optVoxelMVCNR(:,:,3),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',vPlotRange);
set(gca,'YTickLabel','');


% Correlation
cb = dcvisualize2d(p(2,1,3,3),optVoxelCor(:,:,3),1./rhoRange,deltaRange,...
    '',...
    '',...
    [],...
    'voxel width [mm]',vPlotRange,1);
set(gca,'YTickLabel','');
p(2,2,3).select(cb);



p(2,1).ylabel('relative irregularity (\delta/\rho)');
p(2,1).xlabel('columnar cycle [mm]');



p.de.margin = 5;
p.margintop = 20;
p.marginright = 10;
p(2,1).marginbottom = 15;

axes('Position',[0 0 1 1],'YDir','reverse','visible','off');
text(0.27,0.03,'Voxel width for maximizing:','FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');
text(0.01,0.12,{'BOLD PSF','FWHM = 0.5 mm'},'FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');
text(0.01,0.12+0.245,{'BOLD PSF','FWHM = 1 mm'},'FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');
text(0.01,0.12+2*0.245,{'BOLD PSF','FWHM = 2 mm'},'FontSize',12,'FontName','Arial','HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',[figNumberStr 'optimalVoxelSize']));
end


function h_colorbar_axis = dcvisualize2d(p,data,xRange,yRange,...
    xLabel,yLabel,titleText,barText,cRange,hBar,zeroContourOverlayData)
p.select();

xiRange = linspace(xRange(1),xRange(end),length(xRange));
yiRange = linspace(yRange(1),yRange(end),length(yRange));

[Y,X] = meshgrid(yRange,xRange);
[YI,XI] = meshgrid(yiRange,xiRange);

dataI = interp2(Y,X,data,YI,XI);

if exist('cRange','var')
    imagesc(xiRange,yiRange,dataI',cRange);
else
    imagesc(xiRange,yiRange,dataI');
end

axis image;
axis xy;
p.xlabel(xLabel);
p.ylabel(yLabel);

p.title(titleText);
axis square;

% if exist('zeroContourOverlayData','var')
%     hold on;
%     zeroContourOverlayDataI = interp2(Y,X,zeroContourOverlayData,YI,XI);
%     contour(xRange,yRange,zeroContourOverlayDataI',[0 0],'r');
%     hold off;
% end


if exist('hBar','var') && hBar
    h_colorbar_axis = colorbar('peer',gca,'h');
    h_colorbar_axis.Label.String = barText;
    x1=get(gca,'position');
    x=get(h_colorbar_axis,'Position');
    x(4)=0.02;
    set(h_colorbar_axis,'Position',x);   
    set(gca,'position',x1)
else
    h_colorbar_axis = [];
end
end
