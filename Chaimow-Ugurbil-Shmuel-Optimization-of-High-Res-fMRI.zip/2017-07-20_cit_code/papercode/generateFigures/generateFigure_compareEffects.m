function generateFigure_compareEffects(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_compareEffects.mat'));

%% visualize
columnHeight = 7;    % inch 9.45 = maximum
setFigureOptions;
c = get(0,'DefaultAxesColorOrder');
f = figure;

p = panel();


% layout a variety of sub-panels
p.fontname = 'Arial';
p.fontsize = 10;


d = 0.1;
p.pack('v',[(1-d)/4 (1-d)/4 (1-d)/4 d (1-d)/4]);

%% BOLD response amplitude
dataPDetect = [pDetectAvgMag7TGE;pDetectAvgMag3T;pDetectAvgMag7TSE];
dataRDecode = [rDecodeMag7TGE;rDecodeMag3T;rDecodeMag7TSE];
dataCor = [corMag7TGE;corMag3T;corMag7TSE];

%colors = {[0.5 0 0.5],'r','b'};
colors = {c(4,:),c(2,:),c(1,:)};

legendStrings = {[ num2str(100*b7TGE) '% (7T GE)'],...
    [ num2str(100*b3T) '% (3T GE)'],...
    [ num2str(100*b7TSE) '% (7T SE)']};
legendPosition = [0.08 0.785];
plotComparison(p(1),wRange,dataPDetect,dataRDecode,dataCor,colors,...
    legendStrings,legendPosition)

% c = [...
%     0.62   1      0.9    ;...
%     0.95      0.887  0.85   ;...
%     0.1  0.8654 1      ;...
%     0.7556 0.6691 0.8    ;...
%     0.238  0.7211 0.6740 ;...
%     0.58   0.67   0.9];
% set(0,'DefaultAxesColorOrder',hsv2rgb(c));
%c = get(0,'DefaultAxesColorOrder');

%% BOLD response point spread width
dataPDetect = [pDetectAvgPSF7TSE;pDetectAvgPSF7TGE;pDetectAvgPSF3T];
dataRDecode = [rDecodePSF7TSE;rDecodePSF7TGE;rDecodePSF3T];
dataCor = [corPSF7TSE;corPSF7TGE;corPSF3T];
%colors = {'b',[0.5 0 0.5],'r'};
colors = {c(1,:),c(4,:),c(2,:)};
legendStrings = {[ num2str(fwhm7TSE) ' mm (7T SE)'],...
    [ num2str(fwhm7TGE) ' mm (7T GE)'],...
    [ num2str(fwhm3T) ' mm (3T GE)']};
legendPosition = [0.08 0.585];
plotComparison(p(2),wRange,dataPDetect,dataRDecode,dataCor,colors,...
    legendStrings,legendPosition);
%p(1,2).title(['\bf\color[rgb]{' sprintf('%f,%f,%f',c(2,:)) '}'...
%    'Univariate detection']);
%p(1,3).title(['\bf\color[rgb]{' sprintf('%f,%f,%f',c(5,:)) '}'...
%    'Multivariate decoding']);
%p(1,4).title(['\bf\color[rgb]{' sprintf('%f,%f,%f',c(1,:)) '}'...
%    'Reconstruction']);


%% Noise characteristics
dataPDetect = [pDetectAvgNoise7T;pDetectAvgNoise3T];
dataRDecode = [rDecodeNoise7T;rDecodeNoise3T];
dataCor = [corNoise7T;corNoise3T];

%colors = {'b','r'};
colors = {c(1,:),c(2,:)};
legendStrings = {'7T Noise','3T Noise'};
legendPosition = [0.08 0.385];
plotComparison(p(3),wRange,dataPDetect,dataRDecode,dataCor,colors,...
    legendStrings,legendPosition);

%% Combined effects
dataPDetect = [pDetectAvg7TSE;pDetectAvg7TGE;pDetectAvg3T];
dataRDecode = [rDecode7TSE;rDecode7TGE;rDecode3T];
dataCor = [cor7TSE;cor7TGE;cor3T];

%colors = {'b',[0.5 0 0.5],'r'};
colors = {c(1,:),c(4,:),c(2,:)};

legendStrings = {'7T SE','7T GE','3T GE'};
legendPosition = [0.08 0.065];
plotComparison(p(5),wRange,dataPDetect,dataRDecode,dataCor,colors,...
    legendStrings,legendPosition);

p.de.margin = 10;
p.margintop = 10;

axes('Position',[0 0 1 1],'YDir','reverse','visible','off');
t1 = text(0.01,0.01,'Effect of:','FontSize',12,'FontName','Arial',...
    'HorizontalAlignment','left','VerticalAlignment','top');
t2 = text(0.01,0.05,{'\bfA \rmBOLD response','amplitude'},'FontSize',12,...
    'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t3 = text(0.01,0.25,{'\bfB \rmBOLD response','point-spread width'},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');
t4 = text(0.01,0.45,{'\bfC \rmField strength dependent','noise'},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');

t5 = text(0.01,0.77,{'\bfD \rmAll field strength and','pulse sequence specific','factors combined'},...
    'FontSize',12,'FontName','Arial','HorizontalAlignment','left',...
    'VerticalAlignment','top');

t6 = text(0.275+0*0.24,0.01,...
    'Univariate detection',...
    'FontSize',11,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(2,:));
t7 = text(0.275+1*0.24,0.01,...
    'Multivariate decoding',...
    'FontSize',11,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(5,:));
t8 = text(0.275+2*0.24,0.01,...
    'Reconstruction',...
    'FontSize',11,'FontName','Arial','HorizontalAlignment','left','FontWeight','Bold',...
    'VerticalAlignment','top','Color',c(1,:));


if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',[figNumberStr 'compareEffects_single']));
end

function plotComparison(p,wRange,dataSingle,dataMulti,dataCor,colors,...
    legendStrings,legendPosition)
xlabel = 'voxel width [mm]';

p.pack('h',4);
plotData(p(2), wRange, dataSingle, colors, ...
    xlabel, 'probability', '');
fprintf('\nUnivariate detection probability:\n');
[v,idx] = max(dataSingle,[],2);
for z=1:length(legendStrings)
    fprintf('%s: %.4f at %.2fmm\n',legendStrings{z},v(z),wRange(idx(z)));
end

plotData(p(3), wRange, dataMulti, colors, ...
    xlabel, 'accuracy', '');
fprintf('\nDecoding accuracy:\n');
[v,idx] = max(dataMulti,[],2);
for z=1:length(legendStrings)
    fprintf('%s: %.4f at %.2fmm\n',legendStrings{z},v(z),wRange(idx(z)));
end

axis([0 4 0.5 1]);
plotData(p(4), wRange, dataCor, colors, ...
    xlabel, 'correlation', '');
fprintf('\nPattern correlation:\n');
[v,idx] = max(dataCor,[],2);
for z=1:length(legendStrings)
    fprintf('%s: %.4f at %.2fmm\n',legendStrings{z},v(z),wRange(idx(z)));
end


[l1,icons1] = legend(legendStrings,'Box','off','FontSize',8,...
    'Location','NorthEast');
shortenLegendLines(icons1,0.05);

p = get(l1,'Position');
axes('Position',[0 0 1 1],'YDir','reverse','visible','off');
set(l1,'Position',[legendPosition p(3:4)]);
42;
end

function plotData(p, wRange, data, colors, ...
    xlabelText, ylabelText, titleText)
yRangeFactor = [0 1.2];
plotFunction = @plot;
plotDataGeneral(p,wRange,data,colors,xlabelText,ylabelText,titleText,...
    yRangeFactor,plotFunction);
end

function plotDataGeneral(p,wRange,data,colors,...
    xlabelText,ylabelText,titleText,yRangeFactor,plotFunction)
p.select();
hold on;

[~,maxIdx] = max(data,[],2);
[~,minIdx] = min(data,[],2);

for z=1:size(data,1)
    if (data(z,maxIdx(z))-data(z,minIdx(z)))<0.03
        maxIdx(z) = NaN;
    end
end

minData = min(data(:));
maxData = max(data(:));

for z=1:size(data,1)
    plotFunction(wRange,data(z,:),'Color',colors{z});
end

yRange = yRangeFactor .* [minData maxData];

noNanMaxIdx = maxIdx(~isnan(maxIdx));
if length(unique(noNanMaxIdx))==1
    line([wRange(noNanMaxIdx(1)) wRange(noNanMaxIdx(1))],...
        yRange,'Color','k','LineWidth',1,'LineStyle','--');
else
    for z=1:size(data,1)
        if ~isnan(maxIdx(z))
        line([wRange(maxIdx(z)) wRange(maxIdx(z))],...
            yRange,'Color',colors{z},'LineWidth',1,'LineStyle','--');
        end
    end
end

for z=1:size(data,1)
    plotFunction(wRange,data(z,:),'Color',colors{z});
end

axis([0 max(wRange) yRange]);
p.xlabel(xlabelText);
p.ylabel(ylabelText);
p.title(titleText);

axis square;
end
