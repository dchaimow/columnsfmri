function generateFigure_patternCorrelation_Individual
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');


% set parameters
parameters = cit_masterParameterSetting;
rng(parameters.randomNumberSeed);
N = parameters.N;
L = parameters.L;
sim = cdt_setupsim(N,L);

downFactors = parameters.downFactors;
wRange = sim.L./(downFactors*sim.N);

rho = parameters.rho;
delta = parameters.delta;
fwhm = parameters.fwhm7TGE;
b = parameters.beta7TGE;

noise = cdt_noise2(sim);
neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
bold = cdt_bold2(sim,fwhm,b,neuronal);

nT = parameters.nT;
TR = parameters.TR;
sliceThickness = parameters.sliceThickness;
noiseModel = '7T';

differentialFlag = true;

voxelV = sliceThickness.*wRange.^2;
noiseOfWSingleVoxel = cit_noiseModel(...
    voxelV,noiseModel,TR,1,nT,differentialFlag);

dispL = sqrt(parameters.Aflat);


%% A1
figureWidth = 0.8;
figureHeight = 0.8+0.3;
setFigureOptionsIndividual;
f = figure;
p = panel();
p.select();
p.fontsize = 10;
p.margin = 0;

imagesc(sim.x,sim.x,neuronal,[-1 1]*2*sqrt(8/pi));
colormap(gray);
axis image;
axis(dispL*[-1/2 1/2 -1/2 1/2]);
%title('neuronal pattern');
print('-dtiff','-r1000','-painters',...
    fullfile(rootDir,'figures','patternCorrelation_a1.tif'));

close(f);

c = corrcoef(neuronal,bold);
cor = c(1,2);

%% A2
figureWidth = 0.8;
figureHeight = 0.8+0.3;
setFigureOptionsIndividual;
f = figure;
p = panel();
p.select();
p.fontsize = 10;
p.margin = 0;
imagesc(sim.x,sim.x,bold,[-1 1]*2*b*sqrt(8/pi));
colormap(gray);
disp(['R = ' num2str(cor,2)]);
axis image;
axis(dispL*[-1/2 1/2 -1/2 1/2]);
print('-dtiff','-r1000','-painters',...
    fullfile(rootDir,'figures','patternCorrelation_a2.tif'));
close(f);


%% B and C
dfIdcs = [15 14 13 12 11];
nDF = length(dfIdcs);

for z=1:nDF

    [imgVoxel,upVoxel,corVoxel] = simulateImage(...
        sim,neuronal,bold,downFactors(dfIdcs(z)),0);
    nl = fminsearch(...
        @(x) findNoiseLevelForCor(...
        corVoxel,sim,neuronal,bold,1,x),0.1);
    [imgNoise,upNoise,corNoise] = simulateImage(...
        sim,neuronal,bold,1,nl);
       
    % B 
    figureWidth = 0.8;
    figureHeight = 0.8+0.3;
    setFigureOptionsIndividual;
    f = figure;
    p = panel();
    p.select();
    p.fontsize = 10;
    p.margin = 0;
    imagesc(sim.x,sim.x,upNoise,[-1 1]*2*b*sqrt(8/pi));
    colormap(gray);
    axis image;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    axis(dispL*[-1/2 1/2 -1/2 1/2]);
    disp(['R = ' num2str(corNoise,2)]);
    print('-dtiff','-r1000','-painters',...
        fullfile(rootDir,'figures',...
        ['patternCorrelation_b' num2str(z) '.tif']));
    close(f);
    
    % C 1
    figureWidth = 0.8;
    figureHeight = 0.8+0.3;
    setFigureOptionsIndividual;
    f = figure;
    p = panel();
    p.select();
    p.fontsize = 10;
    p.margin = 0;
    imagesc(sim.x,sim.x,imgVoxel,[-1 1]*2*b*sqrt(8/pi));
    colormap(gray);
    axis image;
    axis off;
    axis(dispL*[-1/2 1/2 -1/2 1/2]);
    print('-dtiff','-r1000','-painters',...
        fullfile(rootDir,'figures',...
        ['patternCorrelation_c1.' num2str(z) '.tif']));
    close(f);
    
     % C 2
    figureWidth = 0.8;
    figureHeight = 0.8+0.3;
    setFigureOptionsIndividual;
    f = figure;
    p = panel();
    p.select();
    p.fontsize = 10;
    p.margin = 0;
    imagesc(sim.x,sim.x,upVoxel,[-1 1]*2*b*sqrt(8/pi));
    colormap(gray);
    axis image;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    axis(dispL*[-1/2 1/2 -1/2 1/2]);
    disp(['R = ' num2str(corVoxel,2)]);
    print('-dtiff','-r1000','-painters',...
        fullfile(rootDir,'figures',...
        ['patternCorrelation_c2.' num2str(z) '.tif']));
    close(f);  
end



%% D
% D1
load(fullfile(dataDir,'data_voxelSizeDependence.mat'));

figureWidth = 2.1;
figureHeight = 1.7;
setFigureOptionsIndividual;
c = get(0,'DefaultAxesColorOrder');
f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

ax = visualize1d2func(wRange,[cor0; 1./noiseOfWSingleVoxel]','voxel width [mm]',...
    {'correlation','SNR'},'',{'k',c(3,:)});
axis(ax(1),[0 4 0 max(cor0)*1.2]);
axis(ax(2),[0 4 0 max(1./noiseOfWSingleVoxel)*1.2]);
set(ax(1),'YTick',[0 0.2 0.4 0.6 0.8 1]);
set(ax(2),'YTick',[0 200 400 600 800]);
putGridLines(1,[],1);
axis(ax(1),'square'); axis(ax(2),'square'); 
box off;
p.margintop = 0;
p.marginleft = 11;
p.marginright = 7;
p.marginbottom = 10;
print('-dtiff','-r1000','-painters',...
    fullfile(rootDir,'figures','patternCorrelation_d1.tif'));
close(f);

% D2
figureWidth = 2.1;
figureHeight = 1.7;
setFigureOptionsIndividual;
f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

plotBaseColor = c(1,:);
plotColors =  (1-steps3(end:-1:1)') * [1 1 1] + steps3(end:-1:1)' * plotBaseColor;
%plotColors = (1-[1 0.7 0.4]') * [1 1 1] + [1 0.7 0.4]' * plotBaseColor;
visualize1d(wRange,cor3,'voxel width [mm]',...
    'correlation','',plotColors(1,:));
hold on;
visualize1d(wRange,cor2,'voxel width [mm]',...
    'correlation','',plotColors(2,:));
visualize1d(wRange,cor1,'voxel width [mm]',...
    'correlation','',plotColors(3,:));
[hl,icons] =  legend({['N_t=' num2str(nT*10)],...
     ['N_t=' num2str(nT)],...
     ['N_t=' num2str(nT/10)]},'Location','southeast','box','off');
shortenLegendLines(icons,0.05);
visualize1d(wRange,cor2,'voxel width [mm]',...
    'correlation','',plotColors(2,:));
axis([0 4 0 maxCor*1.2]);
line([wRange(idxCor2) wRange(idxCor2)],[0 maxCor*1.2],'LineStyle',':',...
    'Color',c(1,:));

text(wRange(idxCor2)+0.1,0.9*maxCor*1.2,['w_{opt}(1000) = ' ...
    num2str(wRange(idxCor2),2) ' mm'],'FontSize',10);
axis square;
box off;
%title('Optimal voxel width for reconstruction');
p.margintop = 0;
p.marginleft = 11;
p.marginright = 7;
p.marginbottom = 10;
print('-dtiff','-r1000','-painters',...
    fullfile(rootDir,'figures','patternCorrelation_d2.tif'));
close(f);


%% E
%dfIdcs = [10 12 13 14 16 17 20 24 32];
dfIdcs = [24 19 16 14 12];
nDF = length(dfIdcs);
for z=1:nDF   
    
    [imgVoxel,upVoxel,corVoxel] = simulateImage(...
        sim,neuronal,bold,downFactors(dfIdcs(z)),...
        noiseOfWSingleVoxel(dfIdcs(z)));
    
    % E1
    figureWidth = 0.8;
    figureHeight = 0.8+0.3;
    setFigureOptionsIndividual;
    f = figure;
    p = panel();
    p.select();
    p.fontsize = 10;
    p.margin = 0;
    imagesc(sim.x,sim.x,imgVoxel,[-1 1]*2*b*sqrt(8/pi));
    colormap(gray);
    axis image;
    axis off;
    axis(dispL*[-1/2 1/2 -1/2 1/2]);
    print('-dtiff','-r1000','-painters',...
        fullfile(rootDir,'figures',...
        ['patternCorrelation_e1.' num2str(z) '.tif']));
    close(f);  
    
    % E2
    figureWidth = 0.8;
    figureHeight = 0.8+0.3;
    setFigureOptionsIndividual;
    f = figure;
    p = panel();
    p.select();
    p.fontsize = 10;
    p.margin = 0;
    imagesc(sim.x,sim.x,upVoxel,[-1 1]*2*b*sqrt(8/pi));
    colormap(gray);
    axis image;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);    
    axis(dispL*[-1/2 1/2 -1/2 1/2]);
    disp(['R = ' num2str(corVoxel,2)]);
    print('-dtiff','-r1000','-painters',...
        fullfile(rootDir,'figures',...
        ['patternCorrelation_e2.' num2str(z) '.tif']));
    close(f);  
    
end

end

function y = findNoiseLevelForCor(...
    targetCor,sim,neuronal,bold,downFactor,noiseLevel)
[~,~,cor] = simulateImage(...
    sim,neuronal,bold,downFactor,noiseLevel);
y = (cor-targetCor).^2;
end

function showSimulatedImage(sim,neuronal,bold,downFactor,noiseLevel)
[img,upVoxel,cor] = simulateImage(...
    sim,neuronal,bold,downFactor,noiseLevel);
imagesc(sim.x,sim.x,upVoxel,[-1 1]*prctile(img(:),99.99));
axis image;
axis(dispL*[-1/2 1/2 -1/2 1/2]);
title(num2str(cor));
end

function [img,upVoxel,cor] = simulateImage(...
    sim,neuronal,bold,downFactor,noiseLevel)
rng(23);
[voxel,~] = cdt_mri2(sim,downFactor,bold);
img = voxel + noiseLevel * randn(size(voxel));
upVoxel = real(upSample(img,sim));
c = corrcoef(neuronal,upVoxel);
cor = c(1,2);
end

function upPattern = upSample(pattern,sim)
Fy = fft2(pattern);
[m,n] = size(Fy); % size of the original matrix
nzsr = sim.N - m; % number of zero rows to add
nzsc = sim.N - n; % number of zero columns to add
% quadrants of the FFT, starting in the upper left
q1 = Fy(1:m/2,1:n/2);
q2 = Fy(1:m/2,n/2+1:n);
q3 = Fy(m/2+1:m,n/2+1:n);
q4 = Fy(m/2+1:m,1:n/2);
zpdr = zeros(nzsr,n/2);  % zeropad rows to insert
zpdc = zeros(nzsr+m,nzsc); % zeropad columns to insert
zpdFy = [ [q1;zpdr;q4] , zpdc , [q2;zpdr;q3] ]; % insert the zeros
upPattern = real(ifft2(zpdFy)) * sim.N^2/(m*n) ;
end

function AX=visualize1d2func(xRange,data,xLabel,yLabel,titleText,lineStyle)
[AX,H1,H2] = plotyy(xRange, data(:,1),xRange,data(:,2),'plot');
hold on;
set(get(AX(1),'Ylabel'),'String',yLabel(1));
set(get(AX(1),'Ylabel'),'FontSize',8);
set(get(AX(2),'Ylabel'),'String',yLabel(2));
set(get(AX(2),'Ylabel'),'FontSize',12);
xlabel(xLabel);
if exist('lineStyle','var')
    set(H1,'Color',lineStyle{1});
    set(AX(1),'YColor',lineStyle{1})
    set(get(AX(1),'Ylabel'),'Color',lineStyle{1});
    set(H2,'Color',lineStyle{2});
    set(AX(2),'YColor',lineStyle{2})
    set(get(AX(2),'Ylabel'),'Color',lineStyle{2});
end
title(titleText);
uistack(AX(1));
end

function visualize1d(xRange,data,xLabel,yLabel,titleText,lineStyle)
if ~exist('lineStyle','var')
    lineStyle = 'k';
end

if isnumeric(lineStyle)
    plot(xRange, data,'Color',lineStyle);
else
    plot(xRange, data,lineStyle);
end
xlabel(xLabel);
ylabel(yLabel);
title(titleText);
end

function putGridLines(xRes,yRes,leaveOutLast)
ax = axis(gca);
if ~isempty(xRes)
    startX = floor(ax(1)/xRes)*xRes;
    endX = ceil(ax(2)/xRes)*xRes;
    if exist('leaveOutLast','var') && leaveOutLast
        endX = endX - xRes;
    end
    for x=startX:xRes:endX
        l = line([x x],[ax(3) ax(4)],'LineStyle',':','Color','k','LineWidth',1);
        uistack(l,'bottom');
    end
end
if ~isempty(yRes)
    startY = ceil(ax(3)/yRes)*yRes;
    endY = ceil(ax(4)/yRes)*yRes;
    for y=startY:yRes:endY
        l = line([ax(1) ax(2)],[y y],'LineStyle',':','Color','k','LineWidth',1);
        uistack(l,'bottom');
    end
end
end

