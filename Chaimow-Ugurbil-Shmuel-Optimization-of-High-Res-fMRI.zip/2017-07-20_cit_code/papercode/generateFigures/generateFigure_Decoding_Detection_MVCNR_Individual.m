function generateFigure_Decoding_Detection_MVCNR_Individual
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_allDecodingDetectionCNRnVoxels4curves'));

%% A
pDetectAnalytic = zeros(size(pDetect));
pDetectAnalytic(1,:) = detectionProbability(cnrRange,nVoxelRange(1));
pDetectAnalytic(2,:) = detectionProbability(cnrRange,nVoxelRange(2));
pDetectAnalytic(3,:) = detectionProbability(cnrRange,nVoxelRange(3));
pDetectAnalytic(4,:) = detectionProbability(cnrRange,nVoxelRange(4));

figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;

f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

l1 = plot(cnrRange,pDetect(1,:),'o','Color',cs(c(4,:),steps4(1)));
hold on;
plot(cnrRange,pDetectAnalytic(1,:),'-','Color',cs(c(4,:),steps4(1)));

l2 = plot(cnrRange,pDetect(2,:),'o','Color',cs(c(4,:),steps4(2)));
plot(cnrRange,pDetectAnalytic(2,:),'-','Color',cs(c(4,:),steps4(2)));

l3 = plot(cnrRange,pDetect(3,:),'o','Color',cs(c(4,:),steps4(3)));
plot(cnrRange,pDetectAnalytic(3,:),'-','Color',cs(c(4,:),steps4(3)));

l4 = plot(cnrRange,pDetect(4,:),'o','Color',cs(c(4,:),steps4(4)));
plot(cnrRange,pDetectAnalytic(4,:),'-','Color',cs(c(4,:),steps4(4)));

axis([0 5 0 1.1]);
set(gca,'YTick',[0.05 1]);
%xlabel('CNR');
ylabel('probability');
[lg1,icns1] = legend([l4,l3,l2,l1],{'1000 voxels','100 voxels','10 voxels','1 voxel'},...
    'location','se','Box','off');
moveLegendMarkers(icns1,0.1);
lg1.Position(1) = 0.4;
lg1.Position(2) = 0.12;
box off;


p.margintop = 0;
p.marginleft = 13;
p.marginright = 5;
p.marginbottom = 5;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_a.tif'));
close(f);


%% B
figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;


f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

l1 = plot(cnrRange,pDecode(1,:,1),'o','Color',cs(c(5,:),steps4(1)));
hold on;
plot(cnrRange,pDetectAnalytic(1,:),'-','Color',cs(c(4,:),steps4(1)));

l2 = plot(cnrRange,pDecode(2,:,1),'o','Color',cs(c(5,:),steps4(2)));
plot(cnrRange,pDetectAnalytic(2,:),'-','Color',cs(c(4,:),steps4(2)));

l3 = plot(cnrRange,pDecode(3,:,1),'o','Color',cs(c(5,:),steps4(3)));
plot(cnrRange,pDetectAnalytic(3,:),'-','Color',cs(c(4,:),steps4(3)));

l4 = plot(cnrRange,pDecode(4,:,1),'o','Color',cs(c(5,:),steps4(4)));
plot(cnrRange,pDetectAnalytic(4,:),'-','Color',cs(c(4,:),steps4(4)));

axis([0 5 0 1.1]);
set(gca,'YTick',[0.05 1]);
%xlabel('CNR');
ylabel('probability');

%lg2 = legend([l1,l2,l3,l4],{'1 voxel','10 voxels','100 voxels','1000 voxels'},...
%    'location','se','Box','off');
box off;

p.margintop = 0;
p.marginleft = 13;
p.marginright = 5;
p.marginbottom = 5;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_b.tif'));
close(f);

%% C
figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;

f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

l1 = plot(cnrRange,meanClassPerf(1,:,1),'o','Color',cs(c(5,:),steps4(1)));
hold on;
l2 = plot(cnrRange,meanClassPerf(2,:,1),'o','Color',cs(c(5,:),steps4(2)));
l3 = plot(cnrRange,meanClassPerf(3,:,1),'o','Color',cs(c(5,:),steps4(3)));
l4 = plot(cnrRange,meanClassPerf(4,:,1),'o','Color',cs(c(5,:),steps4(4)));

axis([0 5 0 1.1]);
set(gca,'YTick',[0 0.5 1]);
set(gca,'YTickLabel',{'0','1/2','1'});
%xlabel('CNR');
ylabel('accuracy');
[lg3,icns3] = legend([l4,l3,l2,l1],{'1000 voxels','100 voxels','10 voxels','1 voxel'},...
    'location','se','Box','off');
box off;
moveLegendMarkers(icns3,0.1);
lg3.Position(1) = 0.4;
lg3.Position(2) = 0.12;

p.margintop = 0;
p.marginleft = 13;
p.marginright = 5;
p.marginbottom = 5;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_c.tif'));
close(f);

%% D
figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;

f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

l1 = plot(meanClassPerf(1,:,1),pDecode(1,:,1),'-','Color',cs(c(5,:),steps4(1)));
hold on;
l2 = plot(meanClassPerf(2,:,1),pDecode(2,:,1),'-','Color',cs(c(5,:),steps4(2)));
l3 = plot(meanClassPerf(3,:,1),pDecode(3,:,1),'-','Color',cs(c(5,:),steps4(3)));
l4 = plot(meanClassPerf(4,:,1),pDecode(4,:,1),'-','Color',cs(c(5,:),steps4(4)));
hold off;

axis([0.5 1 0 1.1]);
set(gca,'YTick',[0.05 1]);
set(gca,'XTick',[0.5 1]);
set(gca,'XTickLabel',{'1/2','1'});
xlabel('accuracy');
ylabel('probability');
[lg4,icns4] = legend([l4,l3,l2,l1],{'1000 voxels','100 voxels','10 voxels','1 voxel'},...
    'location','se','Box','off');
lg4.Position(1) = 0.35;
lg4.Position(2) = 0.25;
shortenLegendLines(icns4,0.1);

box off;

p.margintop = 0;
p.marginleft = 13;
p.marginright = 5;
p.marginbottom = 10;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_d.tif'));
close(f);


%% MCNR part
load(fullfile(dataDir,'data_allDecodingDetectionCNRnVoxels'));
MVCNR = CNR(:).*NVOXELS(:).^a;

%% E
figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;

f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

%numSteps = 5;
%[h,C] = contourf(pDetect',linspace(0,1+eps,numColors+1));
%colorbar;
%caxis([0 1]);
%colormap(parula(numSteps))
imagesc(pDetect',[0 1]);axis xy;
cb = colorbar;
%cb.Position(1) = 0.9;
cb.Label.String = 'probability';
axis equal;
axis tight;
box on;

g = gca;

%g.XTick = round(linspace(nNVoxels/6,...
%    nNVoxels-nNVoxels/6,3));

g.XTick = [1 nNVoxels/2 nNVoxels];
g.XTickLabel = num2str(nVoxelRange(g.XTick)');
xlabel('N_{voxels} (log-scale)');

%g.YTick = round(linspace(nCNR/8,nCNR-nCNR/8,3));
g.YTick = [1 nCNR/2 nCNR];
g.YTickLabel = num2str(cnrRange(g.YTick)',2);
ylabel('CNR (log-scale)');


p.margintop = 2;
p.marginleft = 15;
p.marginright = 17;
p.marginbottom = 10;

cb.Position(1) = 0.74;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_e.tif'));
close(f);


%F
figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;

f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

plot(MVCNR(:),pDetect(:),'.','Color',cs(c(4,:),1));
axis([0 10 0 1.1]);
set(gca,'YTick',[0.05 1]);

%xlabel('mv-CNR');
ylabel('probability');
box off;

p.margintop = 0;
p.marginleft = 13;
p.marginright = 5;
p.marginbottom = 5;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_f.tif'));
close(f);


%G
addpath('../simulateDecodingDistribution/');
figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;

f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;

h = zeros(1,3);
for z=1:nClassRange    
    h(z) = plot(sort(MVCNR(:)),...
        f_pDecode{z}(sort(MVCNR(:))),'Color',cs(c(5,:),steps3(3-z+1)));
    hold on;
    plot(MVCNR(:),reshape(pDecode(:,:,z),[],1),...
        '.','Color',cs(c(5,:),1-(z-1)*0.3));
end
axis([0 10 0 1.1]);
set(gca,'YTick',[0.05 1]);

%xlabel('mv-CNR');
ylabel('probability');

[lgg,iconsg] = legend(h,{'2 classes','4 classes','8 classes'},'Box','off',...
    'location','se');
box off;
shortenLegendLines(iconsg,0.1);

p.margintop = 0;
p.marginleft = 13;
p.marginright = 5;
p.marginbottom = 5;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_g.tif'));
close(f);



%h
figureWidth = 2.2;
figureHeight = 1.6;
setFigureOptionsIndividual;



f = figure;
p = panel();
p.fontsize = 10;
p.select();
p.margin = 0;


h = zeros(1,3);
for z=1:nClassRange    
    h(z) = plot(sort(MVCNR(:)),...
        f_meanClassPerf{z}(sort(MVCNR(:))),'Color',cs(c(5,:),steps3(3-z+1)));
    axis([0 50 0 1]);
    hold on;
    plot(MVCNR(:),reshape(meanClassPerf(:,:,z),[],1),...
        '.','Color',cs(c(5,:),1-(z-1)*0.3));
end
axis([0 10 0 1.1]);
set(gca,'YTick',[0 0.125 0.25 0.5 1]);
set(gca,'YTickLabel',{'0','1/8','1/4','1/2','1'});


%xlabel('mv-CNR');
ylabel('accuracy');

%legend(h,{'2 classes','4 classes','8 classes'},'Box','off',...
%    'location','se');
box off;

p.margintop = 0;
p.marginleft = 13;
p.marginright = 5;
p.marginbottom = 5;
print('-dtiff','-r1000','-painters',fullfile(rootDir,'figures','mvcnrFigure_h.tif'));
close(f);


42;

end
function cs = cs(c,s)
cs = s*c+(1-s)*[1 1 1];
end

function visualize1d(xRange,data,xLabel,yLabel,titleText,lineStyle)
if ~exist('lineStyle','var')
    lineStyle = 'k';
end

if isnumeric(lineStyle)
    plot(xRange, data,'Color',lineStyle);
else
    plot(xRange, data,lineStyle);
end
xlabel(xLabel);
ylabel(yLabel);
title(titleText);
end

function [optVoxel,optVal] = findMax(A,wRange)
sz = size(A);
AFlat = reshape(A,[],sz(end));
optVoxel = zeros(size(AFlat,1),1);
optVal = zeros(size(AFlat,1),1);
for z=1:size(AFlat,1)
    optVal(z) = max(AFlat(z,:));
    optVoxel(z) = ...
    mean([wRange(find(AFlat(z,:)==optVal(z),1,'first')),...
        wRange(find(AFlat(z,:)==optVal(z),1,'last'))]);
end
optVoxel = reshape(optVoxel,[sz(1:end-1) 1]);
optVal = reshape(optVal,[sz(1:end-1) 1]);
end