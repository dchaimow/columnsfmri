function generateFigure_permutation(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_allDecodingDetectionCNRnVoxels_permutation'));

columnHeight = 5;    % inch 9.45 = maximum
setFigureOptions;
f = figure;

fontSize = 14;
set(0,'DefaultAxesFontSize',fontSize);

p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;

p.select()
plot(cnrRange,pDecode);
hold on;
plot(cnrRange,pDecodePermutation);
hold off;
xlabel('CNR');
ylabel('probability');
[~,icons] = legend({'null-hypothesis simulation','permutation testing'},...
    'location','nw','Box','off');
set(gca,'YTick',[0.05 1]);
shortenLegendLines(icons,0.1);
axis([0 1 0 1]);
box off;


p.margintop =  25;
p.marginleft =  25;
p.marginright = 15;
%p.marginleft = 15;
%p.marginbottom = 12;
%p.margintop = 20;
%p(1,1).marginright = 30;



axes('Position',[0 0 1 1],'YDir','reverse','visible','off');

t1 = text(0.04, 0.04,...
    {'Probability of significant decoding from 100 voxels as assessed by',...
    'simulating the null-hypothesis compared to permutation testing'},...
    'FontSize',14,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',[figNumberStr 'permutationAnalysis']));
end