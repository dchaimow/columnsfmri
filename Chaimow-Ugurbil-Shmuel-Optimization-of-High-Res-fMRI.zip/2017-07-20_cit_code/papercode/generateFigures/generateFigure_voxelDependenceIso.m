function generateFigure_voxelDependenceIso(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_voxelSizeDependence.mat'));
dataMVCNR = load(fullfile(dataDir,...
    'data_allDecodingDetectionCNRnVoxels'));

% fraction of contrastRange in which 10%, 20%, ... of voxel responses lie
columnHeight = 6;    % inch 9.45 = maximum
setFigureOptions;
c = get(0,'DefaultAxesColorOrder');

f = figure;

fontSize = 12;
set(0,'DefaultAxesFontSize',fontSize);

p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;

p.pack(2,2);

p(1,1).select();
plot(wRange,snr2D);
hold on;
plot(wRange,snrIso);
legend({'2.5 mm slice','isotropic voxels'},'location','se','box','off')
xlabel('voxel width [mm]');
ylabel('SNR');
box off;

p(1,2).select();
plot(wRange,cnr);
hold on;
plot(wRange,cnrIso);
legend({'2.5 mm slice','isotropic voxels'},'location','ne','box','off')
xlabel('voxel width [mm]');
ylabel('CNR');
box off;

p(2,1).select();
semilogy(wRange,nVoxels);
hold on;
semilogy(wRange,nVoxelsIso);
legend({['2.5 mm slice covering' char(10) 'a 87 mm^2 patch'],...
    ['isotropic voxels covering' char(10) 'one hemisphere of V1']},...
    'location','ne','box','off')
xlabel('voxel width [mm]');
ylabel('number of voxels');
box off;

p(2,2).select();
mvcnr = cnr.*(nVoxels).^(dataMVCNR.a);
mvcnrIso = cnrIso.*(nVoxelsIso).^(dataMVCNR.a);
plot(wRange,dataMVCNR.f_meanClassPerf{2}(mvcnr));
hold on;
plot(wRange,dataMVCNR.f_meanClassPerf{2}(mvcnrIso));
legend({'2.5 mm slice','isotropic voxels'},'location','ne','box','off')
xlabel('voxel width [mm]');
ylabel('accuracy');
axis([0 4 0 1.1]);
box off;

c = get(0,'DefaultAxesColorOrder');
[max2d,max2dIdx] = max(dataMVCNR.f_meanClassPerf{2}(mvcnr));
[max3d,max3dIdx] = max(dataMVCNR.f_meanClassPerf{2}(mvcnrIso));
line(wRange(max2dIdx)*[1 1],[0 1],'Color',c(1,:),'LineStyle',':');
line(wRange(max3dIdx)*[1 1],[0 1],'Color',c(2,:),'LineStyle',':');
disp(['max accuracy 2d = ' num2str(max2d)...
    ' at w = ' num2str(wRange(max2dIdx))]);
disp(['max accuracy 3d = ' num2str(max3d)...
    ' at w = ' num2str(wRange(max3dIdx))]);

p.de.margin = 25;
p.margintop =  15;
%p.marginright = 15;
%p.marginleft = 15;
%p.marginbottom = 12;
%p.margintop = 20;
%p(1,1).marginright = 30;



axes('Position',[0 0 1 1],'YDir','reverse','visible','off');

t1 = text(0.0238, 0.0,...
    'A  SNR ',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t2 = text(0.5496, 0.0,...
    'B CNR',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t3 = text(0.0238, 0.5023,...
    'C Number of voxels',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t4 = text(0.5496, 0.5023,...
    {'D Decoding accuracy',...
    '(4 orientations)'},...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(rootDir,'figures',[figNumberStr 'voxelSizeDependenceIso']));
end