function generateFigure_patternParametrizationBoth(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');
addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));

figdir = fullfile(rootDir,'figures');

parameters = cit_masterParameterSetting;
rhoRange = parameters.parametrizationFigure.rhoRange;
deltaRange = parameters.parametrizationFigure.deltaRange;
nDelta = length(deltaRange);
nRho  = length(rhoRange);

columnHeight = 2 * (1+nRho);
setFigureOptions;
f = figure;
p = panel();
p.fontname = 'Arial';
p.fontsize = 10;

p.pack('v',2);

showPatterns(p(1));
showSpectra(p(2));

p.de.margin = 5;
p.marginleft = 25;
p.margintop = 15;
p(2).margintop = 15;


axes('Position',[0 0.5 1 0.5],'YDir','reverse','visible','off');
text(0.4,0.02,'relative irregularity (\delta/\rho)',...
    'FontSize',12,'FontName','Arial',...
    'HorizontalAlignment','left','VerticalAlignment','top');
text(0.025,0.74,'spatial frequency (\rho)',...
    'FontSize',12,'FontName','Arial',...
    'HorizontalAlignment','left','VerticalAlignment','top',...
    'Rotation',90);
text(0.0250,0.03 ,'A','FontSize',14,'FontName','Arial',...
    'FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

axes('Position',[0 0 1 0.5],'YDir','reverse','visible','off');
text(0.025,0.6706,'spatial frequency (\rho)',...
    'FontSize',12,'FontName','Arial',...
    'HorizontalAlignment','left','VerticalAlignment','top',...
    'Rotation',90);
text(0.0250,0.03 ,'B','FontSize',14,'FontName','Arial',...
    'FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
    fullfile(figdir,[figNumberStr 'patternParametrization']));
    
end

function showPatterns(p)
parameters = cit_masterParameterSetting;
rhoRange = parameters.parametrizationFigure.rhoRange;
deltaRange = parameters.parametrizationFigure.deltaRange;
nDelta = length(deltaRange);
nRho  = length(rhoRange);


p.pack(nRho,nDelta);

% set up simulation
N = parameters.N;
L = parameters.L;

rng(parameters.randomNumberSeed);
sim = cdt_setupsim(N,L);


dispL = sqrt(parameters.Aflat);

x1disp = sim.x1(abs(sim.x1)<=dispL/2 & abs(sim.x2)<=dispL/2);
xdisprange = unique(x1disp(:,1));
dispN = length(xdisprange);


noise = cdt_noise2(sim);

for zDelta = 1:length(deltaRange)
    for zRho=1:length(rhoRange)
        rho = rhoRange(zRho);
        delta = deltaRange(zDelta);
        p(zRho,zDelta).select();
        
        neuronal = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
        imagesc(xdisprange,xdisprange,neuronal(1:dispN,1:dispN),[-3 3]);
        
        axis equal;
        axis tight;
        if zRho == 1
            if delta == 0
                title('\delta/\rho ~ 0','FontWeight','normal');
            else
                title(['\delta/\rho = ' num2str(delta)],'FontWeight','normal');
            end
        end
        
        if zDelta == 1
            ylabel(['\rho = ' num2str(rho)]);
        else
            set(gca,'YTickLabel','');
        end
        
        if zRho == nRho
            %xlabel('space [mm]');
        else
            set(gca,'XTickLabel','');
        end
       
        colormap gray;
    end
end
p(3).xlabel('space [mm]');

p.de.margin = 5;
p.marginleft = 25;
p.margintop = 15;

end


function showSpectra(p)
parameters = cit_masterParameterSetting;
rhoRange = parameters.parametrizationFigure.rhoRange;
deltaRange = parameters.parametrizationFigure.deltaRange;
nDelta = length(deltaRange);
nRho  = length(rhoRange);

p.pack(nRho,nDelta);

% set up simulation
N = parameters.N;
L = parameters.L;

rng(parameters.randomNumberSeed);
sim = cdt_setupsim(N,L);


dispL = 24;
x1disp = sim.x1(abs(sim.x1)<=dispL/2 & abs(sim.x2)<=dispL/2);
xdisprange = unique(x1disp(:,1));


dispKmax = 2;
k1disp = sim.k1(abs(sim.k1)<=dispKmax & abs(sim.k2)<=dispKmax);
kdisprange = unique(k1disp(:,1));
dispN = length(kdisprange);


noise = cdt_noise2(sim);

for zDelta = 1:length(deltaRange)
    for zRho=1:length(rhoRange)
        rho = rhoRange(zRho);
        delta = deltaRange(zDelta);
        p(zRho,zDelta).select();
        [~,FORIENT] = cdt_orient2SimpleGaussian(sim,rho,delta,noise);
        FORIENT = 1 - FORIENT/max(FORIENT(:));
        imagesc(sim.k,sim.k,FORIENT);
        axis([-dispKmax dispKmax -dispKmax dispKmax]);
        axis equal;
        colormap gray        
%         if zRho == 1
%             if delta == 0
%                 title('\delta/\rho ~ 0','FontWeight','normal');
%             else
%                 title(['\delta/\rho = ' num2str(delta)],'FontWeight','normal');
%             end
%         end
        
        if zDelta == 1
            ylabel(['\rho = ' num2str(rho)]);
        else
            set(gca,'YTickLabel','');
        end
        
        if zRho == nRho
            %xlabel('space [mm]');
        else
            set(gca,'XTickLabel','');
        end
        
    end
end

p(3).xlabel('spatial frequency [1/mm]');

p.de.margin = 5;
p.marginleft = 25;
p.margintop = 15;

end


