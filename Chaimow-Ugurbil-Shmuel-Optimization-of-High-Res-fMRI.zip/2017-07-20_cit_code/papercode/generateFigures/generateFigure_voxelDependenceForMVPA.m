function generateFigure_voxelDependenceForMVPA(figNumber)
rootDir = fullfile(fileparts(mfilename('fullpath')),'..');

addpath(rootDir);
addpath(fullfile(rootDir,'calcData'));
dataDir = fullfile(rootDir,'data');

load(fullfile(dataDir,'data_voxelSizeDependence.mat'));
dataMVCNR = load(fullfile(dataDir,...
    'data_allDecodingDetectionCNRnVoxels'));

mvcnr = cnr.*nVoxels.^(dataMVCNR.a);
pDecode{1} = dataMVCNR.f_pDecode{1}(mvcnr);
pDecode{2} = dataMVCNR.f_pDecode{2}(mvcnr);
pDecode{3} = dataMVCNR.f_pDecode{3}(mvcnr);
rDecode{1} = dataMVCNR.f_meanClassPerf{1}(mvcnr);
rDecode{2} = dataMVCNR.f_meanClassPerf{2}(mvcnr);
rDecode{3} = dataMVCNR.f_meanClassPerf{3}(mvcnr);
[~,maxIdx] = max(mvcnr);

% visualize
columnHeight = 3.5;    % inch 9.45 = maximum
setFigureOptions;
f = figure;


c = get(0,'DefaultAxesColorOrder');

fontSize = 12;
set(0,'DefaultAxesFontSize',fontSize);

p = panel();
p.fontname = 'Arial';
p.fontsize = fontSize;

p.pack(1,2);

p(1,1).select();
plotBaseColor = c(5,:);
plotColors =  (1-steps3(end:-1:1)') * [1 1 1] + steps3(end:-1:1)' * plotBaseColor;
%plotColors = (1-[1 0.7 0.4]') * [1 1 1] + [1 0.7 0.4]' * plotBaseColor;
visualize1d(wRange,rDecode{1},'voxel width [mm]',...
    'accuracy','',plotColors(1,:));
hold on;
visualize1d(wRange,rDecode{2},'voxel width [mm]',...
    'accuracy','',plotColors(2,:));
visualize1d(wRange,rDecode{3},'voxel width [mm]',...
    'accuracy','',plotColors(3,:));
[~,icons] =  legend({'2 classes','4 classes','8 classes'},...
    'Location','northeast','box','off');
shortenLegendLines(icons,0.05);
axis([0 4 0 1.1]);
line([wRange(maxIdx) wRange(maxIdx)],[0 1],'LineStyle',':',...
    'Color',plotColors(1,:));

text(wRange(maxIdx)+0.1,1.06,['w_{opt} = ' ...
    num2str(wRange(maxIdx),2) ' mm'],'FontSize',12);
%putGridLines(1,[]);
axis square;
box off;

p(1,2).select();
plotBaseColor = c(5,:);
plotColors =  (1-steps3(end:-1:1)') * [1 1 1] + steps3(end:-1:1)' * plotBaseColor;
%plotColors = (1-[1 0.7 0.4]') * [1 1 1] + [1 0.7 0.4]' * plotBaseColor;
visualize1d(wRange,pDecode{1},'voxel width [mm]',...
    'probability','',plotColors(1,:));
hold on;
visualize1d(wRange,pDecode{2},'voxel width [mm]',...
    'probability','',plotColors(2,:));
visualize1d(wRange,pDecode{3},'voxel width [mm]',...
    'probability','',plotColors(3,:));
[~,icons] =  legend({'2 classes','4 classes','8 classes'},...
    'Location','East','box','off');
shortenLegendLines(icons,0.05);
axis([0 4 0 1.1]);
line([wRange(maxIdx) wRange(maxIdx)],[0 1],'LineStyle',':',...
    'Color',plotColors(1,:));

text(wRange(maxIdx)+0.1,1.06,['w_{opt} = ' ...
    num2str(wRange(maxIdx),2) ' mm'],'FontSize',12);
%putGridLines(1,[]);
axis square;
box off;

p.de.margin = 25;
p.margintop =  15;

axes('Position',[0 0 1 1],'YDir','reverse','visible','off');

t1 = text(0.0615, 0.0185,...
    'A Decoding accuracy',...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

t2 = text(0.5734, 0.0185,...
    {'B Probability of statistically','significant decoding'},...
    'FontSize',12,'FontName','Arial','FontWeight','bold',...
    'HorizontalAlignment','left','VerticalAlignment','top');

if ~exist('figNumber','var')
    figNumberStr = '';
else
    figNumberStr = sprintf('%.2d_',figNumber);
end

printFigureOnPaper(twoColumnWidth, columnHeight,...
   fullfile(rootDir,'figures',[figNumberStr 'voxelDependenceMVPA']));
end

function AX=visualize1d2func(xRange,data,xLabel,yLabel,titleText,lineStyle)
[AX,H1,H2] = plotyy(xRange, data(:,1),xRange,data(:,2),'plot');
hold on;
set(get(AX(1),'Ylabel'),'String',yLabel(1));
set(get(AX(1),'Ylabel'),'FontSize',8);
set(get(AX(2),'Ylabel'),'String',yLabel(2));
set(get(AX(2),'Ylabel'),'FontSize',12);
xlabel(xLabel);
if exist('lineStyle','var')
    set(H1,'Color',lineStyle{1});
    set(AX(1),'YColor',lineStyle{1})
    set(get(AX(1),'Ylabel'),'Color',lineStyle{1});
    set(H2,'Color',lineStyle{2});
    set(AX(2),'YColor',lineStyle{2})
    set(get(AX(2),'Ylabel'),'Color',lineStyle{2});
end
title(titleText);
uistack(AX(1));
end

function visualize1d(xRange,data,xLabel,yLabel,titleText,lineStyle)
if ~exist('lineStyle','var')
    lineStyle = 'k';
end

if isnumeric(lineStyle)
    plot(xRange, data,'Color',lineStyle);
else
    plot(xRange, data,lineStyle);
end
xlabel(xLabel);
ylabel(yLabel);
title(titleText);
end

function putGridLines(xRes,yRes,leaveOutLast)
ax = axis(gca);
if ~isempty(xRes)
    startX = floor(ax(1)/xRes)*xRes;
    endX = ceil(ax(2)/xRes)*xRes;
    if exist('leaveOutLast','var') && leaveOutLast
        endX = endX - xRes;
    end
    for x=startX:xRes:endX
        l = line([x x],[ax(3) ax(4)],'LineStyle',':','Color','k','LineWidth',1);
        uistack(l,'bottom');
    end
end
if ~isempty(yRes)
    startY = ceil(ax(3)/yRes)*yRes;
    endY = ceil(ax(4)/yRes)*yRes;
    for y=startY:yRes:endY
        l = line([ax(1) ax(2)],[y y],'LineStyle',':','Color','k','LineWidth',1);
        uistack(l,'bottom');
    end
end
end